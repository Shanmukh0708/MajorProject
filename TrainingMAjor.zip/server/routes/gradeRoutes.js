const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const { protect, authorize } = require('../middleware/auth');
const Grade = require('../models/Grade');
const Student = require('../models/Student');
const Course = require('../models/Course');

// @desc    Get all grades
// @route   GET /api/grades
// @access  Private/Teacher/Admin
router.get('/', protect, authorize('teacher', 'admin'), asyncHandler(async (req, res) => {
  const query = {};

  // Filter by course if provided
  if (req.query.course) {
    query.course = req.query.course;
  }

  // Filter by student if provided
  if (req.query.student) {
    query.student = req.query.student;
  }

  // Filter by category if provided
  if (req.query.category) {
    query.category = req.query.category;
  }

  // Filter by date range
  if (req.query.startDate || req.query.endDate) {
    query.gradedDate = {};
    if (req.query.startDate) query.gradedDate.$gte = new Date(req.query.startDate);
    if (req.query.endDate) query.gradedDate.$lte = new Date(req.query.endDate);
  }

  const grades = await Grade.find(query)
    .populate('student', 'user')
    .populate('course', 'title courseCode')
    .populate('assignment', 'title type')
    .populate('teacher', 'user')
    .sort({ gradedDate: -1 });

  res.json(grades);
}));

// @desc    Get grade by ID
// @route   GET /api/grades/:id
// @access  Private
router.get('/:id', protect, asyncHandler(async (req, res) => {
  const grade = await Grade.findById(req.params.id)
    .populate('student', 'user')
    .populate('course', 'title courseCode')
    .populate('assignment', 'title type')
    .populate('teacher', 'user');

  if (!grade) {
    res.status(404);
    throw new Error('Grade not found');
  }

  // Check if user is authorized to view this grade
  if (
    req.user.role === 'student' &&
    grade.student.user.toString() !== req.user._id.toString()
  ) {
    res.status(403);
    throw new Error('Not authorized to view this grade');
  }

  res.json(grade);
}));

// @desc    Create grade
// @route   POST /api/grades
// @access  Private/Teacher
router.post('/', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const course = await Course.findById(req.body.course);
  
  if (!course) {
    res.status(404);
    throw new Error('Course not found');
  }

  // Verify teacher is assigned to this course
  const isTeacher = course.teachers.some(
    teacher => teacher.teacher.toString() === req.user._id.toString()
  );

  if (!isTeacher) {
    res.status(403);
    throw new Error('Not authorized to create grades for this course');
  }

  const grade = await Grade.create({
    ...req.body,
    teacher: req.user._id
  });

  // Add grade reference to student
  const student = await Student.findById(req.body.student);
  if (student) {
    student.grades.push(grade._id);
    await student.save();
    
    // Recalculate student's GPA
    await student.calculateGPA();
  }

  res.status(201).json(grade);
}));

// @desc    Update grade
// @route   PUT /api/grades/:id
// @access  Private/Teacher
router.put('/:id', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const grade = await Grade.findById(req.params.id);

  if (!grade) {
    res.status(404);
    throw new Error('Grade not found');
  }

  // Verify teacher owns this grade
  if (grade.teacher.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to update this grade');
  }

  const updatedGrade = await Grade.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true, runValidators: true }
  );

  // Recalculate student's GPA
  const student = await Student.findById(grade.student);
  if (student) {
    await student.calculateGPA();
  }

  res.json(updatedGrade);
}));

// @desc    Delete grade
// @route   DELETE /api/grades/:id
// @access  Private/Teacher
router.delete('/:id', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const grade = await Grade.findById(req.params.id);

  if (!grade) {
    res.status(404);
    throw new Error('Grade not found');
  }

  // Verify teacher owns this grade
  if (grade.teacher.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to delete this grade');
  }

  // Remove grade reference from student
  const student = await Student.findById(grade.student);
  if (student) {
    student.grades = student.grades.filter(
      g => g.toString() !== grade._id.toString()
    );
    await student.save();
    
    // Recalculate student's GPA
    await student.calculateGPA();
  }

  await grade.remove();

  res.json({ message: 'Grade removed' });
}));

// @desc    Submit grade dispute
// @route   POST /api/grades/:id/dispute
// @access  Private/Student
router.post('/:id/dispute', protect, authorize('student'), asyncHandler(async (req, res) => {
  const grade = await Grade.findById(req.params.id);

  if (!grade) {
    res.status(404);
    throw new Error('Grade not found');
  }

  // Verify student owns this grade
  if (grade.student.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to dispute this grade');
  }

  const dispute = await grade.submitDispute(req.body.reason);
  res.json(dispute);
}));

// @desc    Resolve grade dispute
// @route   PUT /api/grades/:id/resolve-dispute
// @access  Private/Teacher
router.put('/:id/resolve-dispute', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const grade = await Grade.findById(req.params.id);

  if (!grade) {
    res.status(404);
    throw new Error('Grade not found');
  }

  // Verify teacher owns this grade
  if (grade.teacher.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to resolve this grade dispute');
  }

  const resolvedGrade = await grade.resolveDispute(
    req.body.resolution,
    req.body.newScore
  );

  // Recalculate student's GPA if score was changed
  if (req.body.newScore) {
    const student = await Student.findById(grade.student);
    if (student) {
      await student.calculateGPA();
    }
  }

  res.json(resolvedGrade);
}));

// @desc    Get grade statistics
// @route   GET /api/grades/stats/:courseId
// @access  Private/Teacher
router.get('/stats/:courseId', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const grades = await Grade.find({ course: req.params.courseId });

  const stats = {
    totalGrades: grades.length,
    averageScore: grades.reduce((sum, grade) => sum + grade.score, 0) / grades.length || 0,
    highestScore: Math.max(...grades.map(grade => grade.score)),
    lowestScore: Math.min(...grades.map(grade => grade.score)),
    gradeDistribution: {
      'A+': grades.filter(grade => grade.letterGrade === 'A+').length,
      'A': grades.filter(grade => grade.letterGrade === 'A').length,
      'A-': grades.filter(grade => grade.letterGrade === 'A-').length,
      'B+': grades.filter(grade => grade.letterGrade === 'B+').length,
      'B': grades.filter(grade => grade.letterGrade === 'B').length,
      'B-': grades.filter(grade => grade.letterGrade === 'B-').length,
      'C+': grades.filter(grade => grade.letterGrade === 'C+').length,
      'C': grades.filter(grade => grade.letterGrade === 'C').length,
      'C-': grades.filter(grade => grade.letterGrade === 'C-').length,
      'D+': grades.filter(grade => grade.letterGrade === 'D+').length,
      'D': grades.filter(grade => grade.letterGrade === 'D').length,
      'D-': grades.filter(grade => grade.letterGrade === 'D-').length,
      'F': grades.filter(grade => grade.letterGrade === 'F').length
    }
  };

  res.json(stats);
}));

module.exports = router;
