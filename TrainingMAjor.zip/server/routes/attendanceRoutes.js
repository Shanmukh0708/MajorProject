const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const { protect, authorize } = require('../middleware/auth');
const Attendance = require('../models/Attendance');
const Course = require('../models/Course');
const Student = require('../models/Student');

// @desc    Get all attendance records
// @route   GET /api/attendance
// @access  Private/Teacher/Admin
router.get('/', protect, authorize('teacher', 'admin'), asyncHandler(async (req, res) => {
  const query = {};

  // Filter by course if provided
  if (req.query.course) {
    query.course = req.query.course;
  }

  // Filter by date range
  if (req.query.startDate || req.query.endDate) {
    query.date = {};
    if (req.query.startDate) query.date.$gte = new Date(req.query.startDate);
    if (req.query.endDate) query.date.$lte = new Date(req.query.endDate);
  }

  // Filter by session type if provided
  if (req.query.sessionType) {
    query.sessionType = req.query.sessionType;
  }

  const attendance = await Attendance.find(query)
    .populate('course', 'title courseCode')
    .populate('teacher', 'user')
    .populate({
      path: 'records.student',
      populate: {
        path: 'user',
        select: 'firstName lastName'
      }
    })
    .sort({ date: -1 });

  res.json(attendance);
}));

// @desc    Get attendance by ID
// @route   GET /api/attendance/:id
// @access  Private
router.get('/:id', protect, asyncHandler(async (req, res) => {
  const attendance = await Attendance.findById(req.params.id)
    .populate('course', 'title courseCode')
    .populate('teacher', 'user')
    .populate({
      path: 'records.student',
      populate: {
        path: 'user',
        select: 'firstName lastName'
      }
    });

  if (!attendance) {
    res.status(404);
    throw new Error('Attendance record not found');
  }

  res.json(attendance);
}));

// @desc    Create attendance record
// @route   POST /api/attendance
// @access  Private/Teacher
router.post('/', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const course = await Course.findById(req.body.course);
  
  if (!course) {
    res.status(404);
    throw new Error('Course not found');
  }

  // Verify teacher is assigned to this course
  const isTeacher = course.teachers.some(
    teacher => teacher.teacher.toString() === req.user._id.toString()
  );

  if (!isTeacher) {
    res.status(403);
    throw new Error('Not authorized to take attendance for this course');
  }

  const attendance = await Attendance.create({
    ...req.body,
    teacher: req.user._id
  });

  // Add attendance reference to students
  for (const record of attendance.records) {
    const student = await Student.findById(record.student);
    if (student) {
      student.attendance.push(attendance._id);
      await student.save();
    }
  }

  res.status(201).json(attendance);
}));

// @desc    Update attendance record
// @route   PUT /api/attendance/:id
// @access  Private/Teacher
router.put('/:id', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const attendance = await Attendance.findById(req.params.id);

  if (!attendance) {
    res.status(404);
    throw new Error('Attendance record not found');
  }

  // Verify teacher owns this attendance record
  if (attendance.teacher.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to update this attendance record');
  }

  const updatedAttendance = await Attendance.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true, runValidators: true }
  );

  res.json(updatedAttendance);
}));

// @desc    Delete attendance record
// @route   DELETE /api/attendance/:id
// @access  Private/Teacher
router.delete('/:id', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const attendance = await Attendance.findById(req.params.id);

  if (!attendance) {
    res.status(404);
    throw new Error('Attendance record not found');
  }

  // Verify teacher owns this attendance record
  if (attendance.teacher.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to delete this attendance record');
  }

  // Remove attendance reference from students
  for (const record of attendance.records) {
    const student = await Student.findById(record.student);
    if (student) {
      student.attendance = student.attendance.filter(
        a => a.toString() !== attendance._id.toString()
      );
      await student.save();
    }
  }

  await attendance.remove();

  res.json({ message: 'Attendance record removed' });
}));

// @desc    Mark student attendance
// @route   POST /api/attendance/:id/mark/:studentId
// @access  Private/Teacher
router.post('/:id/mark/:studentId', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const attendance = await Attendance.findById(req.params.id);

  if (!attendance) {
    res.status(404);
    throw new Error('Attendance record not found');
  }

  // Verify teacher owns this attendance record
  if (attendance.teacher.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to mark attendance for this record');
  }

  const record = await attendance.markAttendance(
    req.params.studentId,
    req.body.status,
    req.body.options
  );

  res.json(record);
}));

// @desc    Bulk mark attendance
// @route   POST /api/attendance/:id/bulk-mark
// @access  Private/Teacher
router.post('/:id/bulk-mark', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const attendance = await Attendance.findById(req.params.id);

  if (!attendance) {
    res.status(404);
    throw new Error('Attendance record not found');
  }

  // Verify teacher owns this attendance record
  if (attendance.teacher.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to mark attendance for this record');
  }

  const records = await attendance.bulkMarkAttendance(req.body.records);
  res.json(records);
}));

// @desc    Get student attendance statistics
// @route   GET /api/attendance/student/:studentId
// @access  Private
router.get('/student/:studentId', protect, asyncHandler(async (req, res) => {
  // Verify authorization
  if (
    req.user.role === 'student' &&
    req.user._id.toString() !== req.params.studentId
  ) {
    res.status(403);
    throw new Error('Not authorized to view this attendance record');
  }

  const stats = await Attendance.getStudentStatistics(
    req.params.studentId,
    req.query.courseId
  );

  res.json(stats);
}));

// @desc    Get course attendance statistics
// @route   GET /api/attendance/course/:courseId/stats
// @access  Private/Teacher
router.get('/course/:courseId/stats', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const stats = await Attendance.getCourseStatistics(
    req.params.courseId,
    req.query.startDate,
    req.query.endDate
  );

  res.json(stats);
}));

module.exports = router;
