const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const asyncHandler = require('express-async-handler');
const { protect, authorize, rateLimiter } = require('../middleware/auth');
const User = require('../models/User');
const Student = require('../models/Student');
const Teacher = require('../models/Teacher');

// Generate JWT Token
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });
};

// @desc    Register user
// @route   POST /api/users/register
// @access  Public
router.post('/register', rateLimiter(5, 60 * 1000), asyncHandler(async (req, res) => {
  const { email, password, firstName, lastName, role } = req.body;

  // Check if user exists
  const userExists = await User.findOne({ email });
  if (userExists) {
    res.status(400);
    throw new Error('User already exists');
  }

  // Create user
  const user = await User.create({
    email,
    password,
    firstName,
    lastName,
    role
  });

  // Create role-specific profile
  if (role === 'student') {
    await Student.create({
      user: user._id,
      studentId: `STU${Date.now()}`,
      academicYear: req.body.academicYear || '1st Year',
      major: req.body.major || 'Undeclared'
    });
  } else if (role === 'teacher') {
    await Teacher.create({
      user: user._id,
      teacherId: `TCH${Date.now()}`,
      department: req.body.department || 'General',
      specializations: req.body.specializations || []
    });
  }

  if (user) {
    res.status(201).json({
      _id: user._id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
      token: generateToken(user._id)
    });
  } else {
    res.status(400);
    throw new Error('Invalid user data');
  }
}));

// @desc    Login user
// @route   POST /api/users/login
// @access  Public
router.post('/login', rateLimiter(10, 60 * 1000), asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  // Find user
  const user = await User.findOne({ email });

  if (user && (await user.matchPassword(password))) {
    // Update last login
    user.lastLogin = new Date();
    await user.save();

    res.json({
      _id: user._id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
      token: generateToken(user._id)
    });
  } else {
    res.status(401);
    throw new Error('Invalid email or password');
  }
}));

// @desc    Get user profile
// @route   GET /api/users/profile
// @access  Private
router.get('/profile', protect, asyncHandler(async (req, res) => {
  let userProfile;
  
  if (req.user.role === 'student') {
    userProfile = await Student.findOne({ user: req.user._id }).populate('user', '-password');
  } else if (req.user.role === 'teacher') {
    userProfile = await Teacher.findOne({ user: req.user._id }).populate('user', '-password');
  } else {
    userProfile = await User.findById(req.user._id).select('-password');
  }

  if (userProfile) {
    res.json(userProfile);
  } else {
    res.status(404);
    throw new Error('User profile not found');
  }
}));

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
router.put('/profile', protect, asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);

  if (user) {
    user.firstName = req.body.firstName || user.firstName;
    user.lastName = req.body.lastName || user.lastName;
    user.email = req.body.email || user.email;
    
    if (req.body.password) {
      user.password = req.body.password;
    }

    const updatedUser = await user.save();

    // Update role-specific profile
    if (user.role === 'student') {
      const student = await Student.findOne({ user: user._id });
      if (student && req.body.studentProfile) {
        Object.assign(student, req.body.studentProfile);
        await student.save();
      }
    } else if (user.role === 'teacher') {
      const teacher = await Teacher.findOne({ user: user._id });
      if (teacher && req.body.teacherProfile) {
        Object.assign(teacher, req.body.teacherProfile);
        await teacher.save();
      }
    }

    res.json({
      _id: updatedUser._id,
      firstName: updatedUser.firstName,
      lastName: updatedUser.lastName,
      email: updatedUser.email,
      role: updatedUser.role,
      token: generateToken(updatedUser._id)
    });
  } else {
    res.status(404);
    throw new Error('User not found');
  }
}));

// @desc    Get all users
// @route   GET /api/users
// @access  Private/Admin
router.get('/', protect, authorize('admin'), asyncHandler(async (req, res) => {
  const users = await User.find({}).select('-password');
  res.json(users);
}));

// @desc    Delete user
// @route   DELETE /api/users/:id
// @access  Private/Admin
router.delete('/:id', protect, authorize('admin'), asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);

  if (user) {
    // Delete role-specific profile
    if (user.role === 'student') {
      await Student.findOneAndDelete({ user: user._id });
    } else if (user.role === 'teacher') {
      await Teacher.findOneAndDelete({ user: user._id });
    }

    await user.remove();
    res.json({ message: 'User removed' });
  } else {
    res.status(404);
    throw new Error('User not found');
  }
}));

// @desc    Change password
// @route   PUT /api/users/change-password
// @access  Private
router.put('/change-password', protect, asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  
  const user = await User.findById(req.user._id);
  
  if (user && (await user.matchPassword(currentPassword))) {
    user.password = newPassword;
    await user.save();
    
    res.json({ message: 'Password updated successfully' });
  } else {
    res.status(401);
    throw new Error('Current password is incorrect');
  }
}));

module.exports = router;
