const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const { protect, authorize } = require('../middleware/auth');
const Assignment = require('../models/Assignment');
const Course = require('../models/Course');
const Grade = require('../models/Grade');

// @desc    Get all assignments
// @route   GET /api/assignments
// @access  Private
router.get('/', protect, asyncHandler(async (req, res) => {
  const query = {};

  // Filter by course if provided
  if (req.query.course) {
    query.course = req.query.course;
  }

  // Filter by type if provided
  if (req.query.type) {
    query.type = req.query.type;
  }

  // Filter by status if provided
  if (req.query.status) {
    query.status = req.query.status;
  }

  // Filter by due date range
  if (req.query.startDate || req.query.endDate) {
    query.dueDate = {};
    if (req.query.startDate) query.dueDate.$gte = new Date(req.query.startDate);
    if (req.query.endDate) query.dueDate.$lte = new Date(req.query.endDate);
  }

  const assignments = await Assignment.find(query)
    .populate('course', 'title courseCode')
    .populate('teacher', 'user')
    .sort({ dueDate: 1 });

  res.json(assignments);
}));

// @desc    Get assignment by ID
// @route   GET /api/assignments/:id
// @access  Private
router.get('/:id', protect, asyncHandler(async (req, res) => {
  const assignment = await Assignment.findById(req.params.id)
    .populate('course', 'title courseCode')
    .populate('teacher', 'user')
    .populate({
      path: 'submissions.student',
      populate: {
        path: 'user',
        select: 'firstName lastName email'
      }
    });

  if (!assignment) {
    res.status(404);
    throw new Error('Assignment not found');
  }

  res.json(assignment);
}));

// @desc    Create assignment
// @route   POST /api/assignments
// @access  Private/Teacher
router.post('/', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const course = await Course.findById(req.body.course);

  if (!course) {
    res.status(404);
    throw new Error('Course not found');
  }

  // Verify teacher is assigned to this course
  const isTeacher = course.teachers.some(
    teacher => teacher.teacher.toString() === req.user._id.toString()
  );

  if (!isTeacher) {
    res.status(403);
    throw new Error('Not authorized to create assignments for this course');
  }

  const assignment = await Assignment.create({
    ...req.body,
    teacher: req.user._id
  });

  // Add assignment reference to course
  course.assignments.push(assignment._id);
  await course.save();

  res.status(201).json(assignment);
}));

// @desc    Update assignment
// @route   PUT /api/assignments/:id
// @access  Private/Teacher
router.put('/:id', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const assignment = await Assignment.findById(req.params.id);

  if (!assignment) {
    res.status(404);
    throw new Error('Assignment not found');
  }

  // Verify teacher owns this assignment
  if (assignment.teacher.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to update this assignment');
  }

  const updatedAssignment = await Assignment.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true, runValidators: true }
  );

  res.json(updatedAssignment);
}));

// @desc    Delete assignment
// @route   DELETE /api/assignments/:id
// @access  Private/Teacher
router.delete('/:id', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const assignment = await Assignment.findById(req.params.id);

  if (!assignment) {
    res.status(404);
    throw new Error('Assignment not found');
  }

  // Verify teacher owns this assignment
  if (assignment.teacher.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to delete this assignment');
  }

  // Delete all related grades
  await Grade.deleteMany({ assignment: assignment._id });

  // Remove assignment reference from course
  const course = await Course.findById(assignment.course);
  if (course) {
    course.assignments = course.assignments.filter(
      a => a.toString() !== assignment._id.toString()
    );
    await course.save();
  }

  await assignment.remove();

  res.json({ message: 'Assignment removed' });
}));

// @desc    Submit assignment
// @route   POST /api/assignments/:id/submit
// @access  Private/Student
router.post('/:id/submit', protect, authorize('student'), asyncHandler(async (req, res) => {
  const assignment = await Assignment.findById(req.params.id);

  if (!assignment) {
    res.status(404);
    throw new Error('Assignment not found');
  }

  const submission = await assignment.submitAssignment(req.user._id, req.body.files);
  res.json(submission);
}));

// @desc    Grade submission
// @route   POST /api/assignments/:id/grade/:studentId
// @access  Private/Teacher
router.post('/:id/grade/:studentId', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const assignment = await Assignment.findById(req.params.id);

  if (!assignment) {
    res.status(404);
    throw new Error('Assignment not found');
  }

  // Verify teacher owns this assignment
  if (assignment.teacher.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to grade this assignment');
  }

  const submission = await assignment.gradeSubmission(
    req.params.studentId,
    req.body.gradeData,
    req.user._id
  );

  // Create grade record
  const grade = await Grade.create({
    student: req.params.studentId,
    course: assignment.course,
    assignment: assignment._id,
    teacher: req.user._id,
    score: req.body.gradeData.score,
    feedback: req.body.gradeData.feedback,
    category: assignment.type,
    weight: req.body.gradeData.weight || 1,
    submissionDate: submission.submittedAt,
    gradedDate: new Date(),
    rubricScores: req.body.gradeData.rubricScores
  });

  res.json({ submission, grade });
}));

// @desc    Get assignment statistics
// @route   GET /api/assignments/:id/stats
// @access  Private/Teacher
router.get('/:id/stats', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const assignment = await Assignment.findById(req.params.id);

  if (!assignment) {
    res.status(404);
    throw new Error('Assignment not found');
  }

  const stats = {
    totalSubmissions: assignment.submissionCount,
    averageGrade: assignment.averageGrade,
    submissionRate: (assignment.submissionCount / assignment.course.students.length * 100).toFixed(2),
    gradedCount: assignment.submissions.filter(s => s.grade && s.grade.status === 'graded').length,
    pendingCount: assignment.submissions.filter(s => !s.grade || s.grade.status === 'pending').length,
    lateSubmissions: assignment.submissions.filter(s => s.status === 'late').length
  };

  res.json(stats);
}));

module.exports = router;
