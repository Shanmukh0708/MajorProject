const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const { protect, authorize } = require('../middleware/auth');
const Teacher = require('../models/Teacher');
const Course = require('../models/Course');
const Assignment = require('../models/Assignment');
const Grade = require('../models/Grade');
const Attendance = require('../models/Attendance');
const Student = require('../models/Student');

// @desc    Get teacher dashboard data
// @route   GET /api/teachers/dashboard
// @access  Private/Teacher
router.get('/dashboard', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOne({ user: req.user._id })
    .populate({
      path: 'courses.course',
      populate: {
        path: 'students.student',
        populate: {
          path: 'user',
          select: 'firstName lastName email'
        }
      }
    });

  if (!teacher) {
    res.status(404);
    throw new Error('Teacher profile not found');
  }

  // Get recent assignments
  const recentAssignments = await Assignment.find({
    teacher: teacher._id
  })
    .sort({ createdAt: -1 })
    .limit(5)
    .populate('course', 'title');

  // Get pending grades
  const pendingGrades = await Assignment.find({
    teacher: teacher._id,
    'submissions.grade.status': 'pending'
  })
    .populate('course', 'title')
    .populate('submissions.student', 'user')
    .sort({ dueDate: 1 });

  // Get today's classes
  const today = new Date();
  const todayClasses = teacher.courses.filter(course => {
    return course.schedule.some(schedule => 
      schedule.day === ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][today.getDay()]
    );
  });

  res.json({
    teacher,
    recentAssignments,
    pendingGrades,
    todayClasses
  });
}));

// @desc    Get teacher's courses
// @route   GET /api/teachers/courses
// @access  Private/Teacher
router.get('/courses', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOne({ user: req.user._id });
  
  if (!teacher) {
    res.status(404);
    throw new Error('Teacher profile not found');
  }

  const courses = await Course.find({
    'teachers.teacher': teacher._id
  })
    .populate({
      path: 'students.student',
      populate: {
        path: 'user',
        select: 'firstName lastName email'
      }
    });

  res.json(courses);
}));

// @desc    Create a course
// @route   POST /api/teachers/courses
// @access  Private/Teacher
router.post('/courses', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOne({ user: req.user._id });
  
  if (!teacher) {
    res.status(404);
    throw new Error('Teacher profile not found');
  }

  const course = await Course.create({
    ...req.body,
    teachers: [{ teacher: teacher._id, role: 'primary' }]
  });

  await teacher.addCourse({
    course: course._id,
    role: 'primary',
    semester: course.semester.term + ' ' + course.semester.year
  });

  res.status(201).json(course);
}));

// @desc    Create assignment
// @route   POST /api/teachers/courses/:courseId/assignments
// @access  Private/Teacher
router.post('/courses/:courseId/assignments', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOne({ user: req.user._id });
  const course = await Course.findById(req.params.courseId);

  if (!teacher || !course) {
    res.status(404);
    throw new Error('Teacher or course not found');
  }

  // Verify teacher is assigned to this course
  if (!course.teachers.some(t => t.teacher.toString() === teacher._id.toString())) {
    res.status(403);
    throw new Error('Not authorized to create assignments for this course');
  }

  const assignment = await Assignment.create({
    ...req.body,
    course: course._id,
    teacher: teacher._id
  });

  // Add assignment reference to course
  course.assignments.push(assignment._id);
  await course.save();

  res.status(201).json(assignment);
}));

// @desc    Grade assignment submission
// @route   POST /api/teachers/assignments/:assignmentId/grade/:studentId
// @access  Private/Teacher
router.post('/assignments/:assignmentId/grade/:studentId', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOne({ user: req.user._id });
  const assignment = await Assignment.findById(req.params.assignmentId);
  const student = await Student.findById(req.params.studentId);

  if (!teacher || !assignment || !student) {
    res.status(404);
    throw new Error('Teacher, assignment, or student not found');
  }

  // Grade the submission
  const submission = await assignment.gradeSubmission(
    student._id,
    req.body.gradeData,
    teacher._id
  );

  // Create grade record
  const grade = await Grade.create({
    student: student._id,
    course: assignment.course,
    assignment: assignment._id,
    teacher: teacher._id,
    score: req.body.gradeData.score,
    feedback: req.body.gradeData.feedback,
    category: assignment.type,
    weight: req.body.gradeData.weight || 1,
    submissionDate: submission.submittedAt,
    gradedDate: new Date(),
    rubricScores: req.body.gradeData.rubricScores
  });

  res.json({ submission, grade });
}));

// @desc    Take attendance
// @route   POST /api/teachers/courses/:courseId/attendance
// @access  Private/Teacher
router.post('/courses/:courseId/attendance', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOne({ user: req.user._id });
  const course = await Course.findById(req.params.courseId);

  if (!teacher || !course) {
    res.status(404);
    throw new Error('Teacher or course not found');
  }

  const attendance = await Attendance.create({
    course: course._id,
    teacher: teacher._id,
    date: req.body.date || new Date(),
    records: req.body.records,
    sessionType: req.body.sessionType,
    duration: req.body.duration,
    startTime: req.body.startTime,
    endTime: req.body.endTime,
    location: req.body.location,
    isOnline: req.body.isOnline
  });

  res.status(201).json(attendance);
}));

// @desc    Update office hours
// @route   PUT /api/teachers/office-hours
// @access  Private/Teacher
router.put('/office-hours', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const teacher = await Teacher.findOne({ user: req.user._id });
  
  if (!teacher) {
    res.status(404);
    throw new Error('Teacher profile not found');
  }

  const updatedOfficeHours = await teacher.updateOfficeHours(req.body.officeHours);
  res.json(updatedOfficeHours);
}));

// @desc    Resolve grade dispute
// @route   PUT /api/teachers/grades/:gradeId/resolve-dispute
// @access  Private/Teacher
router.put('/grades/:gradeId/resolve-dispute', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const grade = await Grade.findById(req.params.gradeId);
  
  if (!grade) {
    res.status(404);
    throw new Error('Grade not found');
  }

  if (grade.teacher.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to resolve this grade dispute');
  }

  const resolvedGrade = await grade.resolveDispute(
    req.body.resolution,
    req.body.newScore
  );

  res.json(resolvedGrade);
}));

module.exports = router;
