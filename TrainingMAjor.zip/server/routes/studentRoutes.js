const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const { protect, authorize } = require('../middleware/auth');
const Student = require('../models/Student');
const Course = require('../models/Course');
const Assignment = require('../models/Assignment');
const Grade = require('../models/Grade');
const Attendance = require('../models/Attendance');

// @desc    Get student dashboard data
// @route   GET /api/students/dashboard
// @access  Private/Student
router.get('/dashboard', protect, authorize('student'), asyncHandler(async (req, res) => {
  const student = await Student.findOne({ user: req.user._id })
    .populate('enrolledCourses.course')
    .populate('grades')
    .populate('attendance');

  if (!student) {
    res.status(404);
    throw new Error('Student profile not found');
  }

  // Get recent assignments
  const recentAssignments = await Assignment.find({
    'submissions.student': student._id
  })
    .sort({ dueDate: -1 })
    .limit(5)
    .populate('course', 'title');

  // Get upcoming assignments
  const upcomingAssignments = await Assignment.find({
    course: { $in: student.enrolledCourses.map(ec => ec.course._id) },
    dueDate: { $gt: new Date() }
  })
    .sort({ dueDate: 1 })
    .limit(5)
    .populate('course', 'title');

  // Calculate GPA
  const gpa = await Grade.calculateGPA(student._id);

  // Get attendance statistics
  const attendanceStats = await Attendance.getStudentStatistics(
    student._id,
    student.enrolledCourses.map(ec => ec.course._id)
  );

  res.json({
    student,
    recentAssignments,
    upcomingAssignments,
    gpa,
    attendanceStats
  });
}));

// @desc    Get student courses
// @route   GET /api/students/courses
// @access  Private/Student
router.get('/courses', protect, authorize('student'), asyncHandler(async (req, res) => {
  const student = await Student.findOne({ user: req.user._id })
    .populate({
      path: 'enrolledCourses.course',
      populate: {
        path: 'teachers.teacher',
        select: 'user',
        populate: {
          path: 'user',
          select: 'firstName lastName'
        }
      }
    });

  if (!student) {
    res.status(404);
    throw new Error('Student profile not found');
  }

  res.json(student.enrolledCourses);
}));

// @desc    Enroll in a course
// @route   POST /api/students/courses/:courseId/enroll
// @access  Private/Student
router.post('/courses/:courseId/enroll', protect, authorize('student'), asyncHandler(async (req, res) => {
  const student = await Student.findOne({ user: req.user._id });
  const course = await Course.findById(req.params.courseId);

  if (!student || !course) {
    res.status(404);
    throw new Error('Student or course not found');
  }

  if (course.isFull()) {
    res.status(400);
    throw new Error('Course is at full capacity');
  }

  const enrolled = await student.enrollCourse(course._id);
  if (enrolled) {
    await course.addStudent(student._id);
    res.json({ message: 'Successfully enrolled in course' });
  } else {
    res.status(400);
    throw new Error('Already enrolled in this course');
  }
}));

// @desc    Get student assignments
// @route   GET /api/students/assignments
// @access  Private/Student
router.get('/assignments', protect, authorize('student'), asyncHandler(async (req, res) => {
  const student = await Student.findOne({ user: req.user._id });
  
  if (!student) {
    res.status(404);
    throw new Error('Student profile not found');
  }

  const assignments = await Assignment.find({
    course: { $in: student.enrolledCourses.map(ec => ec.course) }
  })
    .populate('course', 'title')
    .sort({ dueDate: 1 });

  res.json(assignments);
}));

// @desc    Submit assignment
// @route   POST /api/students/assignments/:assignmentId/submit
// @access  Private/Student
router.post('/assignments/:assignmentId/submit', protect, authorize('student'), asyncHandler(async (req, res) => {
  const student = await Student.findOne({ user: req.user._id });
  const assignment = await Assignment.findById(req.params.assignmentId);

  if (!student || !assignment) {
    res.status(404);
    throw new Error('Student or assignment not found');
  }

  const submission = await assignment.submitAssignment(student._id, req.body.files);
  res.json(submission);
}));

// @desc    Get student grades
// @route   GET /api/students/grades
// @access  Private/Student
router.get('/grades', protect, authorize('student'), asyncHandler(async (req, res) => {
  const student = await Student.findOne({ user: req.user._id });
  
  if (!student) {
    res.status(404);
    throw new Error('Student profile not found');
  }

  const grades = await Grade.find({ student: student._id })
    .populate('course', 'title')
    .populate('assignment', 'title type')
    .sort({ gradedDate: -1 });

  const gpa = await Grade.calculateGPA(student._id);

  res.json({
    grades,
    gpa
  });
}));

// @desc    Get student attendance
// @route   GET /api/students/attendance
// @access  Private/Student
router.get('/attendance', protect, authorize('student'), asyncHandler(async (req, res) => {
  const student = await Student.findOne({ user: req.user._id });
  
  if (!student) {
    res.status(404);
    throw new Error('Student profile not found');
  }

  const attendance = await Attendance.find({
    'records.student': student._id
  })
    .populate('course', 'title')
    .sort({ date: -1 });

  const stats = await Attendance.getStudentStatistics(
    student._id,
    student.enrolledCourses.map(ec => ec.course)
  );

  res.json({
    attendance,
    stats
  });
}));

// @desc    Submit grade dispute
// @route   POST /api/students/grades/:gradeId/dispute
// @access  Private/Student
router.post('/grades/:gradeId/dispute', protect, authorize('student'), asyncHandler(async (req, res) => {
  const grade = await Grade.findOne({
    _id: req.params.gradeId,
    student: req.user._id
  });

  if (!grade) {
    res.status(404);
    throw new Error('Grade not found');
  }

  const dispute = await grade.submitDispute(req.body.reason);
  res.json(dispute);
}));

module.exports = router;
