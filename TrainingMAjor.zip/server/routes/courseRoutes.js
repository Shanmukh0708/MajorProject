const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const { protect, authorize } = require('../middleware/auth');
const Course = require('../models/Course');
const Assignment = require('../models/Assignment');
const Grade = require('../models/Grade');
const Attendance = require('../models/Attendance');

// @desc    Get all courses
// @route   GET /api/courses
// @access  Private
router.get('/', protect, asyncHandler(async (req, res) => {
  const query = {};
  
  // Filter by department if provided
  if (req.query.department) {
    query.department = req.query.department;
  }

  // Filter by semester if provided
  if (req.query.semester) {
    query['semester.term'] = req.query.semester;
  }

  // Filter by year if provided
  if (req.query.year) {
    query['semester.year'] = req.query.year;
  }

  // Filter by status if provided
  if (req.query.status) {
    query.status = req.query.status;
  }

  const courses = await Course.find(query)
    .populate({
      path: 'teachers.teacher',
      populate: {
        path: 'user',
        select: 'firstName lastName'
      }
    })
    .sort({ 'semester.year': -1, 'semester.term': 1 });

  res.json(courses);
}));

// @desc    Get course by ID
// @route   GET /api/courses/:id
// @access  Private
router.get('/:id', protect, asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id)
    .populate({
      path: 'teachers.teacher',
      populate: {
        path: 'user',
        select: 'firstName lastName email'
      }
    })
    .populate({
      path: 'students.student',
      populate: {
        path: 'user',
        select: 'firstName lastName email'
      }
    })
    .populate('assignments');

  if (!course) {
    res.status(404);
    throw new Error('Course not found');
  }

  res.json(course);
}));

// @desc    Create course
// @route   POST /api/courses
// @access  Private/Teacher/Admin
router.post('/', protect, authorize('teacher', 'admin'), asyncHandler(async (req, res) => {
  const course = await Course.create({
    ...req.body,
    teachers: [{ teacher: req.user._id, role: 'primary' }]
  });

  res.status(201).json(course);
}));

// @desc    Update course
// @route   PUT /api/courses/:id
// @access  Private/Teacher/Admin
router.put('/:id', protect, authorize('teacher', 'admin'), asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id);

  if (!course) {
    res.status(404);
    throw new Error('Course not found');
  }

  // Check if user is authorized to update the course
  const isTeacher = course.teachers.some(
    teacher => teacher.teacher.toString() === req.user._id.toString()
  );
  
  if (!isTeacher && req.user.role !== 'admin') {
    res.status(403);
    throw new Error('Not authorized to update this course');
  }

  const updatedCourse = await Course.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true, runValidators: true }
  );

  res.json(updatedCourse);
}));

// @desc    Delete course
// @route   DELETE /api/courses/:id
// @access  Private/Admin
router.delete('/:id', protect, authorize('admin'), asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id);

  if (!course) {
    res.status(404);
    throw new Error('Course not found');
  }

  // Delete all related assignments
  await Assignment.deleteMany({ course: course._id });

  // Delete all related grades
  await Grade.deleteMany({ course: course._id });

  // Delete all related attendance records
  await Attendance.deleteMany({ course: course._id });

  await course.remove();

  res.json({ message: 'Course removed' });
}));

// @desc    Get course assignments
// @route   GET /api/courses/:id/assignments
// @access  Private
router.get('/:id/assignments', protect, asyncHandler(async (req, res) => {
  const assignments = await Assignment.find({ course: req.params.id })
    .populate('teacher', 'user')
    .sort({ dueDate: 1 });

  res.json(assignments);
}));

// @desc    Get course grades
// @route   GET /api/courses/:id/grades
// @access  Private/Teacher
router.get('/:id/grades', protect, authorize('teacher', 'admin'), asyncHandler(async (req, res) => {
  const grades = await Grade.find({ course: req.params.id })
    .populate('student', 'user')
    .populate('assignment')
    .sort({ gradedDate: -1 });

  res.json(grades);
}));

// @desc    Get course attendance
// @route   GET /api/courses/:id/attendance
// @access  Private/Teacher
router.get('/:id/attendance', protect, authorize('teacher', 'admin'), asyncHandler(async (req, res) => {
  const attendance = await Attendance.find({ course: req.params.id })
    .populate('records.student', 'user')
    .sort({ date: -1 });

  const stats = await Attendance.getCourseStatistics(
    req.params.id,
    req.query.startDate,
    req.query.endDate
  );

  res.json({
    attendance,
    stats
  });
}));

// @desc    Update course materials
// @route   PUT /api/courses/:id/materials
// @access  Private/Teacher
router.put('/:id/materials', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id);

  if (!course) {
    res.status(404);
    throw new Error('Course not found');
  }

  const material = await course.addMaterial(req.body);
  res.json(material);
}));

// @desc    Update grade distribution
// @route   PUT /api/courses/:id/grade-distribution
// @access  Private/Teacher
router.put('/:id/grade-distribution', protect, authorize('teacher'), asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id);

  if (!course) {
    res.status(404);
    throw new Error('Course not found');
  }

  const distribution = await course.updateGradeDistribution(req.body);
  res.json(distribution);
}));

module.exports = router;
