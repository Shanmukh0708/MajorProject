const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
  courseCode: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  department: {
    type: String,
    required: true
  },
  credits: {
    type: Number,
    required: true,
    min: 0
  },
  teachers: [{
    teacher: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Teacher'
    },
    role: {
      type: String,
      enum: ['primary', 'assistant', 'substitute'],
      default: 'primary'
    }
  }],
  students: [{
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student'
    },
    enrollmentDate: {
      type: Date,
      default: Date.now
    },
    status: {
      type: String,
      enum: ['active', 'completed', 'dropped'],
      default: 'active'
    }
  }],
  assignments: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Assignment'
  }],
  schedule: [{
    day: {
      type: String,
      enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    },
    startTime: String,
    endTime: String,
    location: String
  }],
  semester: {
    term: {
      type: String,
      enum: ['Fall', 'Spring', 'Summer'],
      required: true
    },
    year: {
      type: Number,
      required: true
    }
  },
  prerequisites: [{
    type: String,
    trim: true
  }],
  capacity: {
    type: Number,
    required: true,
    min: 1
  },
  enrolledCount: {
    type: Number,
    default: 0
  },
  syllabus: {
    type: String,
    required: true
  },
  materials: [{
    title: String,
    type: {
      type: String,
      enum: ['document', 'video', 'link', 'other']
    },
    url: String,
    uploadDate: {
      type: Date,
      default: Date.now
    }
  }],
  status: {
    type: String,
    enum: ['active', 'archived', 'draft'],
    default: 'active'
  },
  gradeDistribution: {
    assignments: {
      type: Number,
      default: 40
    },
    midterm: {
      type: Number,
      default: 30
    },
    final: {
      type: Number,
      default: 30
    }
  }
}, {
  timestamps: true
});

// Virtual for current enrollment count
courseSchema.virtual('currentEnrollment').get(function() {
  return this.students.filter(student => student.status === 'active').length;
});

// Method to check if course is full
courseSchema.methods.isFull = function() {
  return this.currentEnrollment >= this.capacity;
};

// Method to add a student
courseSchema.methods.addStudent = async function(studentId) {
  if (this.isFull()) {
    throw new Error('Course is at full capacity');
  }

  const exists = this.students.some(
    enrollment => enrollment.student.toString() === studentId.toString()
  );

  if (!exists) {
    this.students.push({
      student: studentId,
      enrollmentDate: new Date(),
      status: 'active'
    });
    this.enrolledCount = this.currentEnrollment;
    await this.save();
    return true;
  }
  return false;
};

// Method to add course material
courseSchema.methods.addMaterial = async function(materialData) {
  this.materials.push({
    ...materialData,
    uploadDate: new Date()
  });
  await this.save();
  return this.materials[this.materials.length - 1];
};

// Method to update grade distribution
courseSchema.methods.updateGradeDistribution = async function(newDistribution) {
  const total = Object.values(newDistribution).reduce((sum, value) => sum + value, 0);
  if (total !== 100) {
    throw new Error('Grade distribution must total 100%');
  }
  
  this.gradeDistribution = newDistribution;
  await this.save();
  return this.gradeDistribution;
};

const Course = mongoose.model('Course', courseSchema);

module.exports = Course;
