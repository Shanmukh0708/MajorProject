const mongoose = require('mongoose');

const gradeSchema = new mongoose.Schema({
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Student',
    required: true
  },
  course: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Course',
    required: true
  },
  assignment: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Assignment',
    required: true
  },
  teacher: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Teacher',
    required: true
  },
  score: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  letterGrade: {
    type: String,
    enum: ['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-', 'F'],
    required: true
  },
  feedback: {
    type: String,
    trim: true
  },
  category: {
    type: String,
    enum: ['assignment', 'quiz', 'project', 'midterm', 'final', 'participation', 'other'],
    required: true
  },
  weight: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  submissionDate: {
    type: Date,
    required: true
  },
  gradedDate: {
    type: Date,
    required: true
  },
  isPublished: {
    type: Boolean,
    default: false
  },
  rubricScores: [{
    criterion: String,
    score: Number,
    maxScore: Number,
    comments: String
  }],
  latePenalty: {
    type: Number,
    min: 0,
    max: 100,
    default: 0
  },
  finalScore: {
    type: Number,
    min: 0,
    max: 100
  },
  status: {
    type: String,
    enum: ['pending', 'graded', 'disputed', 'resolved'],
    default: 'pending'
  },
  dispute: {
    isDisputed: {
      type: Boolean,
      default: false
    },
    reason: String,
    submittedDate: Date,
    resolvedDate: Date,
    resolution: String,
    originalScore: Number
  }
}, {
  timestamps: true
});

// Pre-save middleware to calculate letter grade
gradeSchema.pre('save', function(next) {
  this.letterGrade = this.calculateLetterGrade(this.score);
  this.finalScore = this.calculateFinalScore();
  next();
});

// Method to calculate letter grade
gradeSchema.methods.calculateLetterGrade = function(score) {
  if (score >= 97) return 'A+';
  if (score >= 93) return 'A';
  if (score >= 90) return 'A-';
  if (score >= 87) return 'B+';
  if (score >= 83) return 'B';
  if (score >= 80) return 'B-';
  if (score >= 77) return 'C+';
  if (score >= 73) return 'C';
  if (score >= 70) return 'C-';
  if (score >= 67) return 'D+';
  if (score >= 63) return 'D';
  if (score >= 60) return 'D-';
  return 'F';
};

// Method to calculate final score after penalties
gradeSchema.methods.calculateFinalScore = function() {
  if (this.latePenalty > 0) {
    const penaltyMultiplier = (100 - this.latePenalty) / 100;
    return Math.round(this.score * penaltyMultiplier);
  }
  return this.score;
};

// Method to submit grade dispute
gradeSchema.methods.submitDispute = async function(reason) {
  this.dispute = {
    isDisputed: true,
    reason,
    submittedDate: new Date(),
    originalScore: this.score
  };
  this.status = 'disputed';
  await this.save();
  return this.dispute;
};

// Method to resolve grade dispute
gradeSchema.methods.resolveDispute = async function(resolution, newScore = null) {
  this.dispute.resolution = resolution;
  this.dispute.resolvedDate = new Date();
  
  if (newScore !== null) {
    this.score = newScore;
    // This will trigger pre-save middleware to recalculate letter grade
  }
  
  this.status = 'resolved';
  await this.save();
  return this;
};

// Static method to calculate GPA
gradeSchema.statics.calculateGPA = async function(studentId) {
  const grades = await this.find({ student: studentId, isPublished: true });
  
  if (grades.length === 0) return 0;

  const gradePoints = {
    'A+': 4.0, 'A': 4.0, 'A-': 3.7,
    'B+': 3.3, 'B': 3.0, 'B-': 2.7,
    'C+': 2.3, 'C': 2.0, 'C-': 1.7,
    'D+': 1.3, 'D': 1.0, 'D-': 0.7,
    'F': 0.0
  };

  let totalPoints = 0;
  let totalCredits = 0;

  for (const grade of grades) {
    const course = await mongoose.model('Course').findById(grade.course);
    totalPoints += gradePoints[grade.letterGrade] * course.credits;
    totalCredits += course.credits;
  }

  return totalCredits > 0 ? (totalPoints / totalCredits).toFixed(2) : 0;
};

const Grade = mongoose.model('Grade', gradeSchema);

module.exports = Grade;
