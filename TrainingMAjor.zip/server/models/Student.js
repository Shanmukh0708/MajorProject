const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  studentId: {
    type: String,
    required: true,
    unique: true
  },
  enrolledCourses: [{
    course: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Course'
    },
    enrollmentDate: {
      type: Date,
      default: Date.now
    },
    status: {
      type: String,
      enum: ['active', 'completed', 'dropped'],
      default: 'active'
    }
  }],
  grades: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Grade'
  }],
  attendance: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Attendance'
  }],
  completedAssignments: [{
    assignment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Assignment'
    },
    submissionDate: {
      type: Date,
      default: Date.now
    },
    status: {
      type: String,
      enum: ['submitted', 'graded', 'late', 'missing'],
      default: 'submitted'
    }
  }],
  completedChallenges: [{
    challenge: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Challenge'
    },
    completionDate: Date,
    score: Number
  }],
  academicYear: {
    type: String,
    required: true
  },
  major: {
    type: String,
    required: true
  },
  gpa: {
    type: Number,
    default: 0.0,
    min: 0.0,
    max: 4.0
  },
  skills: [{
    name: String,
    level: {
      type: String,
      enum: ['beginner', 'intermediate', 'advanced'],
      default: 'beginner'
    },
    endorsements: Number
  }],
  achievements: [{
    title: String,
    description: String,
    dateEarned: Date,
    badge: String
  }]
}, {
  timestamps: true
});

// Virtual for full name
studentSchema.virtual('fullName').get(function() {
  return `${this.user.firstName} ${this.user.lastName}`;
});

// Method to calculate GPA
studentSchema.methods.calculateGPA = async function() {
  const grades = await mongoose.model('Grade').find({ student: this._id });
  if (grades.length === 0) return 0;

  const totalPoints = grades.reduce((sum, grade) => sum + grade.score, 0);
  this.gpa = totalPoints / grades.length;
  await this.save();
  return this.gpa;
};

// Method to enroll in a course
studentSchema.methods.enrollCourse = async function(courseId) {
  const exists = this.enrolledCourses.some(
    enrollment => enrollment.course.toString() === courseId.toString()
  );
  
  if (!exists) {
    this.enrolledCourses.push({
      course: courseId,
      enrollmentDate: new Date(),
      status: 'active'
    });
    await this.save();
    return true;
  }
  return false;
};

const Student = mongoose.model('Student', studentSchema);

module.exports = Student;
