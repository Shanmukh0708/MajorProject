const mongoose = require('mongoose');

const assignmentSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  course: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Course',
    required: true
  },
  teacher: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Teacher',
    required: true
  },
  type: {
    type: String,
    enum: ['homework', 'quiz', 'project', 'exam', 'other'],
    required: true
  },
  totalPoints: {
    type: Number,
    required: true,
    min: 0
  },
  dueDate: {
    type: Date,
    required: true
  },
  availableFrom: {
    type: Date,
    required: true
  },
  submissions: [{
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student'
    },
    submittedAt: {
      type: Date,
      default: Date.now
    },
    files: [{
      filename: String,
      fileUrl: String,
      uploadedAt: {
        type: Date,
        default: Date.now
      }
    }],
    grade: {
      score: {
        type: Number,
        min: 0
      },
      feedback: String,
      gradedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Teacher'
      },
      gradedAt: Date,
      status: {
        type: String,
        enum: ['pending', 'graded', 'returned'],
        default: 'pending'
      }
    },
    status: {
      type: String,
      enum: ['draft', 'submitted', 'late', 'graded'],
      default: 'draft'
    }
  }],
  resources: [{
    title: String,
    type: {
      type: String,
      enum: ['document', 'video', 'link', 'other']
    },
    url: String,
    description: String,
    uploadedAt: {
      type: Date,
      default: Date.now
    }
  }],
  rubric: [{
    criterion: String,
    description: String,
    points: Number,
    levels: [{
      level: String,
      description: String,
      points: Number
    }]
  }],
  allowLateSubmissions: {
    type: Boolean,
    default: false
  },
  latePenalty: {
    percentage: {
      type: Number,
      min: 0,
      max: 100,
      default: 0
    },
    perDay: {
      type: Boolean,
      default: true
    },
    maxDaysLate: {
      type: Number,
      min: 0,
      default: 7
    }
  },
  visibility: {
    type: String,
    enum: ['visible', 'hidden'],
    default: 'hidden'
  },
  status: {
    type: String,
    enum: ['draft', 'published', 'closed'],
    default: 'draft'
  }
}, {
  timestamps: true
});

// Virtual for submission count
assignmentSchema.virtual('submissionCount').get(function() {
  return this.submissions.filter(sub => sub.status === 'submitted' || sub.status === 'graded').length;
});

// Virtual for average grade
assignmentSchema.virtual('averageGrade').get(function() {
  const gradedSubmissions = this.submissions.filter(sub => sub.grade && sub.grade.score !== undefined);
  if (gradedSubmissions.length === 0) return 0;
  
  const totalScore = gradedSubmissions.reduce((sum, sub) => sum + sub.grade.score, 0);
  return totalScore / gradedSubmissions.length;
});

// Method to submit assignment
assignmentSchema.methods.submitAssignment = async function(studentId, files) {
  const submission = this.submissions.find(
    sub => sub.student.toString() === studentId.toString()
  );

  const now = new Date();
  const status = now > this.dueDate ? 'late' : 'submitted';

  if (submission) {
    submission.files = files;
    submission.submittedAt = now;
    submission.status = status;
  } else {
    this.submissions.push({
      student: studentId,
      files,
      submittedAt: now,
      status
    });
  }

  await this.save();
  return this.submissions[this.submissions.length - 1];
};

// Method to grade submission
assignmentSchema.methods.gradeSubmission = async function(studentId, gradeData, teacherId) {
  const submission = this.submissions.find(
    sub => sub.student.toString() === studentId.toString()
  );

  if (!submission) {
    throw new Error('Submission not found');
  }

  submission.grade = {
    ...gradeData,
    gradedBy: teacherId,
    gradedAt: new Date(),
    status: 'graded'
  };
  submission.status = 'graded';

  await this.save();
  return submission;
};

// Method to calculate late penalty
assignmentSchema.methods.calculateLatePenalty = function(submissionDate) {
  if (!this.allowLateSubmissions || submissionDate <= this.dueDate) {
    return 0;
  }

  const daysLate = Math.ceil((submissionDate - this.dueDate) / (1000 * 60 * 60 * 24));
  
  if (daysLate > this.latePenalty.maxDaysLate) {
    return 100;
  }

  return this.latePenalty.perDay 
    ? Math.min(daysLate * this.latePenalty.percentage, 100)
    : this.latePenalty.percentage;
};

const Assignment = mongoose.model('Assignment', assignmentSchema);

module.exports = Assignment;
