const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema({
  course: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Course',
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  teacher: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Teacher',
    required: true
  },
  records: [{
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student',
      required: true
    },
    status: {
      type: String,
      enum: ['present', 'absent', 'late', 'excused'],
      required: true
    },
    arrivalTime: Date,
    excuseReason: String,
    excuseDocumentation: String,
    notes: String
  }],
  sessionType: {
    type: String,
    enum: ['lecture', 'lab', 'tutorial', 'seminar', 'other'],
    required: true
  },
  duration: {
    type: Number, // in minutes
    required: true
  },
  startTime: {
    type: Date,
    required: true
  },
  endTime: {
    type: Date,
    required: true
  },
  location: {
    type: String,
    required: true
  },
  isOnline: {
    type: Boolean,
    default: false
  },
  meetingLink: {
    type: String,
    trim: true
  },
  status: {
    type: String,
    enum: ['pending', 'completed', 'cancelled'],
    default: 'pending'
  },
  cancellationReason: String,
  metadata: {
    totalStudents: {
      type: Number,
      default: 0
    },
    presentCount: {
      type: Number,
      default: 0
    },
    absentCount: {
      type: Number,
      default: 0
    },
    lateCount: {
      type: Number,
      default: 0
    },
    excusedCount: {
      type: Number,
      default: 0
    }
  }
}, {
  timestamps: true
});

// Index for efficient querying
attendanceSchema.index({ course: 1, date: 1 });
attendanceSchema.index({ 'records.student': 1, date: 1 });

// Pre-save middleware to update metadata
attendanceSchema.pre('save', function(next) {
  this.metadata.totalStudents = this.records.length;
  this.metadata.presentCount = this.records.filter(r => r.status === 'present').length;
  this.metadata.absentCount = this.records.filter(r => r.status === 'absent').length;
  this.metadata.lateCount = this.records.filter(r => r.status === 'late').length;
  this.metadata.excusedCount = this.records.filter(r => r.status === 'excused').length;
  next();
});

// Virtual for attendance percentage
attendanceSchema.virtual('attendancePercentage').get(function() {
  if (this.metadata.totalStudents === 0) return 0;
  return ((this.metadata.presentCount + this.metadata.lateCount) / this.metadata.totalStudents * 100).toFixed(2);
});

// Method to mark student attendance
attendanceSchema.methods.markAttendance = async function(studentId, status, options = {}) {
  const existingRecord = this.records.find(
    record => record.student.toString() === studentId.toString()
  );

  const attendanceData = {
    student: studentId,
    status,
    ...options
  };

  if (existingRecord) {
    Object.assign(existingRecord, attendanceData);
  } else {
    this.records.push(attendanceData);
  }

  await this.save();
  return this.records.find(record => record.student.toString() === studentId.toString());
};

// Method to bulk mark attendance
attendanceSchema.methods.bulkMarkAttendance = async function(attendanceRecords) {
  for (const record of attendanceRecords) {
    const existingIndex = this.records.findIndex(
      r => r.student.toString() === record.student.toString()
    );

    if (existingIndex !== -1) {
      this.records[existingIndex] = { ...this.records[existingIndex], ...record };
    } else {
      this.records.push(record);
    }
  }

  await this.save();
  return this.records;
};

// Method to get student attendance record
attendanceSchema.methods.getStudentRecord = function(studentId) {
  return this.records.find(
    record => record.student.toString() === studentId.toString()
  );
};

// Static method to get student attendance statistics
attendanceSchema.statics.getStudentStatistics = async function(studentId, courseId) {
  const attendances = await this.find({
    course: courseId,
    'records.student': studentId
  });

  const totalSessions = attendances.length;
  const records = attendances.map(a => 
    a.records.find(r => r.student.toString() === studentId.toString())
  );

  const stats = {
    totalSessions,
    present: records.filter(r => r.status === 'present').length,
    absent: records.filter(r => r.status === 'absent').length,
    late: records.filter(r => r.status === 'late').length,
    excused: records.filter(r => r.status === 'excused').length
  };

  stats.attendancePercentage = totalSessions ? 
    ((stats.present + stats.late) / totalSessions * 100).toFixed(2) : 0;

  return stats;
};

// Static method to get course attendance statistics
attendanceSchema.statics.getCourseStatistics = async function(courseId, startDate, endDate) {
  const query = { course: courseId };
  if (startDate || endDate) {
    query.date = {};
    if (startDate) query.date.$gte = startDate;
    if (endDate) query.date.$lte = endDate;
  }

  const attendances = await this.find(query);

  return {
    totalSessions: attendances.length,
    averageAttendance: attendances.reduce((sum, a) => sum + Number(a.attendancePercentage), 0) / 
      (attendances.length || 1),
    sessionStats: attendances.map(a => ({
      date: a.date,
      attendancePercentage: a.attendancePercentage,
      metadata: a.metadata
    }))
  };
};

const Attendance = mongoose.model('Attendance', attendanceSchema);

module.exports = Attendance;
