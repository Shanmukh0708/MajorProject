const mongoose = require('mongoose');

const teacherSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  teacherId: {
    type: String,
    required: true,
    unique: true
  },
  department: {
    type: String,
    required: true
  },
  courses: [{
    course: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Course'
    },
    role: {
      type: String,
      enum: ['primary', 'assistant', 'substitute'],
      default: 'primary'
    },
    semester: {
      type: String,
      required: true
    }
  }],
  specializations: [{
    type: String,
    required: true
  }],
  qualifications: [{
    degree: {
      type: String,
      required: true
    },
    field: String,
    institution: String,
    year: Number
  }],
  schedule: [{
    day: {
      type: String,
      enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    },
    startTime: String,
    endTime: String,
    course: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Course'
    }
  }],
  officeHours: [{
    day: {
      type: String,
      enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    },
    startTime: String,
    endTime: String,
    location: String
  }],
  publications: [{
    title: String,
    journal: String,
    year: Number,
    url: String
  }],
  ratings: [{
    score: {
      type: Number,
      min: 1,
      max: 5
    },
    comment: String,
    date: {
      type: Date,
      default: Date.now
    },
    anonymous: {
      type: Boolean,
      default: true
    }
  }],
  averageRating: {
    type: Number,
    default: 0
  },
  achievements: [{
    title: String,
    description: String,
    dateEarned: Date,
    category: {
      type: String,
      enum: ['teaching', 'research', 'service', 'other']
    }
  }],
  status: {
    type: String,
    enum: ['active', 'on leave', 'retired', 'terminated'],
    default: 'active'
  }
}, {
  timestamps: true
});

// Virtual for full name
teacherSchema.virtual('fullName').get(function() {
  return `${this.user.firstName} ${this.user.lastName}`;
});

// Method to calculate average rating
teacherSchema.methods.calculateAverageRating = async function() {
  if (this.ratings.length === 0) return 0;
  
  const totalRating = this.ratings.reduce((sum, rating) => sum + rating.score, 0);
  this.averageRating = totalRating / this.ratings.length;
  await this.save();
  return this.averageRating;
};

// Method to add a course
teacherSchema.methods.addCourse = async function(courseData) {
  const exists = this.courses.some(
    course => course.course.toString() === courseData.course.toString() &&
              course.semester === courseData.semester
  );
  
  if (!exists) {
    this.courses.push(courseData);
    await this.save();
    return true;
  }
  return false;
};

// Method to update office hours
teacherSchema.methods.updateOfficeHours = async function(newOfficeHours) {
  this.officeHours = newOfficeHours;
  await this.save();
  return this.officeHours;
};

const Teacher = mongoose.model('Teacher', teacherSchema);

module.exports = Teacher;
