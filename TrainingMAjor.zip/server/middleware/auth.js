const jwt = require('jsonwebtoken');
const User = require('../models/User');
const asyncHandler = require('express-async-handler');

// Protect routes
const protect = asyncHandler(async (req, res, next) => {
  let token;

  // Check if token exists in headers
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    try {
      // Get token from header
      token = req.headers.authorization.split(' ')[1];

      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Get user from token
      req.user = await User.findById(decoded.id).select('-password');

      if (!req.user) {
        res.status(401);
        throw new Error('Not authorized, user not found');
      }

      if (!req.user.isActive) {
        res.status(401);
        throw new Error('User account is deactivated');
      }

      next();
    } catch (error) {
      console.error(error);
      res.status(401);
      throw new Error('Not authorized, token failed');
    }
  }

  if (!token) {
    res.status(401);
    throw new Error('Not authorized, no token');
  }
});

// Role authorization
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      res.status(403);
      throw new Error(
        `User role ${req.user.role} is not authorized to access this route`
      );
    }
    next();
  };
};

// Check if user owns the resource or is admin
const checkOwnership = (model) => async (req, res, next) => {
  try {
    const resource = await model.findById(req.params.id);
    
    if (!resource) {
      res.status(404);
      throw new Error('Resource not found');
    }

    // Allow access if user is admin or resource owner
    if (
      req.user.role === 'admin' ||
      resource.user.toString() === req.user._id.toString()
    ) {
      req.resource = resource;
      next();
    } else {
      res.status(403);
      throw new Error('Not authorized to access this resource');
    }
  } catch (error) {
    next(error);
  }
};

// Rate limiting for specific routes
const rateLimiter = (limit, timeWindow) => {
  const requests = new Map();

  return (req, res, next) => {
    const ip = req.ip;
    const now = Date.now();

    // Clean up old requests
    for (const [key, value] of requests.entries()) {
      if (now - value.timestamp > timeWindow) {
        requests.delete(key);
      }
    }

    // Check current IP's requests
    const ipRequests = requests.get(ip);
    if (ipRequests) {
      if (now - ipRequests.timestamp < timeWindow && ipRequests.count >= limit) {
        res.status(429);
        throw new Error('Too many requests, please try again later');
      } else if (now - ipRequests.timestamp < timeWindow) {
        ipRequests.count++;
      } else {
        requests.set(ip, { count: 1, timestamp: now });
      }
    } else {
      requests.set(ip, { count: 1, timestamp: now });
    }

    next();
  };
};

// Validate request body
const validateRequest = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body);
    if (error) {
      res.status(400);
      throw new Error(error.details[0].message);
    }
    next();
  };
};

// Track last activity
const trackActivity = asyncHandler(async (req, res, next) => {
  if (req.user) {
    req.user.lastLogin = new Date();
    await req.user.save();
  }
  next();
});

// Log API requests
const logRequest = (req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.originalUrl}`);
  next();
};

module.exports = {
  protect,
  authorize,
  checkOwnership,
  rateLimiter,
  validateRequest,
  trackActivity,
  logRequest
};
