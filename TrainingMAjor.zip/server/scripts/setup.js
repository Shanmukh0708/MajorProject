const { MongoClient } = require('mongodb');
const bcrypt = require('bcryptjs');

require('dotenv').config();
const uri = process.env.MONGODB_URI;

async function setupDatabase() {
  try {
    const client = await MongoClient.connect(uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000
    });
    const db = client.db('smart_skill_mentor');

    // Create collections
    await db.createCollection('users');
    await db.createCollection('students');
    await db.createCollection('teachers');
    await db.createCollection('courses');
    await db.createCollection('assignments');
    await db.createCollection('grades');
    await db.createCollection('attendance');

    // Create indexes
    await db.collection('users').createIndex({ email: 1 }, { unique: true });
    await db.collection('students').createIndex({ 'user': 1 }, { unique: true });
    await db.collection('teachers').createIndex({ 'user': 1 }, { unique: true });
    await db.collection('courses').createIndex({ courseCode: 1 }, { unique: true });

    // Create admin user
    const hashedPassword = await bcrypt.hash('admin123', 10);
    await db.collection('users').insertOne({
      email: 'admin@example.com',
      password: hashedPassword,
      firstName: 'Admin',
      lastName: 'User',
      role: 'admin',
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    });

    console.log('Database setup completed successfully!');
    console.log('Admin credentials:');
    console.log('Email: admin@example.com');
    console.log('Password: admin123');

    await client.close();
  } catch (error) {
    console.error('Error setting up database:', error);
  }
}

setupDatabase();
