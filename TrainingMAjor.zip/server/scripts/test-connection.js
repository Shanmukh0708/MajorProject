const { MongoClient } = require('mongodb');
require('dotenv').config();

async function testConnection() {
  const uri = 'mongodb+srv://smart-skill-mentor:GAQi9Kj3EVJEedbl@smartdata.3zkai.mongodb.net/smartskillmentor?retryWrites=true&w=majority&appName=SmartData';
  
  const client = new MongoClient(uri, {
    maxPoolSize: 10,
    connectTimeoutMS: 30000,
    socketTimeoutMS: 45000,
    serverSelectionTimeoutMS: 30000,
    family: 4,
    ssl: true,
    retryWrites: true,
    w: 'majority'
  });

  try {
    console.log('Attempting to connect to MongoDB Atlas...');
    await client.connect();
    console.log('Successfully connected to MongoDB Atlas!');

    // Test database operations
    const database = client.db('smart_skill_mentor');
    const collection = database.collection('test');
    
    // Test write operation
    const testDoc = { test: 'connection', timestamp: new Date() };
    const insertResult = await collection.insertOne(testDoc);
    console.log('Successfully wrote test document:', insertResult);

    // Test read operation
    const findResult = await collection.findOne({ test: 'connection' });
    console.log('Successfully read test document:', findResult);

    // Clean up
    await collection.deleteOne({ test: 'connection' });
    console.log('Successfully cleaned up test document');

  } catch (err) {
    console.error('Error occurred while connecting to MongoDB Atlas:', err);
  } finally {
    await client.close();
    console.log('Connection closed');
  }
}

testConnection().catch(console.error);
