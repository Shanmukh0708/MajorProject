import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  TextField,
  Button,
  Avatar,
  Divider,
  Stack,
  IconButton,
  Alert,
} from '@mui/material';
import {
  Edit as EditIcon,
  Save as SaveIcon,
  Cancel as CancelIcon,
  PhotoCamera as PhotoCameraIcon,
  AdminPanelSettings as AdminIcon,
} from '@mui/icons-material';

// Mock admin data
const adminData = {
  personalInfo: {
    name: 'Admin User',
    email: 'admin@university.edu',
    employeeId: 'ADM001',
    role: 'System Administrator',
    phone: '+1 234-567-8900',
    office: 'Admin Building, Room 101',
    joinDate: '2020-01-15',
  },
  systemAccess: {
    role: 'Super Admin',
    permissions: [
      'User Management',
      'System Configuration',
      'Data Management',
      'Report Generation',
      'Security Settings',
    ],
    lastLogin: '2024-02-15 09:30 AM',
    lastPasswordChange: '2024-01-01',
    twoFactorEnabled: true,
  },
};

const AdminProfile = () => {
  const [editMode, setEditMode] = useState(false);
  const [personalInfo, setPersonalInfo] = useState(adminData.personalInfo);
  const [showAlert, setShowAlert] = useState(false);

  const handleEditToggle = () => {
    setEditMode(!editMode);
    if (!editMode) {
      setShowAlert(false);
    } else {
      setPersonalInfo(adminData.personalInfo);
    }
  };

  const handleSave = () => {
    setEditMode(false);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPersonalInfo(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Admin Profile
      </Typography>

      {showAlert && (
        <Alert severity="success" sx={{ mb: 2 }}>
          Profile updated successfully!
        </Alert>
      )}

      {/* Profile Header */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 3 }}>
          <Box sx={{ position: 'relative' }}>
            <Avatar
              sx={{
                width: 120,
                height: 120,
                bgcolor: 'error.main',
                fontSize: '3rem',
              }}
            >
              <AdminIcon sx={{ fontSize: '3rem' }} />
            </Avatar>
            <IconButton
              sx={{
                position: 'absolute',
                bottom: 0,
                right: 0,
                bgcolor: 'background.paper',
              }}
              size="small"
            >
              <PhotoCameraIcon />
            </IconButton>
          </Box>
          <Box sx={{ flexGrow: 1 }}>
            <Typography variant="h5" gutterBottom>
              {personalInfo.name}
            </Typography>
            <Typography color="text.secondary" gutterBottom>
              {personalInfo.role}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Employee ID: {personalInfo.employeeId}
            </Typography>
          </Box>
          <Button
            variant={editMode ? "outlined" : "contained"}
            startIcon={editMode ? <CancelIcon /> : <EditIcon />}
            onClick={handleEditToggle}
          >
            {editMode ? 'Cancel' : 'Edit Profile'}
          </Button>
          {editMode && (
            <Button
              variant="contained"
              color="success"
              startIcon={<SaveIcon />}
              onClick={handleSave}
            >
              Save
            </Button>
          )}
        </Box>
      </Paper>

      <Grid container spacing={3}>
        {/* Personal Information */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Personal Information
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Stack spacing={2}>
              <TextField
                fullWidth
                label="Full Name"
                name="name"
                value={personalInfo.name}
                onChange={handleChange}
                disabled={!editMode}
              />
              <TextField
                fullWidth
                label="Email"
                name="email"
                value={personalInfo.email}
                onChange={handleChange}
                disabled={!editMode}
              />
              <TextField
                fullWidth
                label="Phone"
                name="phone"
                value={personalInfo.phone}
                onChange={handleChange}
                disabled={!editMode}
              />
              <TextField
                fullWidth
                label="Office"
                name="office"
                value={personalInfo.office}
                onChange={handleChange}
                disabled={!editMode}
              />
              <TextField
                fullWidth
                label="Join Date"
                name="joinDate"
                value={personalInfo.joinDate}
                disabled
              />
            </Stack>
          </Paper>
        </Grid>

        {/* System Access Information */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              System Access
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Stack spacing={2}>
              <Box>
                <Typography variant="subtitle2" color="text.secondary">
                  Role
                </Typography>
                <Typography variant="body1">
                  {adminData.systemAccess.role}
                </Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Permissions
                </Typography>
                <Stack spacing={1}>
                  {adminData.systemAccess.permissions.map((permission, index) => (
                    <Typography key={index} variant="body2">
                      • {permission}
                    </Typography>
                  ))}
                </Stack>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="text.secondary">
                  Last Login
                </Typography>
                <Typography variant="body1">
                  {adminData.systemAccess.lastLogin}
                </Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="text.secondary">
                  Last Password Change
                </Typography>
                <Typography variant="body1">
                  {adminData.systemAccess.lastPasswordChange}
                </Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="text.secondary">
                  Two-Factor Authentication
                </Typography>
                <Typography variant="body1" color="success.main">
                  {adminData.systemAccess.twoFactorEnabled ? 'Enabled' : 'Disabled'}
                </Typography>
              </Box>
            </Stack>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default AdminProfile;
