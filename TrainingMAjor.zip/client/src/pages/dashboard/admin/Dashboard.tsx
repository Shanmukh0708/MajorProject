import React from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Card,
  CardContent,
  LinearProgress,
} from '@mui/material';
import {
  School as SchoolIcon,
  Person as TeacherIcon,
  Group as StudentsIcon,
  Assignment as AssignmentIcon,
} from '@mui/icons-material';

// Mock data for admin dashboard
const dashboardData = {
  overview: {
    totalStudents: 850,
    totalTeachers: 45,
    totalCourses: 32,
    activeAssignments: 128,
  },
  departmentStats: [
    {
      name: 'Computer Science',
      students: 320,
      teachers: 18,
      courses: 12,
      performance: 88,
    },
    {
      name: 'Electrical Engineering',
      students: 280,
      teachers: 15,
      courses: 10,
      performance: 85,
    },
    {
      name: 'Mechanical Engineering',
      students: 250,
      teachers: 12,
      courses: 10,
      performance: 82,
    },
  ],
  recentActivities: [
    {
      type: 'New Registration',
      details: '15 new students registered',
      timestamp: '2 hours ago',
    },
    {
      type: 'Course Update',
      details: 'New course "Advanced AI" added',
      timestamp: '4 hours ago',
    },
    {
      type: 'Performance Alert',
      details: 'Low performance detected in CS201',
      timestamp: '6 hours ago',
    },
  ],
};

const AdminDashboard = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Admin Dashboard
      </Typography>

      {/* Overview Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <StudentsIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h6">Total Students</Typography>
              </Box>
              <Typography variant="h3" color="primary">
                {dashboardData.overview.totalStudents}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Active enrollments
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <TeacherIcon color="secondary" sx={{ mr: 1 }} />
                <Typography variant="h6">Total Teachers</Typography>
              </Box>
              <Typography variant="h3" color="secondary">
                {dashboardData.overview.totalTeachers}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Faculty members
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <SchoolIcon color="success" sx={{ mr: 1 }} />
                <Typography variant="h6">Total Courses</Typography>
              </Box>
              <Typography variant="h3" color="success.main">
                {dashboardData.overview.totalCourses}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Active courses
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <AssignmentIcon color="warning" sx={{ mr: 1 }} />
                <Typography variant="h6">Assignments</Typography>
              </Box>
              <Typography variant="h3" color="warning.main">
                {dashboardData.overview.activeAssignments}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Active assignments
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Department Statistics */}
      <Typography variant="h5" gutterBottom>
        Department Statistics
      </Typography>
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {dashboardData.departmentStats.map((dept, index) => (
          <Grid item xs={12} md={4} key={index}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                {dept.name}
              </Typography>
              <Box sx={{ mb: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body2">Students</Typography>
                  <Typography variant="body2">{dept.students}</Typography>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body2">Teachers</Typography>
                  <Typography variant="body2">{dept.teachers}</Typography>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body2">Courses</Typography>
                  <Typography variant="body2">{dept.courses}</Typography>
                </Box>
              </Box>
              <Typography variant="body2" gutterBottom>
                Overall Performance
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Box sx={{ flexGrow: 1, mr: 1 }}>
                  <LinearProgress
                    variant="determinate"
                    value={dept.performance}
                    sx={{ height: 8, borderRadius: 4 }}
                  />
                </Box>
                <Typography variant="body2" color="text.secondary">
                  {dept.performance}%
                </Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>

      {/* Recent Activities */}
      <Typography variant="h5" gutterBottom>
        Recent Activities
      </Typography>
      <Paper sx={{ p: 3 }}>
        {dashboardData.recentActivities.map((activity, index) => (
          <Box
            key={index}
            sx={{
              py: 2,
              borderBottom: index < dashboardData.recentActivities.length - 1 ? 1 : 0,
              borderColor: 'divider',
            }}
          >
            <Typography variant="subtitle1" gutterBottom>
              {activity.type}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {activity.details}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {activity.timestamp}
            </Typography>
          </Box>
        ))}
      </Paper>
    </Box>
  );
};

export default AdminDashboard;
