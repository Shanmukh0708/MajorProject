import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Switch,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Divider,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  Stack,
  FormControlLabel,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import {
  Security as SecurityIcon,
  AdminPanelSettings as AdminIcon,
  Notifications as NotificationsIcon,
  Language as LanguageIcon,
} from '@mui/icons-material';

const AdminSettings = () => {
  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    userRegistration: true,
    securityAlerts: true,
    darkMode: false,
    language: 'english',
  });

  const [openPasswordDialog, setOpenPasswordDialog] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertSeverity, setAlertSeverity] = useState<'success' | 'error'>('success');

  const handleSettingChange = (setting: string) => (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setSettings({
      ...settings,
      [setting]: event.target.checked,
    });
    showSuccessMessage('Settings updated successfully');
  };

  const handleLanguageChange = (event: any) => {
    setSettings({
      ...settings,
      language: event.target.value,
    });
    showSuccessMessage('Language preference updated');
  };

  const handlePasswordChange = () => {
    setOpenPasswordDialog(false);
    showSuccessMessage('System password updated successfully');
  };

  const showSuccessMessage = (message: string) => {
    setAlertMessage(message);
    setAlertSeverity('success');
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 3000);
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        System Settings
      </Typography>

      {showAlert && (
        <Alert severity={alertSeverity} sx={{ mb: 2 }}>
          {alertMessage}
        </Alert>
      )}

      <Stack spacing={3}>
        {/* Notification Settings */}
        <Paper sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <NotificationsIcon sx={{ mr: 1 }} color="primary" />
            <Typography variant="h6">Notification Preferences</Typography>
          </Box>
          <List>
            <ListItem>
              <ListItemText 
                primary="Email Notifications"
                secondary="Receive important updates via email"
              />
              <ListItemSecondaryAction>
                <Switch
                  edge="end"
                  checked={settings.emailNotifications}
                  onChange={handleSettingChange('emailNotifications')}
                />
              </ListItemSecondaryAction>
            </ListItem>
            <Divider />
            <ListItem>
              <ListItemText
                primary="Push Notifications"
                secondary="Receive notifications in your browser"
              />
              <ListItemSecondaryAction>
                <Switch
                  edge="end"
                  checked={settings.pushNotifications}
                  onChange={handleSettingChange('pushNotifications')}
                />
              </ListItemSecondaryAction>
            </ListItem>
            <Divider />
            <ListItem>
              <ListItemText
                primary="User Registration"
                secondary="Notify on new user registrations"
              />
              <ListItemSecondaryAction>
                <Switch
                  edge="end"
                  checked={settings.userRegistration}
                  onChange={handleSettingChange('userRegistration')}
                />
              </ListItemSecondaryAction>
            </ListItem>
            <Divider />
            <ListItem>
              <ListItemText
                primary="Security Alerts"
                secondary="Receive security-related notifications"
              />
              <ListItemSecondaryAction>
                <Switch
                  edge="end"
                  checked={settings.securityAlerts}
                  onChange={handleSettingChange('securityAlerts')}
                />
              </ListItemSecondaryAction>
            </ListItem>
          </List>
        </Paper>

        {/* Language Settings */}
        <Paper sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <LanguageIcon sx={{ mr: 1 }} color="primary" />
            <Typography variant="h6">Language</Typography>
          </Box>
          <FormControl fullWidth>
            <InputLabel>Language</InputLabel>
            <Select
              value={settings.language}
              label="Language"
              onChange={handleLanguageChange}
            >
              <MenuItem value="english">English</MenuItem>
              <MenuItem value="spanish">Spanish</MenuItem>
              <MenuItem value="french">French</MenuItem>
              <MenuItem value="german">German</MenuItem>
            </Select>
          </FormControl>
        </Paper>

        {/* Change System Password Dialog */}
        <Dialog 
          open={openPasswordDialog} 
          onClose={() => setOpenPasswordDialog(false)}
        >
          <DialogTitle>Change System Password</DialogTitle>
          <DialogContent>
            <Stack spacing={2} sx={{ mt: 1 }}>
              <TextField
                label="Current Password"
                type="password"
                fullWidth
              />
              <TextField
                label="New Password"
                type="password"
                fullWidth
              />
              <TextField
                label="Confirm New Password"
                type="password"
                fullWidth
              />
            </Stack>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenPasswordDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handlePasswordChange} variant="contained" color="primary">
              Update Password
            </Button>
          </DialogActions>
        </Dialog>
      </Stack>
    </Box>
  );
};

export default AdminSettings;
