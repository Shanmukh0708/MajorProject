import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Avatar,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Stack,
  LinearProgress,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  School as SchoolIcon,
  Assignment as AssignmentIcon,
  Grade as GradeIcon,
  Timeline as TimelineIcon,
} from '@mui/icons-material';

// Mock data for students
const studentsData = [
  {
    id: 1,
    name: 'John Doe',
    email: 'john.doe@university.edu',
    studentId: 'STU001',
    department: 'Computer Science',
    year: '3rd Year',
    semester: '6th Semester',
    gpa: 3.85,
    attendance: 92,
    completedCourses: 18,
    ongoingCourses: [
      'Data Structures',
      'Operating Systems',
      'Computer Networks',
    ],
    status: 'active',
    performance: {
      assignments: 88,
      tests: 85,
      projects: 90,
    },
  },
  {
    id: 2,
    name: 'Jane Smith',
    email: 'jane.smith@university.edu',
    studentId: 'STU002',
    department: 'Computer Science',
    year: '3rd Year',
    semester: '6th Semester',
    gpa: 3.92,
    attendance: 95,
    completedCourses: 18,
    ongoingCourses: [
      'Data Structures',
      'Operating Systems',
      'Computer Networks',
    ],
    status: 'active',
    performance: {
      assignments: 92,
      tests: 90,
      projects: 95,
    },
  },
  {
    id: 3,
    name: 'Mike Johnson',
    email: 'mike.johnson@university.edu',
    studentId: 'STU003',
    department: 'Computer Science',
    year: '3rd Year',
    semester: '6th Semester',
    gpa: 3.45,
    attendance: 78,
    completedCourses: 16,
    ongoingCourses: [
      'Data Structures',
      'Operating Systems',
      'Computer Networks',
    ],
    status: 'warning',
    performance: {
      assignments: 75,
      tests: 72,
      projects: 80,
    },
  },
];

const AdminStudents = () => {
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [filterDepartment, setFilterDepartment] = useState('all');
  const [filterYear, setFilterYear] = useState('all');

  const handleOpenDialog = (student?: any) => {
    setSelectedStudent(student || null);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedStudent(null);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'success';
      case 'warning':
        return 'warning';
      case 'inactive':
        return 'error';
      default:
        return 'default';
    }
  };

  const getGPAColor = (gpa: number) => {
    if (gpa >= 3.5) return 'success.main';
    if (gpa >= 3.0) return 'primary.main';
    if (gpa >= 2.5) return 'warning.main';
    return 'error.main';
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">Student Management</Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <FormControl sx={{ minWidth: 200 }}>
            <InputLabel>Department</InputLabel>
            <Select
              value={filterDepartment}
              label="Department"
              onChange={(e) => setFilterDepartment(e.target.value)}
            >
              <MenuItem value="all">All Departments</MenuItem>
              <MenuItem value="cs">Computer Science</MenuItem>
              <MenuItem value="ee">Electrical Engineering</MenuItem>
              <MenuItem value="me">Mechanical Engineering</MenuItem>
            </Select>
          </FormControl>
          <FormControl sx={{ minWidth: 120 }}>
            <InputLabel>Year</InputLabel>
            <Select
              value={filterYear}
              label="Year"
              onChange={(e) => setFilterYear(e.target.value)}
            >
              <MenuItem value="all">All Years</MenuItem>
              <MenuItem value="1">1st Year</MenuItem>
              <MenuItem value="2">2nd Year</MenuItem>
              <MenuItem value="3">3rd Year</MenuItem>
              <MenuItem value="4">4th Year</MenuItem>
            </Select>
          </FormControl>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => handleOpenDialog()}
          >
            Add Student
          </Button>
        </Box>
      </Box>

      <Grid container spacing={3}>
        {studentsData.map((student) => (
          <Grid item xs={12} md={4} key={student.id}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Avatar
                    sx={{
                      width: 56,
                      height: 56,
                      bgcolor: 'primary.main',
                      mr: 2,
                    }}
                  >
                    {student.name.charAt(0)}
                  </Avatar>
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="h6">{student.name}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {student.studentId}
                    </Typography>
                  </Box>
                  <Chip
                    label={student.status.charAt(0).toUpperCase() + student.status.slice(1)}
                    color={getStatusColor(student.status)}
                    size="small"
                  />
                </Box>

                <Stack spacing={2}>
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Academic Info
                    </Typography>
                    <Typography variant="body1">
                      {student.department} • {student.year}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {student.semester}
                    </Typography>
                  </Box>

                  <Box>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      GPA
                    </Typography>
                    <Typography variant="h4" sx={{ color: getGPAColor(student.gpa) }}>
                      {student.gpa}
                    </Typography>
                  </Box>

                  <Box>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Performance Metrics
                    </Typography>
                    <Stack spacing={1}>
                      <Box>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography variant="body2">Assignments</Typography>
                          <Typography variant="body2">{student.performance.assignments}%</Typography>
                        </Box>
                        <LinearProgress
                          variant="determinate"
                          value={student.performance.assignments}
                          sx={{ height: 6, borderRadius: 3 }}
                        />
                      </Box>
                      <Box>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography variant="body2">Tests</Typography>
                          <Typography variant="body2">{student.performance.tests}%</Typography>
                        </Box>
                        <LinearProgress
                          variant="determinate"
                          value={student.performance.tests}
                          sx={{ height: 6, borderRadius: 3 }}
                        />
                      </Box>
                      <Box>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography variant="body2">Projects</Typography>
                          <Typography variant="body2">{student.performance.projects}%</Typography>
                        </Box>
                        <LinearProgress
                          variant="determinate"
                          value={student.performance.projects}
                          sx={{ height: 6, borderRadius: 3 }}
                        />
                      </Box>
                    </Stack>
                  </Box>

                  <Box>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Current Courses
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {student.ongoingCourses.map((course, index) => (
                        <Chip
                          key={index}
                          label={course}
                          size="small"
                          variant="outlined"
                        />
                      ))}
                    </Box>
                  </Box>

                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <SchoolIcon color="action" sx={{ mr: 1 }} />
                      <Typography variant="body2">
                        {student.completedCourses} Completed
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <TimelineIcon color="action" sx={{ mr: 1 }} />
                      <Typography variant="body2">
                        {student.attendance}% Attendance
                      </Typography>
                    </Box>
                  </Box>
                </Stack>
              </CardContent>
              <CardActions>
                <Button
                  size="small"
                  startIcon={<EditIcon />}
                  onClick={() => handleOpenDialog(student)}
                >
                  Edit
                </Button>
                <Button
                  size="small"
                  startIcon={<GradeIcon />}
                >
                  Grades
                </Button>
                <Button
                  size="small"
                  color="error"
                  startIcon={<DeleteIcon />}
                >
                  Remove
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Add/Edit Student Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {selectedStudent ? 'Edit Student' : 'Add New Student'}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={3} sx={{ mt: 2 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Full Name"
                  defaultValue={selectedStudent?.name}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Email"
                  type="email"
                  defaultValue={selectedStudent?.email}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Student ID"
                  defaultValue={selectedStudent?.studentId}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Department</InputLabel>
                  <Select
                    defaultValue={selectedStudent?.department || ''}
                    label="Department"
                  >
                    <MenuItem value="Computer Science">Computer Science</MenuItem>
                    <MenuItem value="Electrical Engineering">Electrical Engineering</MenuItem>
                    <MenuItem value="Mechanical Engineering">Mechanical Engineering</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Year</InputLabel>
                  <Select
                    defaultValue={selectedStudent?.year || ''}
                    label="Year"
                  >
                    <MenuItem value="1st Year">1st Year</MenuItem>
                    <MenuItem value="2nd Year">2nd Year</MenuItem>
                    <MenuItem value="3rd Year">3rd Year</MenuItem>
                    <MenuItem value="4th Year">4th Year</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Semester</InputLabel>
                  <Select
                    defaultValue={selectedStudent?.semester || ''}
                    label="Semester"
                  >
                    <MenuItem value="1st Semester">1st Semester</MenuItem>
                    <MenuItem value="2nd Semester">2nd Semester</MenuItem>
                    <MenuItem value="3rd Semester">3rd Semester</MenuItem>
                    <MenuItem value="4th Semester">4th Semester</MenuItem>
                    <MenuItem value="5th Semester">5th Semester</MenuItem>
                    <MenuItem value="6th Semester">6th Semester</MenuItem>
                    <MenuItem value="7th Semester">7th Semester</MenuItem>
                    <MenuItem value="8th Semester">8th Semester</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Status</InputLabel>
                  <Select
                    defaultValue={selectedStudent?.status || 'active'}
                    label="Status"
                  >
                    <MenuItem value="active">Active</MenuItem>
                    <MenuItem value="warning">Warning</MenuItem>
                    <MenuItem value="inactive">Inactive</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
            </Grid>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button variant="contained" onClick={handleCloseDialog}>
            {selectedStudent ? 'Save Changes' : 'Add Student'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AdminStudents;
