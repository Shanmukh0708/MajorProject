import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Avatar,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Stack,
  IconButton,
  Rating,
  Divider,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  School as SchoolIcon,
  Class as ClassIcon,
  Assessment as AssessmentIcon,
} from '@mui/icons-material';

// Mock data for teachers
const teachersData = [
  {
    id: 1,
    name: 'Dr. Sarah Johnson',
    email: 'sarah.johnson@university.edu',
    department: 'Computer Science',
    designation: 'Associate Professor',
    specialization: 'Data Structures and Algorithms',
    experience: '8 years',
    rating: 4.8,
    classes: ['Data Structures', 'Algorithms', 'Advanced Programming'],
    students: 85,
    status: 'active',
  },
  {
    id: 2,
    name: 'Prof. Michael Chen',
    email: 'michael.chen@university.edu',
    department: 'Computer Science',
    designation: 'Professor',
    specialization: 'Operating Systems',
    experience: '12 years',
    rating: 4.6,
    classes: ['Operating Systems', 'System Programming', 'Computer Architecture'],
    students: 92,
    status: 'active',
  },
  {
    id: 3,
    name: 'Dr. Emily Brown',
    email: 'emily.brown@university.edu',
    department: 'Computer Science',
    designation: 'Assistant Professor',
    specialization: 'Computer Networks',
    experience: '5 years',
    rating: 4.5,
    classes: ['Computer Networks', 'Network Security', 'Cloud Computing'],
    students: 78,
    status: 'active',
  },
];

const AdminTeachers = () => {
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedTeacher, setSelectedTeacher] = useState<any>(null);
  const [filterDepartment, setFilterDepartment] = useState('all');

  const handleOpenDialog = (teacher?: any) => {
    setSelectedTeacher(teacher || null);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedTeacher(null);
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">Teacher Management</Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <FormControl sx={{ minWidth: 200 }}>
            <InputLabel>Filter by Department</InputLabel>
            <Select
              value={filterDepartment}
              label="Filter by Department"
              onChange={(e) => setFilterDepartment(e.target.value)}
            >
              <MenuItem value="all">All Departments</MenuItem>
              <MenuItem value="cs">Computer Science</MenuItem>
              <MenuItem value="ee">Electrical Engineering</MenuItem>
              <MenuItem value="me">Mechanical Engineering</MenuItem>
            </Select>
          </FormControl>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => handleOpenDialog()}
          >
            Add Teacher
          </Button>
        </Box>
      </Box>

      <Grid container spacing={3}>
        {teachersData.map((teacher) => (
          <Grid item xs={12} md={4} key={teacher.id}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Avatar
                    sx={{
                      width: 56,
                      height: 56,
                      bgcolor: 'primary.main',
                      mr: 2,
                    }}
                  >
                    {teacher.name.charAt(0)}
                  </Avatar>
                  <Box>
                    <Typography variant="h6">{teacher.name}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {teacher.designation}
                    </Typography>
                  </Box>
                </Box>

                <Stack spacing={2}>
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Department
                    </Typography>
                    <Typography variant="body1">
                      {teacher.department}
                    </Typography>
                  </Box>

                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Specialization
                    </Typography>
                    <Typography variant="body1">
                      {teacher.specialization}
                    </Typography>
                  </Box>

                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Experience
                    </Typography>
                    <Typography variant="body1">
                      {teacher.experience}
                    </Typography>
                  </Box>

                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Rating
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Rating value={teacher.rating} precision={0.1} readOnly />
                      <Typography variant="body2" sx={{ ml: 1 }}>
                        ({teacher.rating})
                      </Typography>
                    </Box>
                  </Box>

                  <Divider />

                  <Box>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Current Classes
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {teacher.classes.map((className, index) => (
                        <Chip
                          key={index}
                          label={className}
                          size="small"
                          variant="outlined"
                        />
                      ))}
                    </Box>
                  </Box>

                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <SchoolIcon color="action" sx={{ mr: 1 }} />
                      <Typography variant="body2">
                        {teacher.students} Students
                      </Typography>
                    </Box>
                    <Chip
                      label={teacher.status.charAt(0).toUpperCase() + teacher.status.slice(1)}
                      color={teacher.status === 'active' ? 'success' : 'error'}
                      size="small"
                    />
                  </Box>
                </Stack>
              </CardContent>
              <CardActions>
                <Button
                  size="small"
                  startIcon={<EditIcon />}
                  onClick={() => handleOpenDialog(teacher)}
                >
                  Edit
                </Button>
                <Button
                  size="small"
                  color="error"
                  startIcon={<DeleteIcon />}
                >
                  Remove
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Add/Edit Teacher Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {selectedTeacher ? 'Edit Teacher' : 'Add New Teacher'}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={3} sx={{ mt: 2 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Full Name"
                  defaultValue={selectedTeacher?.name}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Email"
                  type="email"
                  defaultValue={selectedTeacher?.email}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Department</InputLabel>
                  <Select
                    defaultValue={selectedTeacher?.department || ''}
                    label="Department"
                  >
                    <MenuItem value="Computer Science">Computer Science</MenuItem>
                    <MenuItem value="Electrical Engineering">Electrical Engineering</MenuItem>
                    <MenuItem value="Mechanical Engineering">Mechanical Engineering</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Designation</InputLabel>
                  <Select
                    defaultValue={selectedTeacher?.designation || ''}
                    label="Designation"
                  >
                    <MenuItem value="Professor">Professor</MenuItem>
                    <MenuItem value="Associate Professor">Associate Professor</MenuItem>
                    <MenuItem value="Assistant Professor">Assistant Professor</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Specialization"
                  defaultValue={selectedTeacher?.specialization}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Experience"
                  defaultValue={selectedTeacher?.experience}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Status</InputLabel>
                  <Select
                    defaultValue={selectedTeacher?.status || 'active'}
                    label="Status"
                  >
                    <MenuItem value="active">Active</MenuItem>
                    <MenuItem value="inactive">Inactive</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
            </Grid>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button variant="contained" onClick={handleCloseDialog}>
            {selectedTeacher ? 'Save Changes' : 'Add Teacher'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AdminTeachers;
