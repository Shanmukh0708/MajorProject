import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Stack,
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
} from '@mui/material';
import {
  Download as DownloadIcon,
  Print as PrintIcon,
  Share as ShareIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  RemoveRedEye as ViewIcon,
} from '@mui/icons-material';

// Mock data for reports
const reportsData = {
  overview: {
    totalStudents: 850,
    activeStudents: 820,
    averageGPA: 3.45,
    attendanceRate: 88,
    passRate: 92,
    dropoutRate: 3,
  },
  departmentPerformance: [
    {
      department: 'Computer Science',
      students: 320,
      averageGPA: 3.65,
      attendanceRate: 90,
      passRate: 94,
      trend: 'up',
    },
    {
      department: 'Electrical Engineering',
      students: 280,
      averageGPA: 3.45,
      attendanceRate: 87,
      passRate: 91,
      trend: 'up',
    },
    {
      department: 'Mechanical Engineering',
      students: 250,
      averageGPA: 3.25,
      attendanceRate: 85,
      passRate: 89,
      trend: 'down',
    },
  ],
  coursePerformance: [
    {
      course: 'Data Structures',
      department: 'Computer Science',
      students: 85,
      averageGrade: 88,
      passRate: 95,
      highestGrade: 98,
      lowestGrade: 65,
    },
    {
      course: 'Operating Systems',
      department: 'Computer Science',
      students: 78,
      averageGrade: 82,
      passRate: 92,
      highestGrade: 96,
      lowestGrade: 60,
    },
    {
      course: 'Computer Networks',
      department: 'Computer Science',
      students: 72,
      averageGrade: 85,
      passRate: 94,
      highestGrade: 97,
      lowestGrade: 62,
    },
  ],
};

const AdminReports = () => {
  const [timeRange, setTimeRange] = useState('semester');
  const [department, setDepartment] = useState('all');

  const getTrendIcon = (trend: string) => {
    return trend === 'up' ? (
      <TrendingUpIcon color="success" />
    ) : (
      <TrendingDownIcon color="error" />
    );
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">Academic Reports</Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <FormControl sx={{ minWidth: 200 }}>
            <InputLabel>Time Range</InputLabel>
            <Select
              value={timeRange}
              label="Time Range"
              onChange={(e) => setTimeRange(e.target.value)}
            >
              <MenuItem value="semester">Current Semester</MenuItem>
              <MenuItem value="year">Academic Year</MenuItem>
              <MenuItem value="all">All Time</MenuItem>
            </Select>
          </FormControl>
          <FormControl sx={{ minWidth: 200 }}>
            <InputLabel>Department</InputLabel>
            <Select
              value={department}
              label="Department"
              onChange={(e) => setDepartment(e.target.value)}
            >
              <MenuItem value="all">All Departments</MenuItem>
              <MenuItem value="cs">Computer Science</MenuItem>
              <MenuItem value="ee">Electrical Engineering</MenuItem>
              <MenuItem value="me">Mechanical Engineering</MenuItem>
            </Select>
          </FormControl>
          <Button
            variant="contained"
            startIcon={<DownloadIcon />}
          >
            Export Report
          </Button>
        </Box>
      </Box>

      {/* Overview Statistics */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Student Performance
              </Typography>
              <Typography variant="h3" color="primary" gutterBottom>
                {reportsData.overview.averageGPA}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Average GPA
              </Typography>
              <LinearProgress
                variant="determinate"
                value={(reportsData.overview.averageGPA / 4) * 100}
                sx={{ mt: 2, height: 8, borderRadius: 4 }}
              />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Attendance Rate
              </Typography>
              <Typography variant="h3" color="success.main" gutterBottom>
                {reportsData.overview.attendanceRate}%
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Overall attendance
              </Typography>
              <LinearProgress
                variant="determinate"
                value={reportsData.overview.attendanceRate}
                color="success"
                sx={{ mt: 2, height: 8, borderRadius: 4 }}
              />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Pass Rate
              </Typography>
              <Typography variant="h3" color="info.main" gutterBottom>
                {reportsData.overview.passRate}%
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Course completion rate
              </Typography>
              <LinearProgress
                variant="determinate"
                value={reportsData.overview.passRate}
                color="info"
                sx={{ mt: 2, height: 8, borderRadius: 4 }}
              />
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Department Performance */}
      <Paper sx={{ p: 3, mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h6">Department Performance</Typography>
          <Box>
            <IconButton size="small">
              <PrintIcon />
            </IconButton>
            <IconButton size="small">
              <ShareIcon />
            </IconButton>
            <IconButton size="small">
              <DownloadIcon />
            </IconButton>
          </Box>
        </Box>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Department</TableCell>
                <TableCell align="center">Students</TableCell>
                <TableCell align="center">Average GPA</TableCell>
                <TableCell align="center">Attendance</TableCell>
                <TableCell align="center">Pass Rate</TableCell>
                <TableCell align="center">Trend</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {reportsData.departmentPerformance.map((dept) => (
                <TableRow key={dept.department}>
                  <TableCell>{dept.department}</TableCell>
                  <TableCell align="center">{dept.students}</TableCell>
                  <TableCell align="center">{dept.averageGPA}</TableCell>
                  <TableCell align="center">{dept.attendanceRate}%</TableCell>
                  <TableCell align="center">{dept.passRate}%</TableCell>
                  <TableCell align="center">{getTrendIcon(dept.trend)}</TableCell>
                  <TableCell align="center">
                    <IconButton size="small">
                      <ViewIcon />
                    </IconButton>
                    <IconButton size="small">
                      <DownloadIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Course Performance */}
      <Paper sx={{ p: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h6">Course Performance</Typography>
          <Box>
            <IconButton size="small">
              <PrintIcon />
            </IconButton>
            <IconButton size="small">
              <ShareIcon />
            </IconButton>
            <IconButton size="small">
              <DownloadIcon />
            </IconButton>
          </Box>
        </Box>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Course</TableCell>
                <TableCell>Department</TableCell>
                <TableCell align="center">Students</TableCell>
                <TableCell align="center">Average Grade</TableCell>
                <TableCell align="center">Pass Rate</TableCell>
                <TableCell align="center">Grade Range</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {reportsData.coursePerformance.map((course) => (
                <TableRow key={course.course}>
                  <TableCell>{course.course}</TableCell>
                  <TableCell>{course.department}</TableCell>
                  <TableCell align="center">{course.students}</TableCell>
                  <TableCell align="center">{course.averageGrade}%</TableCell>
                  <TableCell align="center">{course.passRate}%</TableCell>
                  <TableCell align="center">
                    {course.lowestGrade}% - {course.highestGrade}%
                  </TableCell>
                  <TableCell align="center">
                    <IconButton size="small">
                      <ViewIcon />
                    </IconButton>
                    <IconButton size="small">
                      <DownloadIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    </Box>
  );
};

export default AdminReports;
