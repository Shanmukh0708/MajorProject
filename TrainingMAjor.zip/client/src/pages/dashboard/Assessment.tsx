import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Stepper,
  Step,
  StepLabel,
  Button,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormControl,
  FormLabel,
  Alert
} from '@mui/material';
import DashboardLayout from '../../components/dashboard/DashboardLayout';

// Mock assessment questions
const assessmentQuestions = [
  {
    question: 'What is the primary purpose of React hooks?',
    options: [
      'To add state to functional components',
      'To create class components',
      'To style components',
      'To handle routing'
    ],
    correctAnswer: 0
  },
  {
    question: 'Which of the following is a core principle of RESTful APIs?',
    options: [
      'All requests must use XML',
      'Statelessness',
      'Only supports GET requests',
      'Requires authentication'
    ],
    correctAnswer: 1
  },
  {
    question: 'What is the purpose of TypeScript?',
    options: [
      'To replace JavaScript completely',
      'To add static typing to JavaScript',
      'To create mobile applications',
      'To handle server-side logic'
    ],
    correctAnswer: 1
  }
];

const Assessment = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);

  const handleAnswer = (answer: number) => {
    const newAnswers = [...answers];
    newAnswers[activeStep] = answer;
    setAnswers(newAnswers);
  };

  const handleNext = () => {
    if (activeStep === assessmentQuestions.length - 1) {
      // Calculate score
      const correctAnswers = answers.reduce((acc, answer, index) => {
        return acc + (answer === assessmentQuestions[index].correctAnswer ? 1 : 0);
      }, 0);
      setScore((correctAnswers / assessmentQuestions.length) * 100);
      setShowResults(true);
    } else {
      setActiveStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
    setAnswers([]);
    setShowResults(false);
    setScore(0);
  };

  return (
    <DashboardLayout>
      <Box sx={{ maxWidth: 800, mx: 'auto', p: 3 }}>
        <Typography variant="h4" gutterBottom>
          Skill Assessment
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" paragraph>
          Test your knowledge to get personalized learning recommendations
        </Typography>

        {!showResults ? (
          <Paper sx={{ p: 3, mt: 3 }}>
            <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
              {assessmentQuestions.map((_, index) => (
                <Step key={index}>
                  <StepLabel>Q{index + 1}</StepLabel>
                </Step>
              ))}
            </Stepper>

            <FormControl component="fieldset" sx={{ width: '100%' }}>
              <FormLabel component="legend" sx={{ mb: 2 }}>
                <Typography variant="h6">
                  {assessmentQuestions[activeStep].question}
                </Typography>
              </FormLabel>
              <RadioGroup
                value={answers[activeStep] ?? ''}
                onChange={(e) => handleAnswer(Number(e.target.value))}
              >
                {assessmentQuestions[activeStep].options.map((option, index) => (
                  <FormControlLabel
                    key={index}
                    value={index}
                    control={<Radio />}
                    label={option}
                    sx={{ mb: 1 }}
                  />
                ))}
              </RadioGroup>
            </FormControl>

            <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
              <Button
                disabled={activeStep === 0}
                onClick={handleBack}
              >
                Back
              </Button>
              <Button
                variant="contained"
                onClick={handleNext}
                disabled={answers[activeStep] === undefined}
              >
                {activeStep === assessmentQuestions.length - 1 ? 'Finish' : 'Next'}
              </Button>
            </Box>
          </Paper>
        ) : (
          <Paper sx={{ p: 3, mt: 3 }}>
            <Typography variant="h5" gutterBottom>
              Assessment Complete!
            </Typography>
            <Alert severity="success" sx={{ mb: 3 }}>
              Your score: {score.toFixed(1)}%
            </Alert>
            <Typography variant="body1" paragraph>
              Based on your results, we recommend focusing on the following areas:
            </Typography>
            <Box sx={{ mb: 3 }}>
              {score < 70 && (
                <>
                  <Typography variant="body1" sx={{ mb: 1 }}>
                    • Review React fundamentals and hooks
                  </Typography>
                  <Typography variant="body1" sx={{ mb: 1 }}>
                    • Study RESTful API principles
                  </Typography>
                  <Typography variant="body1">
                    • Learn TypeScript basics
                  </Typography>
                </>
              )}
              {score >= 70 && score < 90 && (
                <>
                  <Typography variant="body1" sx={{ mb: 1 }}>
                    • Advanced React patterns
                  </Typography>
                  <Typography variant="body1" sx={{ mb: 1 }}>
                    • API security best practices
                  </Typography>
                  <Typography variant="body1">
                    • Advanced TypeScript features
                  </Typography>
                </>
              )}
              {score >= 90 && (
                <>
                  <Typography variant="body1" sx={{ mb: 1 }}>
                    • Expert-level React optimization
                  </Typography>
                  <Typography variant="body1" sx={{ mb: 1 }}>
                    • Microservices architecture
                  </Typography>
                  <Typography variant="body1">
                    • TypeScript compiler API
                  </Typography>
                </>
              )}
            </Box>
            <Button variant="contained" onClick={handleReset}>
              Take Another Assessment
            </Button>
          </Paper>
        )}
      </Box>
    </DashboardLayout>
  );
};

export default Assessment;
