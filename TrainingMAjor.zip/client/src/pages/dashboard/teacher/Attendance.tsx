import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Chip,
  IconButton,
  Grid,
  Card,
  CardContent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  ToggleButton,
  ToggleButtonGroup,
} from '@mui/material';
import {
  CheckCircle as PresentIcon,
  Cancel as AbsentIcon,
  Timer as LateIcon,
  CalendarToday as CalendarIcon,
  Edit as EditIcon,
  Assessment as ReportIcon,
} from '@mui/icons-material';

// Mock data for attendance
const attendanceData = {
  classes: [
    {
      id: 1,
      name: 'Data Structures',
      code: 'CS201',
      schedule: 'Mon, Wed 10:00 AM',
      totalClasses: 24,
      attendanceRate: 92,
    },
    {
      id: 2,
      name: 'Operating Systems',
      code: 'CS301',
      schedule: 'Tue, Thu 2:00 PM',
      totalClasses: 22,
      attendanceRate: 88,
    },
    {
      id: 3,
      name: 'Computer Networks',
      code: 'CS401',
      schedule: 'Wed, Fri 11:00 AM',
      totalClasses: 20,
      attendanceRate: 90,
    },
  ],
  students: [
    {
      id: 1,
      name: 'John Doe',
      rollNo: 'CS001',
      attendance: 'present',
      totalPresent: 22,
      totalAbsent: 2,
      totalLate: 0,
      attendanceRate: 92,
    },
    {
      id: 2,
      name: 'Jane Smith',
      rollNo: 'CS002',
      attendance: 'late',
      totalPresent: 20,
      totalAbsent: 2,
      totalLate: 2,
      attendanceRate: 88,
    },
    {
      id: 3,
      name: 'Mike Johnson',
      rollNo: 'CS003',
      attendance: 'absent',
      totalPresent: 18,
      totalAbsent: 4,
      totalLate: 2,
      attendanceRate: 82,
    },
  ],
};

const TeacherAttendance = () => {
  const [selectedClass, setSelectedClass] = useState('');
  const [openAttendanceDialog, setOpenAttendanceDialog] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const getAttendanceColor = (status: string) => {
    switch (status) {
      case 'present':
        return 'success';
      case 'absent':
        return 'error';
      case 'late':
        return 'warning';
      default:
        return 'default';
    }
  };

  const getAttendanceIcon = (status: string) => {
    switch (status) {
      case 'present':
        return PresentIcon;
      case 'absent':
        return AbsentIcon;
      case 'late':
        return LateIcon;
      default:
        return PresentIcon;
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">Attendance Management</Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <FormControl sx={{ minWidth: 200 }}>
            <InputLabel>Select Class</InputLabel>
            <Select
              value={selectedClass}
              label="Select Class"
              onChange={(e) => setSelectedClass(e.target.value)}
            >
              {attendanceData.classes.map((cls) => (
                <MenuItem key={cls.id} value={cls.id}>
                  {cls.name} ({cls.code})
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <Button
            variant="contained"
            startIcon={<CalendarIcon />}
            onClick={() => setOpenAttendanceDialog(true)}
          >
            Take Attendance
          </Button>
        </Box>
      </Box>

      {/* Class Statistics */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {attendanceData.classes.map((cls) => (
          <Grid item xs={12} md={4} key={cls.id}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  {cls.name}
                </Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  {cls.code} • {cls.schedule}
                </Typography>
                <Box sx={{ mt: 2 }}>
                  <Typography variant="body2" gutterBottom>
                    Total Classes: {cls.totalClasses}
                  </Typography>
                  <Typography variant="h5" color="primary">
                    {cls.attendanceRate}%
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Average Attendance Rate
                  </Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Attendance Table */}
      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Student Name</TableCell>
                <TableCell>Roll No</TableCell>
                <TableCell align="center">Today's Status</TableCell>
                <TableCell align="center">Present</TableCell>
                <TableCell align="center">Absent</TableCell>
                <TableCell align="center">Late</TableCell>
                <TableCell align="center">Attendance Rate</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {attendanceData.students.map((student) => (
                <TableRow key={student.id}>
                  <TableCell>{student.name}</TableCell>
                  <TableCell>{student.rollNo}</TableCell>
                  <TableCell align="center">
                    <Chip
                      icon={<Box component={getAttendanceIcon(student.attendance)} />}
                      label={student.attendance.charAt(0).toUpperCase() + student.attendance.slice(1)}
                      color={getAttendanceColor(student.attendance)}
                      size="small"
                    />
                  </TableCell>
                  <TableCell align="center">{student.totalPresent}</TableCell>
                  <TableCell align="center">{student.totalAbsent}</TableCell>
                  <TableCell align="center">{student.totalLate}</TableCell>
                  <TableCell align="center">
                    <Typography
                      color={student.attendanceRate >= 85 ? 'success.main' : 'error.main'}
                    >
                      {student.attendanceRate}%
                    </Typography>
                  </TableCell>
                  <TableCell align="center">
                    <IconButton size="small" color="primary">
                      <EditIcon />
                    </IconButton>
                    <IconButton size="small" color="primary">
                      <ReportIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Take Attendance Dialog */}
      <Dialog
        open={openAttendanceDialog}
        onClose={() => setOpenAttendanceDialog(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Take Attendance - {new Date(selectedDate).toLocaleDateString()}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2 }}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Student Name</TableCell>
                  <TableCell>Roll No</TableCell>
                  <TableCell align="center">Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {attendanceData.students.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell>{student.name}</TableCell>
                    <TableCell>{student.rollNo}</TableCell>
                    <TableCell align="center">
                      <ToggleButtonGroup
                        value={student.attendance}
                        exclusive
                        size="small"
                      >
                        <ToggleButton value="present" color="success">
                          <PresentIcon />
                        </ToggleButton>
                        <ToggleButton value="late" color="warning">
                          <LateIcon />
                        </ToggleButton>
                        <ToggleButton value="absent" color="error">
                          <AbsentIcon />
                        </ToggleButton>
                      </ToggleButtonGroup>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenAttendanceDialog(false)}>Cancel</Button>
          <Button variant="contained" onClick={() => setOpenAttendanceDialog(false)}>
            Save Attendance
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default TeacherAttendance;
