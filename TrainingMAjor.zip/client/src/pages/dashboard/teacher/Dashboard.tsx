import React, { useState } from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  LinearProgress,
  Card,
  CardContent,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Button,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  Visibility as ViewIcon,
  Grade as GradeIcon,
  Assignment as AssignmentIcon,
  Person as StudentIcon,
  Class as ClassIcon,
  Assessment as AssessmentIcon,
} from '@mui/icons-material';

// Mock data for teacher dashboard
const classStats = {
  totalStudents: 45,
  averageGrade: 85,
  assignmentsSubmitted: 156,
  upcomingTests: 3,
};

const studentProgress = [
  {
    id: 1,
    name: 'John Doe',
    studentId: 'STU001',
    attendance: 95,
    overallGrade: 88,
    recentActivity: 'Submitted Assignment: Data Structures',
    status: 'Active',
    subjects: [
      { name: 'Data Structures', progress: 85, grade: 'A' },
      { name: 'Operating Systems', progress: 78, grade: 'B+' },
      { name: 'Computer Networks', progress: 92, grade: 'A' },
    ],
  },
  {
    id: 2,
    name: 'Jane Smith',
    studentId: 'STU002',
    attendance: 88,
    overallGrade: 92,
    recentActivity: 'Completed Test: Operating Systems',
    status: 'Active',
    subjects: [
      { name: 'Data Structures', progress: 90, grade: 'A' },
      { name: 'Operating Systems', progress: 95, grade: 'A' },
      { name: 'Computer Networks', progress: 88, grade: 'A-' },
    ],
  },
  {
    id: 3,
    name: 'Mike Johnson',
    studentId: 'STU003',
    attendance: 75,
    overallGrade: 72,
    recentActivity: 'Missed Assignment: Computer Networks',
    status: 'At Risk',
    subjects: [
      { name: 'Data Structures', progress: 65, grade: 'C' },
      { name: 'Operating Systems', progress: 70, grade: 'C+' },
      { name: 'Computer Networks', progress: 68, grade: 'C+' },
    ],
  },
];

const TeacherDashboard = () => {
  const [selectedClass, setSelectedClass] = useState('all');

  const getStatusColor = (status: string) => {
    return status === 'Active' ? 'success' : 'error';
  };

  const getGradeColor = (grade: number) => {
    if (grade >= 90) return 'success';
    if (grade >= 80) return 'primary';
    if (grade >= 70) return 'warning';
    return 'error';
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">Teacher Dashboard</Typography>
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Select Class</InputLabel>
          <Select
            value={selectedClass}
            label="Select Class"
            onChange={(e) => setSelectedClass(e.target.value)}
          >
            <MenuItem value="all">All Classes</MenuItem>
            <MenuItem value="ds">Data Structures</MenuItem>
            <MenuItem value="os">Operating Systems</MenuItem>
            <MenuItem value="cn">Computer Networks</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Class Statistics */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <StudentIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h6">Total Students</Typography>
              </Box>
              <Typography variant="h3">{classStats.totalStudents}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <GradeIcon color="success" sx={{ mr: 1 }} />
                <Typography variant="h6">Average Grade</Typography>
              </Box>
              <Typography variant="h3">{classStats.averageGrade}%</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <AssignmentIcon color="info" sx={{ mr: 1 }} />
                <Typography variant="h6">Assignments</Typography>
              </Box>
              <Typography variant="h3">{classStats.assignmentsSubmitted}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <AssessmentIcon color="warning" sx={{ mr: 1 }} />
                <Typography variant="h6">Upcoming Tests</Typography>
              </Box>
              <Typography variant="h3">{classStats.upcomingTests}</Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Student Progress Table */}
      <Paper sx={{ mb: 4 }}>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Student</TableCell>
                <TableCell>ID</TableCell>
                <TableCell align="center">Attendance</TableCell>
                <TableCell align="center">Overall Grade</TableCell>
                <TableCell>Recent Activity</TableCell>
                <TableCell align="center">Status</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {studentProgress.map((student) => (
                <TableRow key={student.id}>
                  <TableCell>{student.name}</TableCell>
                  <TableCell>{student.studentId}</TableCell>
                  <TableCell align="center">
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Box sx={{ width: '100%', mr: 1 }}>
                        <LinearProgress
                          variant="determinate"
                          value={student.attendance}
                          sx={{ height: 8, borderRadius: 4 }}
                        />
                      </Box>
                      <Box sx={{ minWidth: 35 }}>
                        <Typography variant="body2">{student.attendance}%</Typography>
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell align="center">
                    <Chip
                      label={`${student.overallGrade}%`}
                      color={getGradeColor(student.overallGrade) as any}
                    />
                  </TableCell>
                  <TableCell>{student.recentActivity}</TableCell>
                  <TableCell align="center">
                    <Chip
                      label={student.status}
                      color={getStatusColor(student.status)}
                      size="small"
                    />
                  </TableCell>
                  <TableCell align="center">
                    <Tooltip title="View Details">
                      <IconButton size="small" color="primary">
                        <ViewIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Update Grades">
                      <IconButton size="small" color="secondary">
                        <GradeIcon />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Subject-wise Performance */}
      <Typography variant="h5" gutterBottom>
        Subject-wise Performance
      </Typography>
      <Grid container spacing={3}>
        {['Data Structures', 'Operating Systems', 'Computer Networks'].map((subject) => (
          <Grid item xs={12} md={4} key={subject}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <ClassIcon color="primary" sx={{ mr: 1 }} />
                  <Typography variant="h6">{subject}</Typography>
                </Box>
                <Box sx={{ mb: 3 }}>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    Class Average
                  </Typography>
                  <LinearProgress
                    variant="determinate"
                    value={85}
                    sx={{ height: 8, borderRadius: 4 }}
                  />
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                    <Typography variant="body2">Progress</Typography>
                    <Typography variant="body2">85%</Typography>
                  </Box>
                </Box>
                <Button variant="outlined" fullWidth>
                  View Detailed Report
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default TeacherDashboard;
