import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  TextField,
  Button,
  Avatar,
  Divider,
  Stack,
  IconButton,
  Chip,
  Alert,
  Card,
  CardContent,
} from '@mui/material';
import {
  Edit as EditIcon,
  Save as SaveIcon,
  Cancel as CancelIcon,
  PhotoCamera as PhotoCameraIcon,
  School as SchoolIcon,
  Class as ClassIcon,
  Assignment as AssignmentIcon,
} from '@mui/icons-material';

// Mock teacher data
const teacherData = {
  personalInfo: {
    name: 'Dr. Sarah Johnson',
    email: 'sarah.johnson@university.edu',
    employeeId: 'EMP123456',
    department: 'Computer Science',
    designation: 'Associate Professor',
    phone: '+1 234-567-8900',
    office: 'Room 405, CS Building',
    officeHours: 'Mon, Wed 2:00 PM - 4:00 PM',
  },
  academicInfo: {
    specialization: 'Data Structures and Algorithms',
    experience: '8 years',
    education: 'Ph.D. in Computer Science',
    university: 'Stanford University',
    researchInterests: [
      'Algorithm Design',
      'Machine Learning',
      'Distributed Systems',
      'Database Systems',
    ],
  },
  teachingStats: {
    totalClasses: 3,
    totalStudents: 85,
    averageRating: 4.8,
    coursesOffered: [
      'Data Structures',
      'Operating Systems',
      'Computer Networks',
    ],
  },
};

const TeacherProfile = () => {
  const [editMode, setEditMode] = useState(false);
  const [personalInfo, setPersonalInfo] = useState(teacherData.personalInfo);
  const [showAlert, setShowAlert] = useState(false);

  const handleEditToggle = () => {
    setEditMode(!editMode);
    if (!editMode) {
      setShowAlert(false);
    } else {
      setPersonalInfo(teacherData.personalInfo);
    }
  };

  const handleSave = () => {
    setEditMode(false);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPersonalInfo(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Teacher Profile
      </Typography>

      {showAlert && (
        <Alert severity="success" sx={{ mb: 2 }}>
          Profile updated successfully!
        </Alert>
      )}

      {/* Profile Header */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 3 }}>
          <Box sx={{ position: 'relative' }}>
            <Avatar
              sx={{
                width: 120,
                height: 120,
                bgcolor: 'primary.main',
                fontSize: '3rem',
              }}
            >
              {personalInfo.name.charAt(0)}
            </Avatar>
            <IconButton
              sx={{
                position: 'absolute',
                bottom: 0,
                right: 0,
                bgcolor: 'background.paper',
              }}
              size="small"
            >
              <PhotoCameraIcon />
            </IconButton>
          </Box>
          <Box sx={{ flexGrow: 1 }}>
            <Typography variant="h5" gutterBottom>
              {personalInfo.name}
            </Typography>
            <Typography color="text.secondary" gutterBottom>
              {personalInfo.designation} • {personalInfo.department}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Employee ID: {personalInfo.employeeId}
            </Typography>
          </Box>
          <Button
            variant={editMode ? "outlined" : "contained"}
            startIcon={editMode ? <CancelIcon /> : <EditIcon />}
            onClick={handleEditToggle}
          >
            {editMode ? 'Cancel' : 'Edit Profile'}
          </Button>
          {editMode && (
            <Button
              variant="contained"
              color="success"
              startIcon={<SaveIcon />}
              onClick={handleSave}
            >
              Save
            </Button>
          )}
        </Box>
      </Paper>

      <Grid container spacing={3}>
        {/* Personal Information */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Personal Information
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Stack spacing={2}>
              <TextField
                fullWidth
                label="Full Name"
                name="name"
                value={personalInfo.name}
                onChange={handleChange}
                disabled={!editMode}
              />
              <TextField
                fullWidth
                label="Email"
                name="email"
                value={personalInfo.email}
                onChange={handleChange}
                disabled={!editMode}
              />
              <TextField
                fullWidth
                label="Phone"
                name="phone"
                value={personalInfo.phone}
                onChange={handleChange}
                disabled={!editMode}
              />
              <TextField
                fullWidth
                label="Office"
                name="office"
                value={personalInfo.office}
                onChange={handleChange}
                disabled={!editMode}
              />
              <TextField
                fullWidth
                label="Office Hours"
                name="officeHours"
                value={personalInfo.officeHours}
                onChange={handleChange}
                disabled={!editMode}
              />
            </Stack>
          </Paper>
        </Grid>

        {/* Academic Information */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Academic Information
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Stack spacing={2}>
              <Box>
                <Typography variant="subtitle2" color="text.secondary">
                  Specialization
                </Typography>
                <Typography variant="body1">
                  {teacherData.academicInfo.specialization}
                </Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="text.secondary">
                  Experience
                </Typography>
                <Typography variant="body1">
                  {teacherData.academicInfo.experience}
                </Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="text.secondary">
                  Education
                </Typography>
                <Typography variant="body1">
                  {teacherData.academicInfo.education}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {teacherData.academicInfo.university}
                </Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Research Interests
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  {teacherData.academicInfo.researchInterests.map((interest, index) => (
                    <Chip
                      key={index}
                      label={interest}
                      color="primary"
                      variant="outlined"
                    />
                  ))}
                </Box>
              </Box>
            </Stack>
          </Paper>
        </Grid>

        {/* Teaching Statistics */}
        <Grid item xs={12}>
          <Typography variant="h6" gutterBottom>
            Teaching Overview
          </Typography>
          <Grid container spacing={3}>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <ClassIcon color="primary" sx={{ mr: 1 }} />
                    <Typography variant="h6">Current Classes</Typography>
                  </Box>
                  <Typography variant="h3" color="primary">
                    {teacherData.teachingStats.totalClasses}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Active courses this semester
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <SchoolIcon color="primary" sx={{ mr: 1 }} />
                    <Typography variant="h6">Total Students</Typography>
                  </Box>
                  <Typography variant="h3" color="primary">
                    {teacherData.teachingStats.totalStudents}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Students under supervision
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <AssignmentIcon color="primary" sx={{ mr: 1 }} />
                    <Typography variant="h6">Average Rating</Typography>
                  </Box>
                  <Typography variant="h3" color="primary">
                    {teacherData.teachingStats.averageRating}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Based on student feedback
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Box>
  );
};

export default TeacherProfile;
