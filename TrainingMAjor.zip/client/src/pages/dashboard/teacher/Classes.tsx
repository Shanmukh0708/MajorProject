import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Chip,
  Divider,
  Avatar,
  AvatarGroup,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Group as GroupIcon,
  Schedule as ScheduleIcon,
  Assignment as AssignmentIcon,
} from '@mui/icons-material';

// Mock data for classes
const classesData = [
  {
    id: 1,
    name: 'Data Structures',
    code: 'CS201',
    schedule: 'Mon, Wed 10:00 AM',
    students: 32,
    assignments: 8,
    upcomingTest: 'Mid-term Exam (Feb 20)',
    studentList: [
      { id: 1, name: 'John Doe', grade: 'A' },
      { id: 2, name: 'Jane Smith', grade: 'A-' },
      { id: 3, name: 'Mike Johnson', grade: 'B+' },
    ],
  },
  {
    id: 2,
    name: 'Operating Systems',
    code: 'CS301',
    schedule: 'Tue, Thu 2:00 PM',
    students: 28,
    assignments: 6,
    upcomingTest: 'Quiz 3 (Feb 18)',
    studentList: [
      { id: 1, name: 'Alice Brown', grade: 'B+' },
      { id: 2, name: 'Bob Wilson', grade: 'A' },
      { id: 3, name: 'Carol White', grade: 'B' },
    ],
  },
  {
    id: 3,
    name: 'Computer Networks',
    code: 'CS401',
    schedule: 'Wed, Fri 11:00 AM',
    students: 35,
    assignments: 7,
    upcomingTest: 'Lab Test (Feb 22)',
    studentList: [
      { id: 1, name: 'David Lee', grade: 'A-' },
      { id: 2, name: 'Emma Davis', grade: 'B+' },
      { id: 3, name: 'Frank Miller', grade: 'A' },
    ],
  },
];

const TeacherClasses = () => {
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedClass, setSelectedClass] = useState<any>(null);
  const [openStudentList, setOpenStudentList] = useState(false);

  const handleOpenDialog = (classData?: any) => {
    setSelectedClass(classData || null);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedClass(null);
  };

  const handleOpenStudentList = (classData: any) => {
    setSelectedClass(classData);
    setOpenStudentList(true);
  };

  const handleCloseStudentList = () => {
    setOpenStudentList(false);
    setSelectedClass(null);
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">My Classes</Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          Add New Class
        </Button>
      </Box>

      <Grid container spacing={3}>
        {classesData.map((classItem) => (
          <Grid item xs={12} md={4} key={classItem.id}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <Typography variant="h6" gutterBottom>
                    {classItem.name}
                  </Typography>
                  <Chip label={classItem.code} color="primary" size="small" />
                </Box>
                
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <ScheduleIcon sx={{ fontSize: 20, mr: 1, color: 'text.secondary' }} />
                  <Typography variant="body2" color="text.secondary">
                    {classItem.schedule}
                  </Typography>
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <GroupIcon sx={{ fontSize: 20, mr: 1, color: 'text.secondary' }} />
                  <Typography variant="body2" color="text.secondary">
                    {classItem.students} Students
                  </Typography>
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <AssignmentIcon sx={{ fontSize: 20, mr: 1, color: 'text.secondary' }} />
                  <Typography variant="body2" color="text.secondary">
                    {classItem.assignments} Assignments
                  </Typography>
                </Box>

                <Divider sx={{ my: 2 }} />

                <Typography variant="subtitle2" color="primary" gutterBottom>
                  Upcoming: {classItem.upcomingTest}
                </Typography>

                <AvatarGroup max={4} sx={{ mt: 2, justifyContent: 'flex-start' }}>
                  {classItem.studentList.map((student) => (
                    <Avatar key={student.id} sx={{ width: 32, height: 32 }}>
                      {student.name.charAt(0)}
                    </Avatar>
                  ))}
                </AvatarGroup>
              </CardContent>
              <CardActions>
                <Button size="small" onClick={() => handleOpenStudentList(classItem)}>
                  View Students
                </Button>
                <Button size="small" onClick={() => handleOpenDialog(classItem)}>
                  Edit Class
                </Button>
                <IconButton size="small" color="error">
                  <DeleteIcon />
                </IconButton>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Add/Edit Class Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {selectedClass ? 'Edit Class' : 'Add New Class'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField
              fullWidth
              label="Class Name"
              defaultValue={selectedClass?.name}
            />
            <TextField
              fullWidth
              label="Class Code"
              defaultValue={selectedClass?.code}
            />
            <TextField
              fullWidth
              label="Schedule"
              defaultValue={selectedClass?.schedule}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button variant="contained" onClick={handleCloseDialog}>
            {selectedClass ? 'Save Changes' : 'Add Class'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Student List Dialog */}
      <Dialog open={openStudentList} onClose={handleCloseStudentList} maxWidth="sm" fullWidth>
        <DialogTitle>
          Students in {selectedClass?.name}
        </DialogTitle>
        <DialogContent>
          <List>
            {selectedClass?.studentList.map((student: any) => (
              <React.Fragment key={student.id}>
                <ListItem>
                  <Avatar sx={{ mr: 2 }}>{student.name.charAt(0)}</Avatar>
                  <ListItemText
                    primary={student.name}
                    secondary={`Current Grade: ${student.grade}`}
                  />
                  <ListItemSecondaryAction>
                    <IconButton edge="end" size="small">
                      <EditIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
                <Divider />
              </React.Fragment>
            ))}
          </List>
          <Box sx={{ mt: 2, display: 'flex', justifyContent: 'center' }}>
            <Button
              variant="outlined"
              startIcon={<AddIcon />}
            >
              Add Student
            </Button>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseStudentList}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default TeacherClasses;
