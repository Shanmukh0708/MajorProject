import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Grid,
  IconButton,
  Rating,
  Stack,
} from '@mui/material';
import {
  Download as DownloadIcon,
  Grade as GradeIcon,
  Comment as CommentIcon,
} from '@mui/icons-material';

// Mock data for assignments
const assignments = [
  {
    id: 1,
    title: 'Binary Tree Implementation',
    class: 'Data Structures',
    dueDate: '2024-02-20',
    submissions: 28,
    totalStudents: 32,
    status: 'Active',
    submissions_list: [
      {
        id: 1,
        student: 'John Doe',
        submittedDate: '2024-02-18',
        status: 'Submitted',
        grade: null,
        file: 'binary_tree.py',
      },
      {
        id: 2,
        student: 'Jane Smith',
        submittedDate: '2024-02-17',
        status: 'Graded',
        grade: 95,
        file: 'binary_tree.py',
      },
      {
        id: 3,
        student: 'Mike Johnson',
        submittedDate: '2024-02-19',
        status: 'Submitted',
        grade: null,
        file: 'binary_tree.py',
      },
    ],
  },
  {
    id: 2,
    title: 'Process Scheduling Algorithm',
    class: 'Operating Systems',
    dueDate: '2024-02-22',
    submissions: 25,
    totalStudents: 28,
    status: 'Active',
    submissions_list: [
      {
        id: 1,
        student: 'Alice Brown',
        submittedDate: '2024-02-19',
        status: 'Submitted',
        grade: null,
        file: 'scheduler.cpp',
      },
    ],
  },
  {
    id: 3,
    title: 'Network Protocol Analysis',
    class: 'Computer Networks',
    dueDate: '2024-02-15',
    submissions: 35,
    totalStudents: 35,
    status: 'Completed',
    submissions_list: [
      {
        id: 1,
        student: 'David Lee',
        submittedDate: '2024-02-14',
        status: 'Graded',
        grade: 88,
        file: 'protocol_analysis.pdf',
      },
    ],
  },
];

const TeacherGrading = () => {
  const [selectedAssignment, setSelectedAssignment] = useState<any>(null);
  const [openGradeDialog, setOpenGradeDialog] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState<any>(null);
  const [selectedClass, setSelectedClass] = useState('all');

  const handleOpenGradeDialog = (submission: any) => {
    setSelectedSubmission(submission);
    setOpenGradeDialog(true);
  };

  const handleCloseGradeDialog = () => {
    setOpenGradeDialog(false);
    setSelectedSubmission(null);
  };

  const handleViewSubmissions = (assignment: any) => {
    setSelectedAssignment(assignment);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active':
        return 'primary';
      case 'Completed':
        return 'success';
      case 'Graded':
        return 'success';
      case 'Submitted':
        return 'warning';
      default:
        return 'default';
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">Assignment Grading</Typography>
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Filter by Class</InputLabel>
          <Select
            value={selectedClass}
            label="Filter by Class"
            onChange={(e) => setSelectedClass(e.target.value)}
          >
            <MenuItem value="all">All Classes</MenuItem>
            <MenuItem value="ds">Data Structures</MenuItem>
            <MenuItem value="os">Operating Systems</MenuItem>
            <MenuItem value="cn">Computer Networks</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Assignments List */}
      {!selectedAssignment && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Assignment</TableCell>
                <TableCell>Class</TableCell>
                <TableCell align="center">Due Date</TableCell>
                <TableCell align="center">Submissions</TableCell>
                <TableCell align="center">Status</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {assignments.map((assignment) => (
                <TableRow key={assignment.id}>
                  <TableCell>{assignment.title}</TableCell>
                  <TableCell>{assignment.class}</TableCell>
                  <TableCell align="center">{assignment.dueDate}</TableCell>
                  <TableCell align="center">
                    {assignment.submissions}/{assignment.totalStudents}
                  </TableCell>
                  <TableCell align="center">
                    <Chip
                      label={assignment.status}
                      color={getStatusColor(assignment.status)}
                      size="small"
                    />
                  </TableCell>
                  <TableCell align="center">
                    <Button
                      variant="outlined"
                      size="small"
                      onClick={() => handleViewSubmissions(assignment)}
                    >
                      View Submissions
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Submissions List */}
      {selectedAssignment && (
        <Box>
          <Button
            variant="outlined"
            onClick={() => setSelectedAssignment(null)}
            sx={{ mb: 2 }}
          >
            Back to Assignments
          </Button>
          <Typography variant="h5" gutterBottom>
            {selectedAssignment.title} - Submissions
          </Typography>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Student</TableCell>
                  <TableCell align="center">Submitted Date</TableCell>
                  <TableCell align="center">Status</TableCell>
                  <TableCell align="center">Grade</TableCell>
                  <TableCell align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {selectedAssignment.submissions_list.map((submission: any) => (
                  <TableRow key={submission.id}>
                    <TableCell>{submission.student}</TableCell>
                    <TableCell align="center">{submission.submittedDate}</TableCell>
                    <TableCell align="center">
                      <Chip
                        label={submission.status}
                        color={getStatusColor(submission.status)}
                        size="small"
                      />
                    </TableCell>
                    <TableCell align="center">
                      {submission.grade ? `${submission.grade}/100` : 'Not graded'}
                    </TableCell>
                    <TableCell align="center">
                      <IconButton
                        color="primary"
                        onClick={() => handleOpenGradeDialog(submission)}
                      >
                        <GradeIcon />
                      </IconButton>
                      <IconButton color="primary">
                        <DownloadIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}

      {/* Grade Assignment Dialog */}
      <Dialog open={openGradeDialog} onClose={handleCloseGradeDialog} maxWidth="sm" fullWidth>
        <DialogTitle>Grade Submission</DialogTitle>
        <DialogContent>
          {selectedSubmission && (
            <Stack spacing={3} sx={{ mt: 2 }}>
              <Typography variant="subtitle1">
                Student: {selectedSubmission.student}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Submitted: {selectedSubmission.submittedDate}
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Typography>File:</Typography>
                <Chip
                  label={selectedSubmission.file}
                  onClick={() => {}}
                  onDelete={() => {}}
                />
              </Box>
              <TextField
                fullWidth
                label="Grade (out of 100)"
                type="number"
                defaultValue={selectedSubmission.grade}
                InputProps={{ inputProps: { min: 0, max: 100 } }}
              />
              <Box>
                <Typography gutterBottom>Code Quality</Typography>
                <Rating name="code-quality" defaultValue={4} />
              </Box>
              <TextField
                fullWidth
                label="Feedback Comments"
                multiline
                rows={4}
              />
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseGradeDialog}>Cancel</Button>
          <Button variant="contained" onClick={handleCloseGradeDialog}>
            Submit Grade
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default TeacherGrading;
