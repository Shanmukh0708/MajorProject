import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  IconButton,
  Stack,
  TextareaAutosize,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Code as CodeIcon,
  Assignment as AssignmentIcon,
  Timer as TimerIcon,
  Star as StarIcon,
} from '@mui/icons-material';

// Mock data for problems
const problemsData = [
  {
    id: 1,
    title: 'Binary Tree Implementation',
    category: 'Data Structures',
    difficulty: 'Medium',
    timeLimit: '45 mins',
    points: 100,
    submissions: 28,
    successRate: 75,
    description: 'Implement a binary tree with basic operations like insertion, deletion, and traversal.',
    testCases: [
      { input: '[1, 2, 3, 4, 5]', output: 'Inorder: 4 2 5 1 3' },
      { input: '[10, 5, 15]', output: 'Inorder: 5 10 15' },
    ],
  },
  {
    id: 2,
    title: 'Process Scheduler',
    category: 'Operating Systems',
    difficulty: 'Hard',
    timeLimit: '60 mins',
    points: 150,
    submissions: 22,
    successRate: 65,
    description: 'Implement a process scheduler using Round Robin algorithm.',
    testCases: [
      { input: 'Processes: P1(4), P2(3), P3(5)', output: 'Sequence: P1 P2 P3 P1 P3' },
    ],
  },
  {
    id: 3,
    title: 'TCP Socket Programming',
    category: 'Computer Networks',
    difficulty: 'Easy',
    timeLimit: '30 mins',
    points: 75,
    submissions: 35,
    successRate: 85,
    description: 'Create a simple client-server application using TCP sockets.',
    testCases: [
      { input: 'Message: "Hello"', output: 'Server Response: "Hello received"' },
    ],
  },
];

const TeacherProblems = () => {
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedProblem, setSelectedProblem] = useState<any>(null);
  const [filter, setFilter] = useState('all');

  const handleOpenDialog = (problem?: any) => {
    setSelectedProblem(problem || null);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedProblem(null);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'easy':
        return 'success';
      case 'medium':
        return 'warning';
      case 'hard':
        return 'error';
      default:
        return 'default';
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">Problem Bank</Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <FormControl sx={{ minWidth: 200 }}>
            <InputLabel>Filter by Category</InputLabel>
            <Select
              value={filter}
              label="Filter by Category"
              onChange={(e) => setFilter(e.target.value)}
            >
              <MenuItem value="all">All Categories</MenuItem>
              <MenuItem value="ds">Data Structures</MenuItem>
              <MenuItem value="os">Operating Systems</MenuItem>
              <MenuItem value="cn">Computer Networks</MenuItem>
            </Select>
          </FormControl>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => handleOpenDialog()}
          >
            Create Problem
          </Button>
        </Box>
      </Box>

      <Grid container spacing={3}>
        {problemsData.map((problem) => (
          <Grid item xs={12} md={4} key={problem.id}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                  <Typography variant="h6">{problem.title}</Typography>
                  <Chip
                    label={problem.difficulty}
                    color={getDifficultyColor(problem.difficulty)}
                    size="small"
                  />
                </Box>

                <Stack spacing={1}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CodeIcon color="action" fontSize="small" />
                    <Typography variant="body2" color="text.secondary">
                      {problem.category}
                    </Typography>
                  </Box>

                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <TimerIcon color="action" fontSize="small" />
                    <Typography variant="body2" color="text.secondary">
                      Time Limit: {problem.timeLimit}
                    </Typography>
                  </Box>

                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <StarIcon color="action" fontSize="small" />
                    <Typography variant="body2" color="text.secondary">
                      Points: {problem.points}
                    </Typography>
                  </Box>

                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <AssignmentIcon color="action" fontSize="small" />
                    <Typography variant="body2" color="text.secondary">
                      Submissions: {problem.submissions} ({problem.successRate}% success)
                    </Typography>
                  </Box>
                </Stack>

                <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                  {problem.description}
                </Typography>
              </CardContent>
              <CardActions>
                <Button size="small" onClick={() => handleOpenDialog(problem)}>
                  Edit
                </Button>
                <Button size="small">View Submissions</Button>
                <IconButton size="small" color="error">
                  <DeleteIcon />
                </IconButton>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Create/Edit Problem Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {selectedProblem ? 'Edit Problem' : 'Create New Problem'}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={3} sx={{ mt: 2 }}>
            <TextField
              fullWidth
              label="Problem Title"
              defaultValue={selectedProblem?.title}
            />

            <Grid container spacing={2}>
              <Grid item xs={12} md={4}>
                <FormControl fullWidth>
                  <InputLabel>Category</InputLabel>
                  <Select
                    defaultValue={selectedProblem?.category || ''}
                    label="Category"
                  >
                    <MenuItem value="Data Structures">Data Structures</MenuItem>
                    <MenuItem value="Operating Systems">Operating Systems</MenuItem>
                    <MenuItem value="Computer Networks">Computer Networks</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={4}>
                <FormControl fullWidth>
                  <InputLabel>Difficulty</InputLabel>
                  <Select
                    defaultValue={selectedProblem?.difficulty || ''}
                    label="Difficulty"
                  >
                    <MenuItem value="Easy">Easy</MenuItem>
                    <MenuItem value="Medium">Medium</MenuItem>
                    <MenuItem value="Hard">Hard</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Points"
                  type="number"
                  defaultValue={selectedProblem?.points}
                />
              </Grid>
            </Grid>

            <TextField
              fullWidth
              label="Time Limit"
              defaultValue={selectedProblem?.timeLimit}
            />

            <TextField
              fullWidth
              label="Problem Description"
              multiline
              rows={4}
              defaultValue={selectedProblem?.description}
            />

            <Typography variant="subtitle1">Test Cases</Typography>
            {(selectedProblem?.testCases || [{}]).map((testCase: any, index: number) => (
              <Grid container spacing={2} key={index}>
                <Grid item xs={6}>
                  <TextField
                    fullWidth
                    label="Input"
                    defaultValue={testCase.input}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    fullWidth
                    label="Expected Output"
                    defaultValue={testCase.output}
                  />
                </Grid>
              </Grid>
            ))}
            <Button startIcon={<AddIcon />}>
              Add Test Case
            </Button>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button variant="contained" onClick={handleCloseDialog}>
            {selectedProblem ? 'Save Changes' : 'Create Problem'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default TeacherProblems;
