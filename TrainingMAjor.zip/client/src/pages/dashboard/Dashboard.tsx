import React from 'react';
import { Box, Grid, Paper, Typography, LinearProgress } from '@mui/material';
import DashboardLayout from '../../components/dashboard/DashboardLayout';

// Mock data for the dashboard
const skillProgress = [
  { skill: 'JavaScript', progress: 75 },
  { skill: 'React', progress: 60 },
  { skill: 'Node.js', progress: 45 },
  { skill: 'Python', progress: 80 },
];

const recentChallenges = [
  { name: 'Build a REST API', completed: true, score: 95 },
  { name: 'Create a React Component', completed: true, score: 88 },
  { name: 'Implement Authentication', completed: false, score: 0 },
];

const Dashboard = () => {
  return (
    <DashboardLayout>
      <Box>
        <Typography variant="h4" gutterBottom>
          Welcome back, User!
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" gutterBottom>
          Here's your learning progress
        </Typography>

        <Grid container spacing={3} sx={{ mt: 2 }}>
          {/* Skill Progress */}
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Skill Progress
              </Typography>
              {skillProgress.map((skill) => (
                <Box key={skill.skill} sx={{ mb: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body1">{skill.skill}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {skill.progress}%
                    </Typography>
                  </Box>
                  <LinearProgress 
                    variant="determinate" 
                    value={skill.progress}
                    sx={{ height: 8, borderRadius: 4 }}
                  />
                </Box>
              ))}
            </Paper>
          </Grid>

          {/* Recent Challenges */}
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Recent Challenges
              </Typography>
              {recentChallenges.map((challenge, index) => (
                <Box
                  key={index}
                  sx={{
                    p: 2,
                    mb: 1,
                    border: 1,
                    borderColor: 'grey.200',
                    borderRadius: 1,
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}
                >
                  <Box>
                    <Typography variant="body1">{challenge.name}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {challenge.completed ? 'Completed' : 'In Progress'}
                    </Typography>
                  </Box>
                  {challenge.completed && (
                    <Typography
                      variant="h6"
                      sx={{
                        color: 'success.main',
                        bgcolor: 'success.light',
                        px: 2,
                        py: 0.5,
                        borderRadius: 2,
                      }}
                    >
                      {challenge.score}%
                    </Typography>
                  )}
                </Box>
              ))}
            </Paper>
          </Grid>

          {/* Recommended Skills */}
          <Grid item xs={12}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Recommended Skills
              </Typography>
              <Typography variant="body1" paragraph>
                Based on your progress and industry trends, we recommend focusing on:
              </Typography>
              <Grid container spacing={2}>
                {['TypeScript', 'Docker', 'AWS', 'GraphQL'].map((skill) => (
                  <Grid item xs={12} sm={6} md={3} key={skill}>
                    <Paper
                      elevation={0}
                      sx={{
                        p: 2,
                        textAlign: 'center',
                        bgcolor: 'primary.light',
                        color: 'primary.contrastText',
                      }}
                    >
                      {skill}
                    </Paper>
                  </Grid>
                ))}
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      </Box>
    </DashboardLayout>
  );
};

export default Dashboard;
