import React, { useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  LinearProgress,
  IconButton,
  TextField
} from '@mui/material';
import {
  Code as CodeIcon,
  Timer as TimerIcon,
  Star as StarIcon,
  Close as CloseIcon
} from '@mui/icons-material';
import DashboardLayout from '../../components/dashboard/DashboardLayout';

// Mock challenges data
const challengesData = [
  {
    id: 1,
    title: 'Build a REST API',
    description: 'Create a RESTful API with CRUD operations using Node.js and Express',
    difficulty: 'Intermediate',
    timeEstimate: '2 hours',
    points: 100,
    tags: ['Node.js', 'Express', 'REST API'],
    status: 'not_started'
  },
  {
    id: 2,
    title: 'React Component Library',
    description: 'Develop a reusable component library with TypeScript and Styled Components',
    difficulty: 'Advanced',
    timeEstimate: '4 hours',
    points: 150,
    tags: ['React', 'TypeScript', 'Styled Components'],
    status: 'not_started'
  },
  {
    id: 3,
    title: 'Authentication System',
    description: 'Implement JWT-based authentication with refresh tokens',
    difficulty: 'Advanced',
    timeEstimate: '3 hours',
    points: 200,
    tags: ['Security', 'JWT', 'Authentication'],
    status: 'in_progress',
    progress: 60
  }
];

const Challenges = () => {
  const [selectedChallenge, setSelectedChallenge] = useState<any>(null);
  const [openDialog, setOpenDialog] = useState(false);

  const handleOpenChallenge = (challenge: any) => {
    setSelectedChallenge(challenge);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'beginner':
        return 'success';
      case 'intermediate':
        return 'warning';
      case 'advanced':
        return 'error';
      default:
        return 'default';
    }
  };

  return (
    <DashboardLayout>
      <Box sx={{ p: 3 }}>
        <Typography variant="h4" gutterBottom>
          Coding Challenges
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" paragraph>
          Complete challenges to earn points and improve your skills
        </Typography>

        <Grid container spacing={3}>
          {challengesData.map((challenge) => (
            <Grid item xs={12} md={6} lg={4} key={challenge.id}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <CodeIcon sx={{ mr: 1, color: 'primary.main' }} />
                    <Typography variant="h6" component="div">
                      {challenge.title}
                    </Typography>
                  </Box>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    {challenge.description}
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <TimerIcon sx={{ fontSize: 'small', mr: 0.5 }} />
                    <Typography variant="body2" color="text.secondary" sx={{ mr: 2 }}>
                      {challenge.timeEstimate}
                    </Typography>
                    <StarIcon sx={{ fontSize: 'small', mr: 0.5 }} />
                    <Typography variant="body2" color="text.secondary">
                      {challenge.points} points
                    </Typography>
                  </Box>
                  <Box sx={{ mb: 2 }}>
                    <Chip
                      label={challenge.difficulty}
                      size="small"
                      color={getDifficultyColor(challenge.difficulty) as any}
                      sx={{ mr: 1 }}
                    />
                    {challenge.tags.map((tag: string) => (
                      <Chip
                        key={tag}
                        label={tag}
                        size="small"
                        variant="outlined"
                        sx={{ mr: 1 }}
                      />
                    ))}
                  </Box>
                  {challenge.status === 'in_progress' && (
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        Progress: {challenge.progress}%
                      </Typography>
                      <LinearProgress
                        variant="determinate"
                        value={challenge.progress}
                        sx={{ height: 8, borderRadius: 4 }}
                      />
                    </Box>
                  )}
                </CardContent>
                <CardActions>
                  <Button
                    size="small"
                    variant="contained"
                    onClick={() => handleOpenChallenge(challenge)}
                  >
                    {challenge.status === 'not_started' ? 'Start Challenge' : 'Continue'}
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Challenge Details Dialog */}
        <Dialog
          open={openDialog}
          onClose={handleCloseDialog}
          maxWidth="md"
          fullWidth
        >
          {selectedChallenge && (
            <>
              <DialogTitle>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <Typography variant="h6">{selectedChallenge.title}</Typography>
                  <IconButton onClick={handleCloseDialog}>
                    <CloseIcon />
                  </IconButton>
                </Box>
              </DialogTitle>
              <DialogContent dividers>
                <Typography variant="subtitle1" gutterBottom>
                  Challenge Description
                </Typography>
                <Typography variant="body1" paragraph>
                  {selectedChallenge.description}
                </Typography>
                <Typography variant="subtitle1" gutterBottom>
                  Requirements
                </Typography>
                <Typography variant="body1" paragraph>
                  • Implement all required functionality according to specifications
                  <br />
                  • Write clean, maintainable code
                  <br />
                  • Include proper error handling
                  <br />
                  • Add appropriate documentation
                </Typography>
                <TextField
                  fullWidth
                  multiline
                  rows={8}
                  variant="outlined"
                  label="Your Solution"
                  placeholder="Write your code here..."
                />
              </DialogContent>
              <DialogActions>
                <Button onClick={handleCloseDialog}>Cancel</Button>
                <Button variant="contained" onClick={handleCloseDialog}>
                  Submit Solution
                </Button>
              </DialogActions>
            </>
          )}
        </Dialog>
      </Box>
    </DashboardLayout>
  );
};

export default Challenges;
