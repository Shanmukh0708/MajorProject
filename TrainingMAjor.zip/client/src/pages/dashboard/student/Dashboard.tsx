import React from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  LinearProgress,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  Divider,
} from '@mui/material';
import {
  Schedule as ScheduleIcon,
  School as SchoolIcon,
  Code as CodeIcon,
  Assignment as AssignmentIcon,
} from '@mui/icons-material';

// Mock data for academic courses
const academicCourses = [
  {
    subject: 'Data Structures',
    professor: 'Dr. Sarah Johnson',
    progress: 75,
    upcomingTest: {
      title: 'Mid-term Exam',
      date: '2024-02-20',
      topics: ['Binary Trees', 'Graph Algorithms'],
    },
  },
  {
    subject: 'Operating Systems',
    professor: 'Prof. Michael Chen',
    progress: 60,
    upcomingTest: {
      title: 'Quiz 3',
      date: '2024-02-18',
      topics: ['Process Scheduling', 'Memory Management'],
    },
  },
  {
    subject: 'Computer Networks',
    professor: 'Dr. Emily Brown',
    progress: 85,
    upcomingTest: {
      title: 'Lab Test',
      date: '2024-02-22',
      topics: ['TCP/IP', 'Network Security'],
    },
  },
];

// Mock data for personalized interest courses
const interestCourses = [
  {
    title: 'Machine Learning Fundamentals',
    provider: 'AI Learning Hub',
    progress: 45,
    matchScore: 95,
    recommendedProblems: [
      'Linear Regression Implementation',
      'Classification Algorithm',
    ],
  },
  {
    title: 'Web Development with React',
    provider: 'Frontend Masters',
    progress: 68,
    matchScore: 88,
    recommendedProblems: [
      'State Management',
      'API Integration',
    ],
  },
  {
    title: 'Cloud Computing',
    provider: 'Cloud Academy',
    progress: 30,
    matchScore: 85,
    recommendedProblems: [
      'Deploy Serverless Function',
      'Set up Load Balancer',
    ],
  },
];

const StudentDashboard = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Welcome back, Student!
      </Typography>

      {/* Academic Courses Section */}
      <Typography variant="h5" sx={{ mt: 4, mb: 2 }}>
        Academic Courses
      </Typography>
      <Grid container spacing={3}>
        {academicCourses.map((course) => (
          <Grid item xs={12} md={4} key={course.subject}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <SchoolIcon sx={{ mr: 1 }} color="primary" />
                  <Typography variant="h6">{course.subject}</Typography>
                </Box>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  Professor: {course.professor}
                </Typography>
                <Box sx={{ mt: 2, mb: 1 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2">Progress</Typography>
                    <Typography variant="body2">{course.progress}%</Typography>
                  </Box>
                  <LinearProgress 
                    variant="determinate" 
                    value={course.progress}
                    sx={{ height: 8, borderRadius: 4 }}
                  />
                </Box>
                <Box sx={{ mt: 2 }}>
                  <Typography variant="subtitle2" color="primary" gutterBottom>
                    <ScheduleIcon sx={{ fontSize: 16, mr: 0.5, verticalAlign: 'text-bottom' }} />
                    Upcoming Test
                  </Typography>
                  <Typography variant="body2">
                    {course.upcomingTest.title} - {course.upcomingTest.date}
                  </Typography>
                  <Box sx={{ mt: 1 }}>
                    {course.upcomingTest.topics.map((topic, index) => (
                      <Chip
                        key={index}
                        label={topic}
                        size="small"
                        sx={{ mr: 0.5, mt: 0.5 }}
                      />
                    ))}
                  </Box>
                </Box>
              </CardContent>
              <CardActions>
                <Button size="small">View Details</Button>
                <Button size="small">Study Materials</Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Personalized Interest Courses Section */}
      <Typography variant="h5" sx={{ mt: 4, mb: 2 }}>
        Personalized Interest Courses
      </Typography>
      <Grid container spacing={3}>
        {interestCourses.map((course) => (
          <Grid item xs={12} md={4} key={course.title}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <CodeIcon sx={{ mr: 1 }} color="secondary" />
                  <Typography variant="h6">{course.title}</Typography>
                </Box>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  Provider: {course.provider}
                </Typography>
                <Chip 
                  label={`${course.matchScore}% Match`}
                  color="success"
                  size="small"
                  sx={{ mb: 2 }}
                />
                <Box sx={{ mt: 2, mb: 1 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2">Progress</Typography>
                    <Typography variant="body2">{course.progress}%</Typography>
                  </Box>
                  <LinearProgress 
                    variant="determinate" 
                    value={course.progress}
                    sx={{ height: 8, borderRadius: 4 }}
                  />
                </Box>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle2" color="secondary" gutterBottom>
                  <AssignmentIcon sx={{ fontSize: 16, mr: 0.5, verticalAlign: 'text-bottom' }} />
                  Recommended Problems
                </Typography>
                {course.recommendedProblems.map((problem, index) => (
                  <Typography key={index} variant="body2" sx={{ mt: 0.5 }}>
                    • {problem}
                  </Typography>
                ))}
              </CardContent>
              <CardActions>
                <Button size="small">Continue Learning</Button>
                <Button size="small">View Problems</Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Quick Stats */}
      <Grid container spacing={2} sx={{ mt: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="primary">6</Typography>
            <Typography variant="body2">Active Courses</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="secondary">3</Typography>
            <Typography variant="body2">Upcoming Tests</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="success.main">85%</Typography>
            <Typography variant="body2">Average Progress</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="info.main">12</Typography>
            <Typography variant="body2">Completed Assignments</Typography>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default StudentDashboard;
