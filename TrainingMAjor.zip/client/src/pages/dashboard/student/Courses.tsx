import React from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Button,
  Card,
  CardContent,
  CardActions,
  CardMedia,
  Chip,
  LinearProgress,
} from '@mui/material';
import {
  Schedule as ScheduleIcon,
  Person as TeacherIcon,
  Class as ClassIcon,
} from '@mui/icons-material';

// Mock data for courses
const courses = [
  {
    id: 1,
    name: 'Data Structures and Algorithms',
    teacher: 'Dr. Sarah Johnson',
    schedule: 'Mon, Wed 10:00 AM',
    progress: 75,
    image: 'https://source.unsplash.com/random/400x200?coding',
    status: 'In Progress',
  },
  {
    id: 2,
    name: 'Web Development',
    teacher: 'Prof. Michael Chen',
    schedule: 'Tue, Thu 2:00 PM',
    progress: 60,
    image: 'https://source.unsplash.com/random/400x200?webdev',
    status: 'In Progress',
  },
  {
    id: 3,
    name: 'Database Systems',
    teacher: 'Dr. Emily Brown',
    schedule: 'Wed, Fri 11:00 AM',
    progress: 45,
    image: 'https://source.unsplash.com/random/400x200?database',
    status: 'In Progress',
  },
  {
    id: 4,
    name: 'Computer Networks',
    teacher: 'Prof. David Wilson',
    schedule: 'Mon, Thu 3:00 PM',
    progress: 80,
    image: 'https://source.unsplash.com/random/400x200?network',
    status: 'In Progress',
  },
];

const StudentCourses = () => {
  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Typography variant="h4" gutterBottom>
            My Courses
          </Typography>
          <Typography variant="subtitle1" color="text.secondary">
            View and manage your enrolled courses
          </Typography>
        </div>
        <Button variant="contained" color="primary">
          Browse More Courses
        </Button>
      </Box>

      <Grid container spacing={3}>
        {courses.map((course) => (
          <Grid item xs={12} md={6} key={course.id}>
            <Card>
              <CardMedia
                component="img"
                height="140"
                image={course.image}
                alt={course.name}
              />
              <CardContent>
                <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="h6" component="div">
                    {course.name}
                  </Typography>
                  <Chip
                    label={course.status}
                    color="primary"
                    size="small"
                  />
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <TeacherIcon sx={{ mr: 1, fontSize: 20, color: 'text.secondary' }} />
                    <Typography variant="body2" color="text.secondary">
                      {course.teacher}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <ScheduleIcon sx={{ mr: 1, fontSize: 20, color: 'text.secondary' }} />
                    <Typography variant="body2" color="text.secondary">
                      {course.schedule}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <ClassIcon sx={{ mr: 1, fontSize: 20, color: 'text.secondary' }} />
                    <Typography variant="body2" color="text.secondary">
                      Progress: {course.progress}%
                    </Typography>
                  </Box>
                </Box>

                <LinearProgress 
                  variant="determinate" 
                  value={course.progress}
                  sx={{ 
                    height: 8, 
                    borderRadius: 4,
                    mb: 2,
                    backgroundColor: 'grey.200',
                  }}
                />
              </CardContent>
              <CardActions>
                <Button size="small" color="primary">
                  View Course
                </Button>
                <Button size="small" color="primary">
                  Materials
                </Button>
                <Button size="small" color="primary">
                  Assignments
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Course Statistics */}
      <Grid container spacing={2} sx={{ mt: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="primary">4</Typography>
            <Typography variant="body2">Active Courses</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="success.main">65%</Typography>
            <Typography variant="body2">Average Progress</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="warning.main">12</Typography>
            <Typography variant="body2">Pending Assignments</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="info.main">8</Typography>
            <Typography variant="body2">Completed Courses</Typography>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default StudentCourses;
