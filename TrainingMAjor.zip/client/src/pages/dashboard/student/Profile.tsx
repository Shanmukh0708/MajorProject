import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  TextField,
  Button,
  Avatar,
  Divider,
  Stack,
  IconButton,
  Chip,
  Alert,
} from '@mui/material';
import {
  Edit as EditIcon,
  Save as SaveIcon,
  Cancel as CancelIcon,
  PhotoCamera as PhotoCameraIcon,
} from '@mui/icons-material';

// Mock student data
const studentData = {
  personalInfo: {
    name: 'John Doe',
    email: 'john.doe@university.edu',
    studentId: 'STU123456',
    department: 'Computer Science',
    year: '3rd Year',
    semester: '6th Semester',
    phone: '+1 234-567-8900',
    address: '123 University Ave, College Town, ST 12345',
  },
  academicInfo: {
    major: 'Computer Science',
    minor: 'Mathematics',
    advisor: 'Dr. Sarah Johnson',
    gpa: '3.85',
    credits: '75',
    expectedGraduation: '2025',
  },
  skills: [
    'Java',
    'Python',
    'React',
    'Node.js',
    'Data Structures',
    'Algorithms',
    'Database Systems',
    'Web Development',
  ],
};

const StudentProfile = () => {
  const [editMode, setEditMode] = useState(false);
  const [personalInfo, setPersonalInfo] = useState(studentData.personalInfo);
  const [showAlert, setShowAlert] = useState(false);

  const handleEditToggle = () => {
    setEditMode(!editMode);
    if (!editMode) {
      // Enter edit mode
      setShowAlert(false);
    } else {
      // Cancel edit mode
      setPersonalInfo(studentData.personalInfo);
    }
  };

  const handleSave = () => {
    // Here you would typically make an API call to update the profile
    setEditMode(false);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPersonalInfo(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Student Profile
      </Typography>

      {showAlert && (
        <Alert severity="success" sx={{ mb: 2 }}>
          Profile updated successfully!
        </Alert>
      )}

      {/* Profile Header */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 3 }}>
          <Box sx={{ position: 'relative' }}>
            <Avatar
              sx={{
                width: 120,
                height: 120,
                bgcolor: 'primary.main',
                fontSize: '3rem',
              }}
            >
              {personalInfo.name.charAt(0)}
            </Avatar>
            <IconButton
              sx={{
                position: 'absolute',
                bottom: 0,
                right: 0,
                bgcolor: 'background.paper',
              }}
              size="small"
            >
              <PhotoCameraIcon />
            </IconButton>
          </Box>
          <Box sx={{ flexGrow: 1 }}>
            <Typography variant="h5" gutterBottom>
              {personalInfo.name}
            </Typography>
            <Typography color="text.secondary" gutterBottom>
              {studentData.academicInfo.major} • {personalInfo.year}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Student ID: {personalInfo.studentId}
            </Typography>
          </Box>
          <Button
            variant={editMode ? "outlined" : "contained"}
            startIcon={editMode ? <CancelIcon /> : <EditIcon />}
            onClick={handleEditToggle}
          >
            {editMode ? 'Cancel' : 'Edit Profile'}
          </Button>
          {editMode && (
            <Button
              variant="contained"
              color="success"
              startIcon={<SaveIcon />}
              onClick={handleSave}
            >
              Save
            </Button>
          )}
        </Box>
      </Paper>

      {/* Personal Information */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Personal Information
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Stack spacing={2}>
              <TextField
                fullWidth
                label="Full Name"
                name="name"
                value={personalInfo.name}
                onChange={handleChange}
                disabled={!editMode}
              />
              <TextField
                fullWidth
                label="Email"
                name="email"
                value={personalInfo.email}
                onChange={handleChange}
                disabled={!editMode}
              />
              <TextField
                fullWidth
                label="Phone"
                name="phone"
                value={personalInfo.phone}
                onChange={handleChange}
                disabled={!editMode}
              />
              <TextField
                fullWidth
                label="Address"
                name="address"
                value={personalInfo.address}
                onChange={handleChange}
                disabled={!editMode}
                multiline
                rows={2}
              />
            </Stack>
          </Paper>
        </Grid>

        {/* Academic Information */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Academic Information
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Major
                </Typography>
                <Typography variant="body1">
                  {studentData.academicInfo.major}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Minor
                </Typography>
                <Typography variant="body1">
                  {studentData.academicInfo.minor}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Academic Advisor
                </Typography>
                <Typography variant="body1">
                  {studentData.academicInfo.advisor}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Current GPA
                </Typography>
                <Typography variant="body1">
                  {studentData.academicInfo.gpa}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Credits Completed
                </Typography>
                <Typography variant="body1">
                  {studentData.academicInfo.credits}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Expected Graduation
                </Typography>
                <Typography variant="body1">
                  {studentData.academicInfo.expectedGraduation}
                </Typography>
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        {/* Skills */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Skills & Expertise
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {studentData.skills.map((skill, index) => (
                <Chip
                  key={index}
                  label={skill}
                  color="primary"
                  variant="outlined"
                />
              ))}
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default StudentProfile;
