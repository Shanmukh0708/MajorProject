import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Tabs,
  Tab,
  Button,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
} from '@mui/material';
import {
  Upload as UploadIcon,
  Visibility as ViewIcon,
  CloudUpload as CloudUploadIcon,
} from '@mui/icons-material';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

// Mock data for assignments
const assignments = {
  pending: [
    {
      id: 1,
      title: 'Binary Tree Implementation',
      course: 'Data Structures',
      dueDate: '2024-02-15',
      status: 'Pending',
      type: 'Programming',
    },
    {
      id: 2,
      title: 'React Components',
      course: 'Web Development',
      dueDate: '2024-02-18',
      status: 'Pending',
      type: 'Project',
    },
  ],
  submitted: [
    {
      id: 3,
      title: 'Database Schema Design',
      course: 'Database Systems',
      submittedDate: '2024-02-01',
      grade: 'A',
      status: 'Graded',
      type: 'Design',
    },
    {
      id: 4,
      title: 'Network Protocols',
      course: 'Computer Networks',
      submittedDate: '2024-02-05',
      grade: 'Pending',
      status: 'Submitted',
      type: 'Theory',
    },
  ],
};

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`assignment-tabpanel-${index}`}
      aria-labelledby={`assignment-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const StudentAssignments = () => {
  const [tabValue, setTabValue] = useState(0);
  const [openSubmitDialog, setOpenSubmitDialog] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<any>(null);

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleOpenSubmitDialog = (assignment: any) => {
    setSelectedAssignment(assignment);
    setOpenSubmitDialog(true);
  };

  const handleCloseSubmitDialog = () => {
    setOpenSubmitDialog(false);
    setSelectedAssignment(null);
  };

  const handleSubmitAssignment = () => {
    // Handle assignment submission logic here
    handleCloseSubmitDialog();
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Assignments
      </Typography>
      
      <Paper sx={{ width: '100%', mb: 4 }}>
        <Tabs
          value={tabValue}
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
        >
          <Tab label="Pending" />
          <Tab label="Submitted" />
        </Tabs>

        <TabPanel value={tabValue} index={0}>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Title</TableCell>
                  <TableCell>Course</TableCell>
                  <TableCell>Type</TableCell>
                  <TableCell>Due Date</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {assignments.pending.map((assignment) => (
                  <TableRow key={assignment.id}>
                    <TableCell>{assignment.title}</TableCell>
                    <TableCell>{assignment.course}</TableCell>
                    <TableCell>
                      <Chip label={assignment.type} size="small" />
                    </TableCell>
                    <TableCell>{assignment.dueDate}</TableCell>
                    <TableCell>
                      <Chip 
                        label={assignment.status} 
                        color="warning"
                        size="small"
                      />
                    </TableCell>
                    <TableCell>
                      <IconButton 
                        color="primary"
                        onClick={() => handleOpenSubmitDialog(assignment)}
                      >
                        <UploadIcon />
                      </IconButton>
                      <IconButton color="primary">
                        <ViewIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </TabPanel>

        <TabPanel value={tabValue} index={1}>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Title</TableCell>
                  <TableCell>Course</TableCell>
                  <TableCell>Type</TableCell>
                  <TableCell>Submitted Date</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Grade</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {assignments.submitted.map((assignment) => (
                  <TableRow key={assignment.id}>
                    <TableCell>{assignment.title}</TableCell>
                    <TableCell>{assignment.course}</TableCell>
                    <TableCell>
                      <Chip label={assignment.type} size="small" />
                    </TableCell>
                    <TableCell>{assignment.submittedDate}</TableCell>
                    <TableCell>
                      <Chip 
                        label={assignment.status}
                        color={assignment.status === 'Graded' ? 'success' : 'info'}
                        size="small"
                      />
                    </TableCell>
                    <TableCell>{assignment.grade}</TableCell>
                    <TableCell>
                      <IconButton color="primary">
                        <ViewIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </TabPanel>
      </Paper>

      {/* Submit Assignment Dialog */}
      <Dialog open={openSubmitDialog} onClose={handleCloseSubmitDialog}>
        <DialogTitle>Submit Assignment</DialogTitle>
        <DialogContent>
          {selectedAssignment && (
            <Box sx={{ pt: 2 }}>
              <Typography variant="subtitle1" gutterBottom>
                {selectedAssignment.title}
              </Typography>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Course: {selectedAssignment.course}
              </Typography>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Due Date: {selectedAssignment.dueDate}
              </Typography>
              <TextField
                fullWidth
                multiline
                rows={4}
                margin="normal"
                label="Comments (Optional)"
                variant="outlined"
              />
              <Button
                variant="outlined"
                component="label"
                startIcon={<CloudUploadIcon />}
                sx={{ mt: 2 }}
              >
                Upload File
                <input type="file" hidden />
              </Button>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseSubmitDialog}>Cancel</Button>
          <Button onClick={handleSubmitAssignment} variant="contained">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default StudentAssignments;
