import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Switch,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Divider,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  Stack,
  FormControlLabel,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import {
  Notifications as NotificationsIcon,
  Security as SecurityIcon,
  Palette as PaletteIcon,
  Language as LanguageIcon,
} from '@mui/icons-material';

const StudentSettings = () => {
  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    assignmentReminders: true,
    gradeUpdates: true,
    courseAnnouncements: true,
    darkMode: false,
    language: 'english',
  });

  const [openPasswordDialog, setOpenPasswordDialog] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertSeverity, setAlertSeverity] = useState<'success' | 'error'>('success');

  const handleSettingChange = (setting: string) => (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setSettings({
      ...settings,
      [setting]: event.target.checked,
    });
    showSuccessMessage('Settings updated successfully');
  };

  const handleLanguageChange = (event: any) => {
    setSettings({
      ...settings,
      language: event.target.value,
    });
    showSuccessMessage('Language preference updated');
  };

  const handlePasswordChange = () => {
    // Here you would typically make an API call to change the password
    setOpenPasswordDialog(false);
    showSuccessMessage('Password updated successfully');
  };

  const showSuccessMessage = (message: string) => {
    setAlertMessage(message);
    setAlertSeverity('success');
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 3000);
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Settings
      </Typography>

      {showAlert && (
        <Alert severity={alertSeverity} sx={{ mb: 2 }}>
          {alertMessage}
        </Alert>
      )}

      <Stack spacing={3}>
        {/* Notification Settings */}
        <Paper sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <NotificationsIcon sx={{ mr: 1 }} color="primary" />
            <Typography variant="h6">Notification Preferences</Typography>
          </Box>
          <List>
            <ListItem>
              <ListItemText 
                primary="Email Notifications"
                secondary="Receive important updates via email"
              />
              <ListItemSecondaryAction>
                <Switch
                  edge="end"
                  checked={settings.emailNotifications}
                  onChange={handleSettingChange('emailNotifications')}
                />
              </ListItemSecondaryAction>
            </ListItem>
            <Divider />
            <ListItem>
              <ListItemText
                primary="Push Notifications"
                secondary="Receive notifications in your browser"
              />
              <ListItemSecondaryAction>
                <Switch
                  edge="end"
                  checked={settings.pushNotifications}
                  onChange={handleSettingChange('pushNotifications')}
                />
              </ListItemSecondaryAction>
            </ListItem>
            <Divider />
            <ListItem>
              <ListItemText
                primary="Assignment Reminders"
                secondary="Get notified about upcoming assignments"
              />
              <ListItemSecondaryAction>
                <Switch
                  edge="end"
                  checked={settings.assignmentReminders}
                  onChange={handleSettingChange('assignmentReminders')}
                />
              </ListItemSecondaryAction>
            </ListItem>
            <Divider />
            <ListItem>
              <ListItemText
                primary="Grade Updates"
                secondary="Get notified when grades are posted"
              />
              <ListItemSecondaryAction>
                <Switch
                  edge="end"
                  checked={settings.gradeUpdates}
                  onChange={handleSettingChange('gradeUpdates')}
                />
              </ListItemSecondaryAction>
            </ListItem>
            <Divider />
            <ListItem>
              <ListItemText
                primary="Course Announcements"
                secondary="Get notified about course updates"
              />
              <ListItemSecondaryAction>
                <Switch
                  edge="end"
                  checked={settings.courseAnnouncements}
                  onChange={handleSettingChange('courseAnnouncements')}
                />
              </ListItemSecondaryAction>
            </ListItem>
          </List>
        </Paper>

        {/* Account Security */}
        <Paper sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <SecurityIcon sx={{ mr: 1 }} color="primary" />
            <Typography variant="h6">Account Security</Typography>
          </Box>
          <Button
            variant="outlined"
            onClick={() => setOpenPasswordDialog(true)}
          >
            Change Password
          </Button>
        </Paper>

        {/* Appearance Settings */}
        <Paper sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <PaletteIcon sx={{ mr: 1 }} color="primary" />
            <Typography variant="h6">Appearance</Typography>
          </Box>
          <FormControlLabel
            control={
              <Switch
                checked={settings.darkMode}
                onChange={handleSettingChange('darkMode')}
              />
            }
            label="Dark Mode"
          />
        </Paper>

        {/* Language Settings */}
        <Paper sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <LanguageIcon sx={{ mr: 1 }} color="primary" />
            <Typography variant="h6">Language</Typography>
          </Box>
          <FormControl fullWidth>
            <InputLabel>Language</InputLabel>
            <Select
              value={settings.language}
              label="Language"
              onChange={handleLanguageChange}
            >
              <MenuItem value="english">English</MenuItem>
              <MenuItem value="spanish">Spanish</MenuItem>
              <MenuItem value="french">French</MenuItem>
              <MenuItem value="german">German</MenuItem>
            </Select>
          </FormControl>
        </Paper>
      </Stack>

      {/* Change Password Dialog */}
      <Dialog 
        open={openPasswordDialog} 
        onClose={() => setOpenPasswordDialog(false)}
      >
        <DialogTitle>Change Password</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              label="Current Password"
              type="password"
              fullWidth
            />
            <TextField
              label="New Password"
              type="password"
              fullWidth
            />
            <TextField
              label="Confirm New Password"
              type="password"
              fullWidth
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenPasswordDialog(false)}>
            Cancel
          </Button>
          <Button onClick={handlePasswordChange} variant="contained">
            Update Password
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default StudentSettings;
