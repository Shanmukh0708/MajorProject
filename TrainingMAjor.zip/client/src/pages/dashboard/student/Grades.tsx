import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Grid,
  LinearProgress,
  Stack,
  Avatar,
} from '@mui/material';

// Mock data for grades
const grades = {
  currentSemester: [
    {
      course: 'Data Structures',
      assignments: 85,
      midterm: 78,
      final: 88,
      total: 84,
      grade: 'A-',
      status: 'In Progress',
    },
    {
      course: 'Web Development',
      assignments: 92,
      midterm: 85,
      final: null,
      total: 89,
      grade: 'A',
      status: 'In Progress',
    },
    {
      course: 'Database Systems',
      assignments: 76,
      midterm: 82,
      final: null,
      total: 79,
      grade: 'B+',
      status: 'In Progress',
    },
    {
      course: 'Computer Networks',
      assignments: 88,
      midterm: 90,
      final: null,
      total: 89,
      grade: 'A',
      status: 'In Progress',
    },
  ],
  recentActivities: [
    {
      date: '2024-02-10',
      activity: 'Final Project Submission',
      course: 'Web Development',
      grade: 95,
    },
    {
      date: '2024-02-08',
      activity: 'Midterm Exam',
      course: 'Database Systems',
      grade: 82,
    },
    {
      date: '2024-02-05',
      activity: 'Assignment #3',
      course: 'Data Structures',
      grade: 88,
    },
  ],
};

const getGradeColor = (grade: string | null) => {
  if (!grade) return 'default';
  const firstChar = grade.charAt(0);
  switch (firstChar) {
    case 'A':
      return 'success';
    case 'B':
      return 'primary';
    case 'C':
      return 'warning';
    default:
      return 'error';
  }
};

const StudentGrades = () => {
  const [semester, setSemester] = useState('current');

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Academic Performance
      </Typography>

      {/* Semester Selection */}
      <Box sx={{ mb: 4 }}>
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Semester</InputLabel>
          <Select
            value={semester}
            label="Semester"
            onChange={(e) => setSemester(e.target.value)}
          >
            <MenuItem value="current">Current Semester</MenuItem>
            <MenuItem value="fall2023">Fall 2023</MenuItem>
            <MenuItem value="spring2023">Spring 2023</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Grade Summary Cards */}
      <Grid container spacing={2} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="primary">3.85</Typography>
            <Typography variant="body2">Current GPA</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="success.main">3.92</Typography>
            <Typography variant="body2">Cumulative GPA</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="info.main">86%</Typography>
            <Typography variant="body2">Average Score</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="warning.main">15</Typography>
            <Typography variant="body2">Credits Completed</Typography>
          </Paper>
        </Grid>
      </Grid>

      {/* Detailed Grades Table */}
      <Paper sx={{ mb: 4 }}>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Course</TableCell>
                <TableCell align="center">Assignments</TableCell>
                <TableCell align="center">Midterm</TableCell>
                <TableCell align="center">Final</TableCell>
                <TableCell align="center">Total</TableCell>
                <TableCell align="center">Grade</TableCell>
                <TableCell align="center">Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {grades.currentSemester.map((course) => (
                <TableRow key={course.course}>
                  <TableCell>{course.course}</TableCell>
                  <TableCell align="center">{course.assignments}%</TableCell>
                  <TableCell align="center">{course.midterm}%</TableCell>
                  <TableCell align="center">{course.final ? `${course.final}%` : 'N/A'}</TableCell>
                  <TableCell align="center">{course.total}%</TableCell>
                  <TableCell align="center">
                    <Chip
                      label={course.grade}
                      color={getGradeColor(course.grade)}
                      size="small"
                    />
                  </TableCell>
                  <TableCell align="center">
                    <Chip
                      label={course.status}
                      color="info"
                      variant="outlined"
                      size="small"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Recent Grade Activities */}
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Recent Grade Activities
        </Typography>
        <Stack spacing={2}>
          {grades.recentActivities.map((activity, index) => (
            <Paper
              key={index}
              variant="outlined"
              sx={{ p: 2 }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Avatar 
                  sx={{ 
                    bgcolor: activity.grade >= 85 ? 'success.main' : 'primary.main',
                    width: 40,
                    height: 40,
                  }}
                >
                  {activity.grade}%
                </Avatar>
                <Box sx={{ flexGrow: 1 }}>
                  <Typography variant="subtitle2">
                    {activity.activity} - {activity.course}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {new Date(activity.date).toLocaleDateString()}
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                    <Box sx={{ flexGrow: 1, mr: 1 }}>
                      <LinearProgress
                        variant="determinate"
                        value={activity.grade}
                        sx={{ 
                          height: 8, 
                          borderRadius: 4,
                          backgroundColor: 'grey.200',
                          '& .MuiLinearProgress-bar': {
                            backgroundColor: activity.grade >= 85 ? 'success.main' : 'primary.main',
                          }
                        }}
                      />
                    </Box>
                  </Box>
                </Box>
              </Box>
            </Paper>
          ))}
        </Stack>
      </Paper>
    </Box>
  );
};

export default StudentGrades;
