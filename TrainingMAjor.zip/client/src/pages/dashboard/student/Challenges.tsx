import React, { useState } from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  LinearProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
} from '@mui/material';
import {
  Timer as TimerIcon,
  EmojiEvents as TrophyIcon,
  Code as CodeIcon,
  Assignment as AssignmentIcon,
} from '@mui/icons-material';

// Mock data for challenges
const challenges = [
  {
    id: 1,
    title: 'Array Manipulation',
    difficulty: 'Easy',
    points: 100,
    timeLimit: '30 mins',
    completedBy: 150,
    category: 'Data Structures',
    description: 'Implement various array manipulation operations like insertion, deletion, and searching.',
  },
  {
    id: 2,
    title: 'Binary Search Tree',
    difficulty: 'Medium',
    points: 200,
    timeLimit: '45 mins',
    completedBy: 89,
    category: 'Data Structures',
    description: 'Implement a binary search tree with insertion, deletion, and traversal operations.',
  },
  {
    id: 3,
    title: 'REST API Design',
    difficulty: 'Hard',
    points: 300,
    timeLimit: '60 mins',
    completedBy: 45,
    category: 'Web Development',
    description: 'Design and implement a RESTful API for a given problem statement.',
  },
  {
    id: 4,
    title: 'Database Optimization',
    difficulty: 'Medium',
    points: 250,
    timeLimit: '45 mins',
    completedBy: 76,
    category: 'Database',
    description: 'Optimize database queries and improve performance for a given scenario.',
  },
];

const StudentChallenges = () => {
  const [openChallenge, setOpenChallenge] = useState(false);
  const [selectedChallenge, setSelectedChallenge] = useState<any>(null);
  const [filter, setFilter] = useState('all');

  const handleOpenChallenge = (challenge: any) => {
    setSelectedChallenge(challenge);
    setOpenChallenge(true);
  };

  const handleCloseChallenge = () => {
    setOpenChallenge(false);
    setSelectedChallenge(null);
  };

  const handleStartChallenge = () => {
    // Handle starting the challenge
    handleCloseChallenge();
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'easy':
        return 'success';
      case 'medium':
        return 'warning';
      case 'hard':
        return 'error';
      default:
        return 'default';
    }
  };

  const filteredChallenges = filter === 'all' 
    ? challenges 
    : challenges.filter(c => c.difficulty.toLowerCase() === filter);

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Typography variant="h4" gutterBottom>
            Coding Challenges
          </Typography>
          <Typography variant="subtitle1" color="text.secondary">
            Practice and improve your coding skills
          </Typography>
        </div>
        <FormControl sx={{ minWidth: 120 }}>
          <InputLabel>Difficulty</InputLabel>
          <Select
            value={filter}
            label="Difficulty"
            onChange={(e) => setFilter(e.target.value)}
          >
            <MenuItem value="all">All</MenuItem>
            <MenuItem value="easy">Easy</MenuItem>
            <MenuItem value="medium">Medium</MenuItem>
            <MenuItem value="hard">Hard</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Challenge Cards */}
      <Grid container spacing={3}>
        {filteredChallenges.map((challenge) => (
          <Grid item xs={12} md={6} key={challenge.id}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">
                    {challenge.title}
                  </Typography>
                  <Chip
                    label={challenge.difficulty}
                    color={getDifficultyColor(challenge.difficulty) as any}
                    size="small"
                  />
                </Box>

                <Typography variant="body2" color="text.secondary" paragraph>
                  {challenge.description}
                </Typography>

                <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                  <Chip
                    icon={<TimerIcon />}
                    label={challenge.timeLimit}
                    variant="outlined"
                    size="small"
                  />
                  <Chip
                    icon={<TrophyIcon />}
                    label={`${challenge.points} Points`}
                    variant="outlined"
                    size="small"
                  />
                  <Chip
                    icon={<CodeIcon />}
                    label={challenge.category}
                    variant="outlined"
                    size="small"
                  />
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <AssignmentIcon color="action" fontSize="small" />
                  <Typography variant="body2" color="text.secondary">
                    Completed by {challenge.completedBy} students
                  </Typography>
                </Box>
              </CardContent>
              <CardActions>
                <Button 
                  size="small" 
                  variant="contained"
                  onClick={() => handleOpenChallenge(challenge)}
                >
                  Start Challenge
                </Button>
                <Button size="small">View Details</Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Challenge Dialog */}
      <Dialog open={openChallenge} onClose={handleCloseChallenge} maxWidth="md" fullWidth>
        <DialogTitle>
          {selectedChallenge?.title}
          {selectedChallenge && (
            <Chip
              label={selectedChallenge.difficulty}
              color={getDifficultyColor(selectedChallenge.difficulty) as any}
              size="small"
              sx={{ ml: 1 }}
            />
          )}
        </DialogTitle>
        <DialogContent>
          {selectedChallenge && (
            <Box sx={{ pt: 2 }}>
              <Typography variant="body1" paragraph>
                {selectedChallenge.description}
              </Typography>
              
              <Typography variant="subtitle1" gutterBottom>
                Challenge Details:
              </Typography>
              <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
                <Chip icon={<TimerIcon />} label={selectedChallenge.timeLimit} />
                <Chip icon={<TrophyIcon />} label={`${selectedChallenge.points} Points`} />
                <Chip icon={<CodeIcon />} label={selectedChallenge.category} />
              </Box>

              <Typography variant="subtitle1" gutterBottom>
                Rules:
              </Typography>
              <Typography variant="body2" component="ul" sx={{ pl: 2 }}>
                <li>You have {selectedChallenge.timeLimit} to complete the challenge</li>
                <li>You can submit your solution only once</li>
                <li>Your solution will be evaluated automatically</li>
                <li>Results will be available immediately after submission</li>
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseChallenge}>Cancel</Button>
          <Button onClick={handleStartChallenge} variant="contained" color="primary">
            Start Challenge
          </Button>
        </DialogActions>
      </Dialog>

      {/* Statistics */}
      <Grid container spacing={2} sx={{ mt: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="primary">15</Typography>
            <Typography variant="body2">Challenges Completed</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="success.main">850</Typography>
            <Typography variant="body2">Total Points Earned</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="warning.main">75%</Typography>
            <Typography variant="body2">Success Rate</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="info.main">#25</Typography>
            <Typography variant="body2">Global Ranking</Typography>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default StudentChallenges;
