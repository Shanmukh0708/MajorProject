import React from 'react';
import { Box, Container, Typography, Grid, Paper } from '@mui/material';

const About = () => {
  return (
    <Box sx={{ py: 6 }}>
      <Container maxWidth="lg">
        {/* Mission Section */}
        <Box sx={{ mb: 8, textAlign: 'center' }}>
          <Typography variant="h3" component="h1" gutterBottom>
            About Smart Skill Mentor
          </Typography>
          <Typography variant="h5" color="text.secondary" sx={{ mb: 4 }}>
            Empowering students to reach their full potential through AI-driven skill development
          </Typography>
        </Box>

        {/* Vision and Mission */}
        <Grid container spacing={4} sx={{ mb: 8 }}>
          <Grid item xs={12} md={6}>
            <Paper elevation={3} sx={{ p: 4, height: '100%' }}>
              <Typography variant="h4" gutterBottom>
                Our Vision
              </Typography>
              <Typography paragraph>
                To revolutionize skill development by creating a personalized learning ecosystem 
                that bridges the gap between education and industry requirements.
              </Typography>
              <Typography>
                We envision a future where every student has access to tailored guidance 
                and opportunities for growth, powered by cutting-edge AI technology.
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={12} md={6}>
            <Paper elevation={3} sx={{ p: 4, height: '100%' }}>
              <Typography variant="h4" gutterBottom>
                Our Mission
              </Typography>
              <Typography paragraph>
                To provide students with personalized skill development pathways that align 
                with their goals and industry demands.
              </Typography>
              <Typography>
                We're committed to leveraging AI technology to deliver accurate, actionable 
                recommendations that help students build meaningful careers.
              </Typography>
            </Paper>
          </Grid>
        </Grid>

        {/* Core Values */}
        <Box sx={{ mb: 8 }}>
          <Typography variant="h4" gutterBottom sx={{ textAlign: 'center', mb: 4 }}>
            Our Core Values
          </Typography>
          <Grid container spacing={3}>
            {[
              {
                title: 'Innovation',
                description: 'Continuously improving our AI algorithms and learning methodologies'
              },
              {
                title: 'Personalization',
                description: 'Tailoring recommendations to individual learning styles and goals'
              },
              {
                title: 'Quality',
                description: 'Maintaining high standards in our content and recommendations'
              },
              {
                title: 'Accessibility',
                description: 'Making skill development guidance available to all students'
              }
            ].map((value, index) => (
              <Grid item xs={12} sm={6} md={3} key={index}>
                <Paper elevation={2} sx={{ p: 3, height: '100%', textAlign: 'center' }}>
                  <Typography variant="h6" gutterBottom>
                    {value.title}
                  </Typography>
                  <Typography color="text.secondary">
                    {value.description}
                  </Typography>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Box>

        {/* Team Section */}
        <Box>
          <Typography variant="h4" gutterBottom sx={{ textAlign: 'center', mb: 4 }}>
            Our Team
          </Typography>
          <Typography variant="body1" paragraph sx={{ textAlign: 'center', maxWidth: 800, mx: 'auto' }}>
            Our diverse team of educators, technologists, and industry experts work together 
            to create an innovative learning platform that adapts to each student's unique needs.
          </Typography>
        </Box>
      </Container>
    </Box>
  );
};

export default About;
