import React from 'react';
import { Box, Button, Container, Typography, Grid } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();

  return (
    <Box>
      {/* Hero Section */}
      <Box sx={{ 
        bgcolor: 'primary.main',
        color: 'white',
        py: 8,
        textAlign: 'center'
      }}>
        <Container maxWidth="md">
          <Typography variant="h2" component="h1" gutterBottom>
            Unlock Your Potential with AI-Powered Skill Development
          </Typography>
          <Typography variant="h5" paragraph>
            Get personalized recommendations and track your progress with Smart Skill Mentor
          </Typography>
          <Button
            variant="contained"
            color="secondary"
            size="large"
            onClick={() => navigate('/signup')}
            sx={{ mt: 2 }}
          >
            Get Started
          </Button>
        </Container>
      </Box>

      {/* Features Section */}
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Typography variant="h3" component="h2" textAlign="center" gutterBottom>
          Why Choose Smart Skill Mentor?
        </Typography>
        <Grid container spacing={4} sx={{ mt: 4 }}>
          <Grid item xs={12} md={4}>
            <Box textAlign="center">
              <Typography variant="h5" gutterBottom>
                Personalized Learning
              </Typography>
              <Typography>
                AI-powered recommendations tailored to your goals and learning style
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box textAlign="center">
              <Typography variant="h5" gutterBottom>
                Real-World Challenges
              </Typography>
              <Typography>
                Practice with industry-relevant projects and scenarios
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box textAlign="center">
              <Typography variant="h5" gutterBottom>
                Track Progress
              </Typography>
              <Typography>
                Monitor your skill development with detailed analytics and insights
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default Home;
