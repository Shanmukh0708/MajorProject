import React from 'react';
import { Box, Container, Typography, Grid, Card, CardContent, CardMedia, CardActionArea, Chip, Stack } from '@mui/material';

const blogPosts = [
  {
    id: 1,
    title: 'The Future of AI in Skill Development',
    excerpt: 'Explore how artificial intelligence is revolutionizing the way we learn and develop new skills.',
    image: 'https://source.unsplash.com/random/800x600?ai',
    date: '2024-01-15',
    tags: ['AI', 'Education', 'Technology']
  },
  {
    id: 2,
    title: 'Top 10 In-Demand Skills for 2024',
    excerpt: 'Discover the most sought-after skills that employers are looking for in the current job market.',
    image: 'https://source.unsplash.com/random/800x600?skills',
    date: '2024-01-10',
    tags: ['Career', 'Skills', 'Job Market']
  },
  {
    id: 3,
    title: 'How to Create an Effective Learning Path',
    excerpt: 'Learn the key strategies for developing a personalized learning journey that leads to success.',
    image: 'https://source.unsplash.com/random/800x600?learning',
    date: '2024-01-05',
    tags: ['Learning', 'Strategy', 'Personal Development']
  },
  {
    id: 4,
    title: 'Success Stories: From Novice to Expert',
    excerpt: 'Read inspiring stories of students who transformed their careers through dedicated skill development.',
    image: 'https://source.unsplash.com/random/800x600?success',
    date: '2024-01-01',
    tags: ['Success Stories', 'Inspiration', 'Career Growth']
  }
];

const Blog = () => {
  return (
    <Box sx={{ py: 6 }}>
      <Container maxWidth="lg">
        {/* Blog Header */}
        <Box sx={{ mb: 8, textAlign: 'center' }}>
          <Typography variant="h3" component="h1" gutterBottom>
            Blog & Insights
          </Typography>
          <Typography variant="h5" color="text.secondary" sx={{ mb: 4 }}>
            Latest articles on skill development, industry trends, and success stories
          </Typography>
        </Box>

        {/* Blog Posts Grid */}
        <Grid container spacing={4}>
          {blogPosts.map((post) => (
            <Grid item xs={12} sm={6} md={6} key={post.id}>
              <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                <CardActionArea>
                  <CardMedia
                    component="img"
                    height="200"
                    image={post.image}
                    alt={post.title}
                  />
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography gutterBottom variant="h5" component="h2">
                      {post.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" paragraph>
                      {post.excerpt}
                    </Typography>
                    <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
                      {post.tags.map((tag, index) => (
                        <Chip
                          key={index}
                          label={tag}
                          size="small"
                          color="primary"
                          variant="outlined"
                        />
                      ))}
                    </Stack>
                    <Typography variant="caption" color="text.secondary" sx={{ mt: 2, display: 'block' }}>
                      Published on {new Date(post.date).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </Typography>
                  </CardContent>
                </CardActionArea>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Newsletter Subscription */}
        <Box sx={{ mt: 8, textAlign: 'center' }}>
          <Typography variant="h4" gutterBottom>
            Stay Updated
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 800, mx: 'auto' }}>
            Subscribe to our newsletter to receive the latest articles, insights, and updates 
            on skill development trends directly in your inbox.
          </Typography>
        </Box>
      </Container>
    </Box>
  );
};

export default Blog;
