import React from 'react';
import { Box, Container, Typography, Grid, Card, CardContent, CardHeader, List, ListItem, ListItemIcon, ListItemText } from '@mui/material';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';

const Services = () => {
  const services = [
    {
      title: 'AI-Powered Skill Assessment',
      description: 'Get a comprehensive evaluation of your current skills and identify areas for improvement.',
      features: [
        'Personalized skill gap analysis',
        'Industry-standard benchmarking',
        'Detailed performance metrics',
        'Custom improvement recommendations'
      ]
    },
    {
      title: 'Personalized Learning Paths',
      description: 'Follow customized learning paths tailored to your goals and current skill level.',
      features: [
        'AI-driven course recommendations',
        'Adaptive learning sequences',
        'Progress tracking',
        'Milestone achievements'
      ]
    },
    {
      title: 'Real-World Projects',
      description: 'Apply your skills to practical projects that simulate real industry challenges.',
      features: [
        'Industry-relevant scenarios',
        'Expert-designed challenges',
        'Portfolio-building opportunities',
        'Collaborative projects'
      ]
    },
    {
      title: 'Career Guidance',
      description: 'Receive expert guidance on career paths aligned with your skills and interests.',
      features: [
        'Industry insights',
        'Career path mapping',
        'Job market analysis',
        'Interview preparation'
      ]
    }
  ];

  return (
    <Box sx={{ py: 6 }}>
      <Container maxWidth="lg">
        {/* Services Header */}
        <Box sx={{ mb: 8, textAlign: 'center' }}>
          <Typography variant="h3" component="h1" gutterBottom>
            Our Services
          </Typography>
          <Typography variant="h5" color="text.secondary" sx={{ mb: 4 }}>
            Comprehensive skill development solutions powered by AI
          </Typography>
        </Box>

        {/* Services Grid */}
        <Grid container spacing={4}>
          {services.map((service, index) => (
            <Grid item xs={12} md={6} key={index}>
              <Card sx={{ height: '100%' }}>
                <CardHeader
                  title={service.title}
                  titleTypographyProps={{ variant: 'h5' }}
                  sx={{ bgcolor: 'primary.main', color: 'white' }}
                />
                <CardContent>
                  <Typography paragraph color="text.secondary">
                    {service.description}
                  </Typography>
                  <List>
                    {service.features.map((feature, featureIndex) => (
                      <ListItem key={featureIndex}>
                        <ListItemIcon>
                          <CheckCircleOutlineIcon color="primary" />
                        </ListItemIcon>
                        <ListItemText primary={feature} />
                      </ListItem>
                    ))}
                  </List>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Additional Information */}
        <Box sx={{ mt: 8, textAlign: 'center' }}>
          <Typography variant="h4" gutterBottom>
            Why Choose Our Services?
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 800, mx: 'auto' }}>
            Our AI-powered platform continuously adapts to your learning style and progress, 
            ensuring you get the most effective and efficient skill development experience. 
            With real-time feedback and industry-aligned content, you'll be well-prepared 
            for your career journey.
          </Typography>
        </Box>
      </Container>
    </Box>
  );
};

export default Services;
