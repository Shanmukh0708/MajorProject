import React, { useState } from 'react';
import {
  Box,
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Link,
  Alert,
  IconButton,
  InputAdornment,
  ToggleButton,
  ToggleButtonGroup,
  styled
} from '@mui/material';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import PersonIcon from '@mui/icons-material/Person';
import SchoolIcon from '@mui/icons-material/School';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';

// Styled ToggleButton for better visual hierarchy
const StyledToggleButton = styled(ToggleButton)(({ theme }) => ({
  margin: theme.spacing(1),
  padding: theme.spacing(2),
  width: '150px',
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(1),
  '&.Mui-selected': {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.primary.contrastText,
    '&:hover': {
      backgroundColor: theme.palette.primary.dark,
    },
  },
}));

const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    role: ''
  });

  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleRoleChange = (
    _event: React.MouseEvent<HTMLElement>,
    newRole: string,
  ) => {
    setFormData(prev => ({
      ...prev,
      role: newRole
    }));
    setError('');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!formData.role) {
      setError('Please select a role to continue');
      return;
    }

    try {
      // Here you would make an API call to authenticate
      console.log('Login attempt with:', formData);
      
      // Simulate API call and redirect based on role
      if (formData.email && formData.password) {
        switch(formData.role) {
          case 'student':
            navigate('/dashboard/student');
            break;
          case 'teacher':
            navigate('/dashboard/teacher');
            break;
          case 'admin':
            navigate('/dashboard/admin');
            break;
          default:
            setError('Invalid role selected');
        }
      } else {
        setError('Please fill in all fields');
      }
    } catch (err) {
      setError('Invalid email or password');
    }
  };

  return (
    <Box sx={{ py: 8, bgcolor: 'grey.50', minHeight: '100vh' }}>
      <Container maxWidth="sm">
        <Paper elevation={3} sx={{ p: 4 }}>
          <Typography variant="h4" component="h1" align="center" gutterBottom>
            Welcome Back
          </Typography>
          <Typography variant="body1" align="center" color="text.secondary" sx={{ mb: 4 }}>
            Sign in to Smart Skill Mentor
          </Typography>

          {/* Role Selection */}
          <Box sx={{ display: 'flex', justifyContent: 'center', mb: 4 }}>
            <ToggleButtonGroup
              value={formData.role}
              exclusive
              onChange={handleRoleChange}
              aria-label="user role"
            >
              <StyledToggleButton value="student" aria-label="student login">
                <SchoolIcon />
                <Typography variant="body2">Student</Typography>
              </StyledToggleButton>
              <StyledToggleButton value="teacher" aria-label="teacher login">
                <PersonIcon />
                <Typography variant="body2">Teacher</Typography>
              </StyledToggleButton>
              <StyledToggleButton value="admin" aria-label="admin login">
                <AdminPanelSettingsIcon />
                <Typography variant="body2">Admin</Typography>
              </StyledToggleButton>
            </ToggleButtonGroup>
          </Box>

          {error && (
            <Alert severity="error" sx={{ mb: 3 }}>
              {error}
            </Alert>
          )}

          <form onSubmit={handleSubmit}>
            <TextField
              fullWidth
              label="Email Address"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              margin="normal"
              required
            />
            <TextField
              fullWidth
              label="Password"
              name="password"
              type={showPassword ? 'text' : 'password'}
              value={formData.password}
              onChange={handleChange}
              margin="normal"
              required
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              size="large"
              sx={{ mt: 3, mb: 2 }}
            >
              Sign In
            </Button>
          </form>

          <Box sx={{ textAlign: 'center', mt: 2 }}>
            <Link component={RouterLink} to="/forgot-password" variant="body2">
              Forgot password?
            </Link>
          </Box>
          <Box sx={{ textAlign: 'center', mt: 2 }}>
            <Typography variant="body2">
              Don't have an account?{' '}
              <Link component={RouterLink} to="/signup">
                Sign up
              </Link>
            </Typography>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
};

export default Login;
