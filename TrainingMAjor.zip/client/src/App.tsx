import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, CssBaseline } from '@mui/material';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Layout from './components/common/Layout';
import StudentDashboardLayout from './components/dashboard/StudentDashboardLayout';
import TeacherDashboardLayout from './components/dashboard/TeacherDashboardLayout';
import AdminDashboardLayout from './components/dashboard/AdminDashboardLayout';

// Public pages
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Blog from './pages/Blog';
import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';

// Student pages
import StudentDashboard from './pages/dashboard/student/Dashboard';
import StudentCourses from './pages/dashboard/student/Courses';
import StudentAssignments from './pages/dashboard/student/Assignments';
import StudentChallenges from './pages/dashboard/student/Challenges';
import StudentGrades from './pages/dashboard/student/Grades';
import StudentProfile from './pages/dashboard/student/Profile';
import StudentSettings from './pages/dashboard/student/Settings';

// Teacher pages
import TeacherDashboard from './pages/dashboard/teacher/Dashboard';
import TeacherClasses from './pages/dashboard/teacher/Classes';
import TeacherGrading from './pages/dashboard/teacher/Grading';
import TeacherAttendance from './pages/dashboard/teacher/Attendance';
import TeacherProblems from './pages/dashboard/teacher/Problems';
import TeacherProfile from './pages/dashboard/teacher/Profile';
import TeacherSettings from './pages/dashboard/teacher/Settings';

// Admin pages
import AdminDashboard from './pages/dashboard/admin/Dashboard';
import AdminUsers from './pages/dashboard/admin/Users';
import AdminTeachers from './pages/dashboard/admin/Teachers';
import AdminStudents from './pages/dashboard/admin/Students';
import AdminReports from './pages/dashboard/admin/Reports';
import AdminProfile from './pages/dashboard/admin/Profile';
import AdminSettings from './pages/dashboard/admin/Settings';
import theme from './theme';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Router>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<Layout><Home /></Layout>} />
            <Route path="/about" element={<Layout><About /></Layout>} />
            <Route path="/services" element={<Layout><Services /></Layout>} />
            <Route path="/contact" element={<Layout><Contact /></Layout>} />
            <Route path="/blog" element={<Layout><Blog /></Layout>} />
            <Route path="/login" element={<Layout><Login /></Layout>} />
            <Route path="/signup" element={<Layout><Signup /></Layout>} />

            {/* Student Routes */}
            <Route path="/dashboard/student" element={<StudentDashboardLayout><StudentDashboard /></StudentDashboardLayout>} />
            <Route path="/dashboard/student/courses" element={<StudentDashboardLayout><StudentCourses /></StudentDashboardLayout>} />
            <Route path="/dashboard/student/assignments" element={<StudentDashboardLayout><StudentAssignments /></StudentDashboardLayout>} />
            <Route path="/dashboard/student/challenges" element={<StudentDashboardLayout><StudentChallenges /></StudentDashboardLayout>} />
            <Route path="/dashboard/student/grades" element={<StudentDashboardLayout><StudentGrades /></StudentDashboardLayout>} />
            <Route path="/dashboard/student/profile" element={<StudentDashboardLayout><StudentProfile /></StudentDashboardLayout>} />
            <Route path="/dashboard/student/settings" element={<StudentDashboardLayout><StudentSettings /></StudentDashboardLayout>} />

            {/* Teacher Routes */}
            <Route path="/dashboard/teacher" element={<TeacherDashboardLayout><TeacherDashboard /></TeacherDashboardLayout>} />
            <Route path="/dashboard/teacher/classes" element={<TeacherDashboardLayout><TeacherClasses /></TeacherDashboardLayout>} />
            <Route path="/dashboard/teacher/grading" element={<TeacherDashboardLayout><TeacherGrading /></TeacherDashboardLayout>} />
            <Route path="/dashboard/teacher/attendance" element={<TeacherDashboardLayout><TeacherAttendance /></TeacherDashboardLayout>} />
            <Route path="/dashboard/teacher/problems" element={<TeacherDashboardLayout><TeacherProblems /></TeacherDashboardLayout>} />
            <Route path="/dashboard/teacher/profile" element={<TeacherDashboardLayout><TeacherProfile /></TeacherDashboardLayout>} />
            <Route path="/dashboard/teacher/settings" element={<TeacherDashboardLayout><TeacherSettings /></TeacherDashboardLayout>} />

            {/* Admin Routes */}
            <Route path="/dashboard/admin" element={<AdminDashboardLayout><AdminDashboard /></AdminDashboardLayout>} />
            <Route path="/dashboard/admin/users" element={<AdminDashboardLayout><AdminUsers /></AdminDashboardLayout>} />
            <Route path="/dashboard/admin/teachers" element={<AdminDashboardLayout><AdminTeachers /></AdminDashboardLayout>} />
            <Route path="/dashboard/admin/students" element={<AdminDashboardLayout><AdminStudents /></AdminDashboardLayout>} />
            <Route path="/dashboard/admin/reports" element={<AdminDashboardLayout><AdminReports /></AdminDashboardLayout>} />
            <Route path="/dashboard/admin/profile" element={<AdminDashboardLayout><AdminProfile /></AdminDashboardLayout>} />
            <Route path="/dashboard/admin/settings" element={<AdminDashboardLayout><AdminSettings /></AdminDashboardLayout>} />
          </Routes>
        </Router>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
